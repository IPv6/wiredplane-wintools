[Shader]
-ColorOP:D3DTOP_MODULATE4X
-ColorP1:D3DTA_CURRENT
-ColorP2:D3DTA_TEXTURE
-AlphaOP:D3DTOP_MODULATE4X
-AlphaP1:D3DTA_CURRENT
-AlphaP2:D3DTA_TEXTURE
-BlendOP:D3DBLENDOP_ADD
-BlendSRC:D3DBLEND_SRCALPHA
-BlendDST:D3DBLEND_DESTALPHA

-VertexShader:
	;For DX8 programs input registers look like this: 
	;v0: position, v1: normal, v2: color, v3: texture cooridnates, v4: texture coordinates 2 if available.
	;Example: http://forum.gameplanet.by/index.php?s=669c0bd35297902b15ff5b53a88286c0&showtopic=334&pid=702949&st=0&#entry702949
	vs.1.1
	; transpose and transform position to clip space 
	mul r0, v0.x, c4
	mad r0, v0.y, c5, r0
	mad r0, v0.z, c6, r0
	add oPos, c7, r0
	; output texture coords
	mov oT0, v3
	; oD0-�������� ������� �����. ���� ��������� ���� ��������
	mov oD0, v2

-PixelShader:
	ps.1.1
	tex t0; sample color map
	;add r0, t0, t0     ; make it brighter and store result
	;mov r0,float3(1,1,1)
	mov r0,t0
	add r0.rgb, r0, c5

