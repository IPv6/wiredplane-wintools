Amulet of tricolor
v. 1.0

Copyright (c) 2007 Wiredplane games. 
All rights reserved

________________________________________________________________
Adventure of Lindal Calanor - magician that holds fabulous
Amulet of tricolor.
________________________________________________________________
System requirements

    - Windows 2000/XP/Vista
    - Pentium 500 or better
    - Direct3D compatable video card
    - RAM: at least 64 mb
    - 35 megs free hard drive space
    - Sound card
    - DirectX 8.1 or higher 
      You can download the latest version of DirectX at 
	  www.microsoft.com/directx
________________________________________________________________
Installing the game

Installation process is simple. Just run the "AmuletSetup.exe" file you received 
and point the folder on the disk you wish the game to be installed to, 
and the program group name in Start menu. 
After copying of required files the program is ready to be launched.
________________________________________________________________
Uninstalling the game

The program could be removed in a usual manner. To uninstall the game you should 
choose "AmuletOfTricolor Uninstall" item in start menu group. You can also choose
 the "Add/remove programs" item in a Windows Control Panel, highlight 
 "Amulet of tricolor" in installed programs list and then press "Add/remove" 
button. In a dialog box appeared you need to confirm or cancel the uninstallation
________________________________________________________________
Copyright and license

See "License.txt" file.
