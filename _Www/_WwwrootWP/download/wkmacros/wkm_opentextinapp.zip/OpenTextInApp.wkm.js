// Title: Open Text In App
// Description: Opens selected text in the application specified by the parameter, or Notepad by default.  
// ParamType: file
// Author: Walton Dell (Walt.Dell at gmail)

if ( typeof WScript != "undefined" )
{
  var objArgs = WScript.Arguments;
  if ( objArgs.length == 0 )
  {
    WScript.Echo('Usage:\n\nCScript OpenTextInApp.wk.js "Text goes here" ["ApplicationPath"]');
  }
  else
  {
    var strText = objArgs(0);
    var strParam = null;
    if (objArgs.length > 1) strParam = objArgs(1);
    wkMain(strText, strParam);
  }
}

function wkMain(selectedText,macroParameter)
{
	if (!macroParameter) macroParameter = "notepad.exe";
	var fso = new ActiveXObject("Scripting.FileSystemObject");
	var WshShell = new ActiveXObject('WScript.Shell');
	// Adding "%" to prevent WireKeys from expanding envstring by himself ("/"->"//" error otherwise)
	var tempFile = WshShell.ExpandEnvironmentStrings("%"+"TEMP"+"%"+"\\wk_selectedText.txt");
	var ts = fso.OpenTextFile(tempFile,2, true, -2);
	ts.Write(selectedText);
	ts.Close();
	WshShell.Run(macroParameter+" "+tempFile,1,false);
	var f = fso.GetFile(tempFile);
	if (macroParameter == "notepad.exe")     // We can't count on other apps starting within 3 seconds
	{
	        Sleep(3000);       // Wait 3 seconds, then delete file (notepad should have opened it by then).
        	f.Delete();        // Notepad doesn't lock file, so no problem to delete it now.
	}
	return "";
};

function Sleep(milliseconds)
{
	var d = new Date();
	while((new Date()).getTime()-d.getTime()<milliseconds){
		// Do nothing :( There is no special JavaScript function to wait for awhile
	};
}