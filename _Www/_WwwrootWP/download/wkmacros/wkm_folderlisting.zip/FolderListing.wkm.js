// Title: Folder listing
// Description: Select folder in explorer and call this macro. You will get listing of files in this folder.
// Type parameter type (string/file/folder/none)
// ParamType: none

var sLog="Listing of files:\r\n";
var	fso = new ActiveXObject("Scripting.FileSystemObject");
var iTotalCounter=0,iTotalCounterFolder=0;

if ( typeof WScript != "undefined" )
{
  var objArgs = WScript.Arguments;
  if ( objArgs.length == 0 )
  {
    WScript.Echo('Usage:\n\nCScript FolderListing.wk.js "Folder path goes here"');
  }
  else
  {
    var strText = objArgs(0);
    var strParam = null;
    if (objArgs.length > 1) strParam = objArgs(1);
    wkMain(strText, strParam);
  }
}

function processFolder(fromFolder,toFolder)
{
	var f = fso.GetFolder(fromFolder);
	var ff = new Enumerator(f.files);
	for (; !ff.atEnd(); ff.moveNext()){
		sLog+="- "+ff.item()+"\r\n";
		iTotalCounter++;
	}
	var fc = new Enumerator(f.SubFolders);
	for (; !fc.atEnd(); fc.moveNext()){
		// For each subfolder
		iTotalCounterFolder++;
		processFolder(fc.item(),toFolder);
	}
}

function wkMain(selectedText,macroParamenter)
{// wkMain description: Simply generate listing of files in the selected directory
	var sFolders=selectedText.split('\n');
	// Target location...
	if(sFolders.length>0){
		sLog+="Selected folders:\r\n"+selectedText+"\r\n\r\n";
		// For each folder in source...
		for(i=0;i<sFolders.length;i++){
			processFolder(sFolders[i],"");
		}
	}else{
		sLog+="No folders selected!\r\n";
	}
	var WshShell = new ActiveXObject('WScript.Shell');
	// Adding "%" to prevent WireKeys from expanding envstring by himself ("/"->"//" error otherwise)
	var logFile = WshShell.ExpandEnvironmentStrings("%"+"TEMP"+"%"+"\\wk_filelisting.txt");
	var ts = fso.OpenTextFile(logFile,2, true, -2);
	ts.Write(sLog);
	ts.Write("\r\nResult: listed "+iTotalCounter);
	ts.Write(" files and "+iTotalCounterFolder+" folders.\r\n\r\n");
	ts.Close();
	WshShell.Run("notepad.exe "+logFile,1,false);
	var f = fso.GetFile(logFile);
        Sleep(3000);
        f.Delete();
	return "";
};

function Sleep(milliseconds)
{
	var d = new Date();
	while((new Date()).getTime()-d.getTime()<milliseconds){
		// Do nothing :( There is no special JavaScript function to wait for awhile
	};
}

