// IconsFont.cpp : Defines the initialization routines for the DLL.
//

#include "stdafx.h"
#include <atlbase.h>
#include "WP_TextScr.h"
#include "HookCode.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern COptions plgOptions;
extern CString g_sResult;
extern CArray<HWND,HWND> g_Windows;
BOOL CALLBACK AddCWin(HWND hwnd,LPARAM lParam)
{
	g_Windows.Add(hwnd);
	return TRUE;
}

BOOL StartWindProcessing()
{
	if(g_Windows.GetSize()==0){
		return 0;
	}
	EnumChildWindows(g_Windows[0],AddCWin,0);
	g_sResult="";
	char szBuffer[10000]="";
	for(int i=0;i<g_Windows.GetSize();i++){
		::GetWindowText(g_Windows[i],szBuffer,sizeof(szBuffer));
		if(strlen(szBuffer)>0){
			g_sResult+=szBuffer;
			g_sResult+="\r\n------------------\r\n";
		}
	}
	return TRUE;
}