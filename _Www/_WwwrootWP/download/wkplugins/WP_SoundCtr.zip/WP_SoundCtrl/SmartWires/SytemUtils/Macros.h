#if !defined(H_MACROSES_IPV6)
#define H_MACROSES_IPV6
#define SUPPORT_EMAIL	"support@wiredplane.com"
#define DOWNLOAD_URL	"www.wiredplane.com"
#define	COMPANY_NAME	"WiredPlane"
#define LOGTIMEFRMT		"%d.%m.%Y %H:%M:%S"
#define BUFSIZE			1024
#define MAX(a,b) (((a) > (b)) ? (a) : (b))
#define MIN(a,b) (((a) < (b)) ? (a) : (b))
#define ABS(a)   ((a<0)?-a:a)
// Pragma message helper macros
#define chSTR2(x)	#x
#define chSTR(x)	chSTR2(x)
#define TODO(desc)	message(__FILE__ "(" chSTR(__LINE__) "):" #desc)
// Windows units conversions
#define HIMETRIC_PER_INCH   2540
#define MAP_PIX_TO_LOGHIM(x,ppli)   ( (HIMETRIC_PER_INCH*(x) + ((ppli)>>1)) / (ppli) )
#define MAP_LOGHIM_TO_PIX(x,ppli)   ( ((ppli)*(x) + HIMETRIC_PER_INCH/2) / HIMETRIC_PER_INCH )
// This macro returns TRUE if a number is between two others
#define chINRANGE(low, Num, High) (((low) <= (Num)) && ((Num) <= (High)))
// This macro evaluates to the number of elements in an array. 
#define chDIMOF(Array) (sizeof(Array) / sizeof(Array[0]))
// Quick MessageBox Macro
inline void chMB(const char* s) {
   char szTMP[128];
   GetModuleFileNameA(NULL, szTMP, chDIMOF(szTMP));
   MessageBoxA(GetActiveWindow(), s, szTMP, MB_OK);
}
// Assert/Verify Macros //////////////////////////////////////
inline void chFAIL(PSTR szMsg) {
   chMB(szMsg);
   DebugBreak();
}

// Put up an assertion failure message box.
inline void chASSERTFAIL(LPCSTR file, int line, PCSTR expr) {
   char sz[128];
   wsprintfA(sz, "File %s, line %d : %s", file, line, expr);
   chFAIL(sz);
}

// Put up a message box if an assertion fails in a debug build.
#ifdef _DEBUG
#define chASSERT(x) if (!(x)) chASSERTFAIL(__FILE__, __LINE__, #x)
#else
#define chASSERT(x)
#endif

// Assert in debug builds, but don't remove the code in retail builds.
#ifdef _DEBUG
#define chVERIFY(x) chASSERT(x)
#else
#define chVERIFY(x) (x)
#endif
// DebugBreak Improvement for x86 platforms
#ifdef _X86_
#define DebugBreak()    _asm { int 3 }
#endif
/*// This function forces the debugger to be invoked
#ifdef _DEBUG
void ForceDebugBreak() {
   __try { DebugBreak(); }
   __except(UnhandledExceptionFilter(GetExceptionInformation())) { }
}
#else
#define ForceDebugBreak()
#endif*/
// Useful macro for creating your own software exception codes
#define MAKESOFTWAREEXCEPTION(Severity, Facility, Exception) \
   ((DWORD) ( \
   /* Severity code    */  (Severity       ) |     \
   /* MS(0) or Cust(1) */  (1         << 29) |     \
   /* Reserved(0)      */  (0         << 28) |     \
   /* Facility code    */  (Facility  << 16) |     \
   /* Exception code   */  (Exception <<  0)))
////////////////////////////////////////////////////////////////
// OS Version Check Macros
inline BOOL isWin9x() {
   OSVERSIONINFO vi = { sizeof(vi) };
   GetVersionEx(&vi);
   if (vi.dwPlatformId == VER_PLATFORM_WIN32_WINDOWS) {
      return TRUE;
   }
   return FALSE;
}

inline void chWindows9xNotAllowed() {
   OSVERSIONINFO vi = { sizeof(vi) };
   GetVersionEx(&vi);
   if (vi.dwPlatformId == VER_PLATFORM_WIN32_WINDOWS) {
      chMB("This application requires features not present in Windows 9x.");
      ExitProcess(0);
   }
}

inline void chWindows2000Required() {
   OSVERSIONINFO vi = { sizeof(vi) };
   GetVersionEx(&vi);
   if ((vi.dwPlatformId != VER_PLATFORM_WIN32_NT) && (vi.dwMajorVersion < 5)) {
      chMB("This application requires features present in Windows 2000.");
      ExitProcess(0);
   }
}

#define	SHUTDOWN_NAME	"WK_SHUTDOWN"
inline BOOL SmartUnhookWindowsHookEx(HHOOK g_hhook, BOOL* bNoNeedToWait=NULL)
{
	if(bNoNeedToWait){
		*bNoNeedToWait=FALSE;
	}
	HANDLE hMutexOneInstance = ::CreateMutex( NULL, TRUE, SHUTDOWN_NAME);
	DWORD dwLastErr=GetLastError();
	CloseHandle(hMutexOneInstance);
    if(dwLastErr == ERROR_ALREADY_EXISTS){
		// ������� ����������� � ���� ��� �� ��������
		if(bNoNeedToWait){
			*bNoNeedToWait=TRUE;
		}
    	return TRUE;
    }
	// ������� ������ ����...
	BOOL bRes=TRUE;
	if(g_hhook){
		bRes=UnhookWindowsHookEx(g_hhook);
	}
	//#pragma TODO(check situation ::SendMessageTimeout HWND_BROADCAST)
	/*if(bWithSendMsg){
		DWORD dwRes=0;
		::SendMessageTimeout(HWND_BROADCAST, WM_NULL, 0, 0, SMTO_ABORTIFHUNG|SMTO_NORMAL, 100, &dwRes);
	}*/
	return bRes;
}

// ������ ��� ������ ������� � ��������� ������
#define FORK(func,param) \
	{\
		DWORD dwThread=0;\
		HANDLE hThread=::CreateThread(NULL, 0, func, LPVOID(param), 0, &dwThread);\
		::CloseHandle(hThread);\
	}
// ������ ��� ������ ������� � ��������� ������
#define FORK_WAIT(func,param,timeout) \
	{\
		DWORD dwThread=0;\
		HANDLE hThread=::CreateThread(NULL, 0, func, LPVOID(param), 0, &dwThread);\
		::WaitForSingleObject(hThread,timeout);\
		::CloseHandle(hThread);\
	}
// ������ ��� ������ ����������� � ��������� ������
#define HANDLEINTHREAD(classname,func) \
	DWORD WINAPI func##_InThread(LPVOID pValue);\
	afx_msg void classname::func()\
	{\
		DWORD dwThread=0;\
		HANDLE hThread=::CreateThread(NULL, 0, func##_InThread, NULL, 0, &dwThread);\
		::CloseHandle(hThread);\
	}\
	DWORD WINAPI func##_InThread(LPVOID pValue)
//
// ������ ��� ������ ����������� � ����� ���������� - this - � ��������� ������
#define HANDLEINTHREAD2(classname,func) \
	DWORD WINAPI func##_InThread(LPVOID pThis);\
	afx_msg void classname::func()\
	{\
		DWORD dwThread=0;\
		HANDLE hThread=::CreateThread(NULL, 0, func##_InThread, LPVOID(this), 0, &dwThread);\
		::CloseHandle(hThread);\
	}\
	DWORD WINAPI func##_InThread(LPVOID pThis)
// ������ ��� ������ ����������� � ��������� ������ � ����������� ����� ������� ����� �������
#define HANDLEINTHREAD3(classname,func,statement) \
	DWORD WINAPI func##_InThread(LPVOID pValue);\
	afx_msg void classname::func()\
	{\
		{statement;};\
		DWORD dwThread=0;\
		HANDLE hThread=::CreateThread(NULL, 0, func##_InThread, NULL, 0, &dwThread);\
		::CloseHandle(hThread);\
	}\
	DWORD WINAPI func##_InThread(LPVOID pValue)
// ������ ��� ����������� ������ �� ����
#define LOG3(x,z1,z2,z3)	{FILE* f=fopen("c:\\wk_debug.txt","a+");if(f){time_t tmt=time(NULL);fprintf(f,"%s %s(%lu): ",ctime(&tmt),__FILE__,__LINE__);fprintf(f,x,z1,z2,z3);fprintf(f,"\n");fclose(f);};};
#define LOG4(x,z1,z2,z3,z4)	{FILE* f=fopen("c:\\wk_debug.txt","a+");if(f){time_t tmt=time(NULL);fprintf(f,"%s %s(%lu): ",ctime(&tmt),__FILE__,__LINE__);fprintf(f,x,z1,z2,z3,z4);fprintf(f,"\n");fclose(f);};};
#ifdef _DEBUG
#define FLOG3(x,z1,z2,z3)	{FILE* f=fopen("c:\\wk_debug.txt","a+");fprintf(f,x,z1,z2,z3);fprintf(f,"\n");fclose(f);};
#define FLOG2(x,z1,z2)		{FILE* f=fopen("c:\\wk_debug.txt","a+");fprintf(f,x,z1,z2);fprintf(f,"\n");fclose(f);};
#define FLOG1(x,z1)			{FILE* f=fopen("c:\\wk_debug.txt","a+");fprintf(f,x,z1);fprintf(f,"\n");fclose(f);};
#define FLOG(x)				{FILE* f=fopen("c:\\wk_debug.txt","a+");fprintf(f,x);fprintf(f,"\n");fclose(f);};
#else
#define FLOG3(x,z1,z2,z3)
#define FLOG2(x,z1,z2)
#define FLOG1(x,z1)
#define FLOG(x)
#endif
// ������ ��� ����������� ���������� �� ������������
#include <time.h>
#ifdef _DEBUG
#define LOGERROR1(x,y)		{char szCurrentExeFile[MAX_PATH]="";GetModuleFileName(NULL, szCurrentExeFile, sizeof(szCurrentExeFile));char szDrive[MAX_PATH],szDir[MAX_PATH];_splitpath(szCurrentExeFile, szDrive, szDir, NULL, NULL);strcpy(szCurrentExeFile,szDrive);strcat(szCurrentExeFile,szDir);strcat(szCurrentExeFile,"errors.log");FILE* f=fopen(szCurrentExeFile,"a+");if(f){time_t tmt=time(NULL);fprintf(f,"%s %s(%lu): ",ctime(&tmt),__FILE__,__LINE__);fprintf(f,x,y);fprintf(f,"\n");fclose(f);};DebugBreak();};
#define LOGERROR2(x,y,z)	{char szCurrentExeFile[MAX_PATH]="";GetModuleFileName(NULL, szCurrentExeFile, sizeof(szCurrentExeFile));char szDrive[MAX_PATH],szDir[MAX_PATH];_splitpath(szCurrentExeFile, szDrive, szDir, NULL, NULL);strcpy(szCurrentExeFile,szDrive);strcat(szCurrentExeFile,szDir);strcat(szCurrentExeFile,"errors.log");FILE* f=fopen(szCurrentExeFile,"a+");if(f){time_t tmt=time(NULL);fprintf(f,"%s %s(%lu): ",ctime(&tmt),__FILE__,__LINE__);fprintf(f,x,y,z);fprintf(f,"\n");fclose(f);};DebugBreak();};
#else
#define LOGERROR1(x,y)		{char szCurrentExeFile[MAX_PATH]="";GetModuleFileName(NULL, szCurrentExeFile, sizeof(szCurrentExeFile));char szDrive[MAX_PATH],szDir[MAX_PATH];_splitpath(szCurrentExeFile, szDrive, szDir, NULL, NULL);strcpy(szCurrentExeFile,szDrive);strcat(szCurrentExeFile,szDir);strcat(szCurrentExeFile,"errors.log");FILE* f=fopen(szCurrentExeFile,"a+");if(f){time_t tmt=time(NULL);fprintf(f,"%s %s(%lu): ",ctime(&tmt),__FILE__,__LINE__);fprintf(f,x,y);fprintf(f,"\n");fclose(f);};};
#define LOGERROR2(x,y,z)	{char szCurrentExeFile[MAX_PATH]="";GetModuleFileName(NULL, szCurrentExeFile, sizeof(szCurrentExeFile));char szDrive[MAX_PATH],szDir[MAX_PATH];_splitpath(szCurrentExeFile, szDrive, szDir, NULL, NULL);strcpy(szCurrentExeFile,szDrive);strcat(szCurrentExeFile,szDir);strcat(szCurrentExeFile,"errors.log");FILE* f=fopen(szCurrentExeFile,"a+");if(f){time_t tmt=time(NULL);fprintf(f,"%s %s(%lu): ",ctime(&tmt),__FILE__,__LINE__);fprintf(f,x,y,z);fprintf(f,"\n");fclose(f);};};
#endif
// ������ ��� ����������� ������������������ ������ � ������
#ifdef _DEBUG
#define RLOG3(x,y1,y2,y3)	{char szText[256]="";sprintf(szText,x,y1,y2,y3);CRegKey key;if(key.Open(HKEY_CURRENT_USER, "SOFTWARE\\WiredPlane\\WireKeys\\")!=ERROR_SUCCESS){key.Create(HKEY_CURRENT_USER, "SOFTWARE\\WiredPlane\\WireKeys\\");}if(key.m_hKey!=NULL){RegSetValueEx(key.m_hKey,"DEBUG",0,REG_SZ,(BYTE*)(szText),sizeof(szText));};}
#else
#define RLOG3(x,y1,y2,y3)
#endif
// ������� ����� ��� �������������
class SimpleTracker
{
public:
	long* bValue;
	SimpleTracker(long& b){
		bValue=&b;
		InterlockedIncrement(bValue);
	};
	~SimpleTracker(){
		InterlockedDecrement(bValue);
	};
};
// �������� �� ������� ����� � �������: if(ISIN(aaa,))
#define ISIN2(x,y,z) ((x)==y || (x)==z)
////////////////////////////////////////////////////////////////
// Force Windows subsystem
#pragma comment(linker, "/subsystem:Windows")
#endif // H_MACROSES_IPV6


