// IconsFont.h : main header file for the CLOCKFONT DLL
//

#if !defined(AFX_CLOCKFONT_H__C80658DE_F831_48C1_8AC8_57C3C48BBC71__INCLUDED_)
#define AFX_CLOCKFONT_H__C80658DE_F831_48C1_8AC8_57C3C48BBC71__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols
#include "../WKPlugin.h"
#include "..\..\SmartWires\SoundUtils\MixerBase.h"
#include "..\..\SmartWires\SystemUtils\Macros.h"
class COptions
{
public:
	long lStepCount;
	long lPanStepCount;
	long lShowOSD;
};
/////////////////////////////////////////////////////////////////////////////
//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CLOCKFONT_H__C80658DE_F831_48C1_8AC8_57C3C48BBC71__INCLUDED_)
