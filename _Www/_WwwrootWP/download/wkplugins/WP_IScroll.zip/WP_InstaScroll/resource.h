//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by WP_InstaScroll.rc
//
#define IDB_BM_ICON                     1000
#define IDC_STICK                       1000
#define IDD_MAIN                        1001
#define IDC_EDIT1                       1001
#define IDC_STICKEDIT                   1001
#define IDC_SMOOTH                      1001
#define IDD_OPTIONS                     1002
#define IDC_MIN                         1002
#define IDC_SPEED                       1002
#define IDC_EDIT2                       1003
#define IDC_MIN2                        1004
#define IDC_STICK2                      1005
#define IDC_STICKEDIT2                  1006
#define IDC_MIN3                        1007
#define IDC_WKMENU                      1007
#define IDC_STICK3                      1008
#define IDC_ROLLUP                      1009
#define IDC_ROLLUP2                     1010
#define IDC_ROLLUP_MENU                 1010
#define IDC_STICKEDIT3                  1011
#define IDC_INACTSEC                    1011
#define IDC_INJECT                      1012
#define IDC_SMENU1                      1013
#define IDC_TABS                        1014
#define IDC_STATIC1                     1015
#define IDC_STATIC2                     1016
#define IDC_STATIC3                     1017
#define IDC_STATIC4                     1018
#define IDC_STATICD1                    1019
#define IDC_STATICD2                    1020
#define IDC_STATICP                     1021
#define IDC_STATIC5                     1022
#define IDC_STATIC7                     1023
#define IDC_STATIC8                     1024
#define IDC_STATIC6                     1025
#define IDC_SMENU2                      1026
#define IDC_SMENU3                      1027
#define IDC_SMENU4                      1028
#define IDC_STATIC9                     1029
#define IDC_LS                          1030
#define IDC_LC                          1031
#define IDC_LA                          1032
#define IDC_LW                          1033
#define IDC_RS                          1034
#define IDC_RC                          1035
#define IDC_RA                          1036
#define IDC_RW                          1037
#define IDC_RESTORE                     1038
#define IDC_STATICS                     1038
#define IDC_RESTORE2                    1039
#define IDC_ROLLBACK                    1039
#define IDC_STATICSL                    1039
#define IDC_STATICDIS                   1040

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        1003
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1041
#define _APS_NEXT_SYMED_VALUE           1000
#endif
#endif
