// HookCode.h: interface for the CHookCode class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_HOOKCODE_H__64477B7D_244B_4B80_B147_FBB50C232127__INCLUDED_)
#define AFX_HOOKCODE_H__64477B7D_244B_4B80_B147_FBB50C232127__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "resource.h"
struct COptions
{
	/*BOOL bAP_Add2WK;
	BOOL bRecPauses;
	long lPauseLevel;
	BOOL bAP_OpenInEd;
	long bAppSwitchesRTyp;
	CString sLastMacroName;
	CString sLastMacroContent;*/
};

#endif // !defined(AFX_HOOKCODE_H__64477B7D_244B_4B80_B147_FBB50C232127__INCLUDED_)
