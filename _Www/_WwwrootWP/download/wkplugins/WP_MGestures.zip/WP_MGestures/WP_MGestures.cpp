// IconsFont.cpp : Defines the initialization routines for the DLL.
//

#include "stdafx.h"
#include <atlbase.h>
#include "WP_MGestures.h"
#include "HookCode.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#ifdef _DEBUG
#define TRACETHREAD	TRACE3("\nCheckpoint: Thread: 0x%04x, file=%s, line=%lu\n",::GetCurrentThreadId(),__FILE__,__LINE__);
#else
#define TRACETHREAD
#endif

#define FORK(func,param) \
	{\
		DWORD dwThread=0;\
		HANDLE hThread=::CreateThread(NULL, 0, func, LPVOID(param), 0, &dwThread);\
		::CloseHandle(hThread);\
	}

CString _pl(const char* szText);
WKCallbackInterface*& WKGetPluginContainer();
extern HANDLE hStopEvent;
extern HINSTANCE g_hinstDll;
extern HANDLE hHookerThread;
extern CRITICAL_SECTION csMainThread;
/*
char* GetSubString(const char* szFrom, const char* szBegin, char cEnd, char* szTarget, const char* szDefaultValue="", int iOutBufLen=16)
{
	strcpy(szTarget,szDefaultValue);
	char* szPos=strstr(szFrom,szBegin);
	if(szPos){
		szPos=szPos+strlen(szBegin);
		char* szEnd=strchr(szPos,cEnd);
		if(szEnd){
			int iLen=szEnd-szPos;
			if(iLen>iOutBufLen){
				iLen=iOutBufLen-1;
			}
			memcpy(szTarget,szPos,iLen);
			szTarget[iLen]=0;
		}
	}
	return szTarget;
}*/

BOOL bNotStop=0;
extern BOOL bShowInOSD;
extern BOOL bStepTime;
DWORD WINAPI DepressKey(LPVOID pData)
{
	char c=(char)pData;
	char sz1[]="MOG0";
	sz1[3]=c;
	WKGetPluginContainer()->NotifyEventStarted(sz1);
	if(bShowInOSD){
		CString sText=_pl("Mouse gesture: Left-to-Right");
		if(c=='1'){
			sText=_pl("Mouse gesture: Right-to-Left");
		}
		if(c=='2'){
			sText=_pl("Mouse gesture: Top-to-Bottom");
		}
		if(c=='3'){
			sText=_pl("Mouse gesture: Bottom-to-Top");
		}
		WKGetPluginContainer()->ShowOSD(sText,bStepTime>0?bStepTime*1000:3000);
	}
	Sleep(bStepTime*1000);
	char sz2[]="MOG0";
	sz2[3]=c;
	WKGetPluginContainer()->NotifyEventFinished(sz2);
	return 0;
}


BOOL bGestureInAction=0;
DWORD WINAPI GlobalHooker_Gestures(LPVOID pData)
{
	::EnterCriticalSection(&csMainThread);
	//FLOG(" in>>\r\n");
	char c=0;
	CPoint pt0;
	::GetCursorPos(&pt0);
	BOOL bNotStopStart=bNotStop;
#ifdef _DEBUG
	//{char sz[64]={0};	sprintf(sz,"!!! %i->%i: Action: (%i,%i)",bNotStopStart,bNotStop,pt0.x,pt0.y);	FLOG(sz);}
#endif
	bGestureInAction=2;
	while(bNotStopStart==bNotStop){
		Sleep(20);
	}
	CPoint pt1;
	::GetCursorPos(&pt1);
#ifdef _DEBUG
	//{char sz[64]={0};	sprintf(sz,"!!! %i->%i: Action2: (%i,%i)",bNotStopStart,bNotStop,pt1.x,pt1.y);	FLOG(sz);}
#endif
	long lX=pt1.x-pt0.x;
	long lY=pt1.y-pt0.y;
	CRect rt;
	GetWindowRect(GetDesktopWindow(),&rt);
	if(max(abs(lX),abs(lY))>max(rt.Width(),rt.Height())/5 && min(abs(lX),abs(lY))<max(rt.Width(),rt.Height())/5){
		if(abs(lX)>abs(lY)){
			// X
			if(pt1.x>pt0.x){
				c='0';
			}else{
				c='1';
			}
		}else{
			// Y
			if(pt1.y>pt0.y){
				c='2';
			}else{
				c='3';
			}
		}
	}
	// ������� ����������!!! ������������
	if(c!=0){
		FORK(DepressKey,c);
	}
	bGestureInAction=0;
	//FLOG(" out<<\r\n");
	::LeaveCriticalSection(&csMainThread);
	return 0;
}
