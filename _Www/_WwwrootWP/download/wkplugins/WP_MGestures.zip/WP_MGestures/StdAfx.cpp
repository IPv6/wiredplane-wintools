#include "stdafx.h"
//#include <winspool.h>
extern "C" __declspec( dllexport )
BOOL WINAPI ClosePrinter(HANDLE hPrinter)
{
	return FALSE;
}

extern "C" __declspec( dllexport )
LONG WINAPI DocumentPropertiesA(HWND,HANDLE,LPTSTR,PDEVMODE,PDEVMODE,DWORD)
{
	return 0;
}

typedef struct _PRINTER_DEFAULTSA{
	LPSTR pDatatype;
    LPDEVMODEA pDevMode;
    ACCESS_MASK DesiredAccess;
} PRINTER_DEFAULTSA, *PPRINTER_DEFAULTSA, *LPPRINTER_DEFAULTSA;

extern "C" __declspec( dllexport )
BOOL WINAPI OpenPrinterA(LPTSTR,LPHANDLE,LPPRINTER_DEFAULTSA)
{
	return FALSE;
}


