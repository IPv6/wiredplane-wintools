//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by WP_MGestures.rc
//
#define ID_SETFONT                      2
#define IDB_BM_ICON                     1000
#define IDC_BGCOL                       1000
#define IDD_MAIN                        1001
#define IDD_OPTIONS                     1002
#define IDC_BT_BG                       1004
#define IDC_CHECK_EDOPEN                1004
#define IDC_CHECK2                      1005
#define IDC_CHECK_ADDWK                 1005
#define IDC_EDIT_PAUSEL                 1006
#define IDC_CHECK_PAUSE                 1007
#define IDC_SETFONT                     1008
#define IDC_EDIT_TITLE                  1008
#define IDC_SETTXCOL                    1009
#define IDC_RADIO1                      1009
#define IDC_SETBGCOL                    1010
#define IDC_RADIO2                      1010
#define IDC_SETBGTRANS                  1011
#define IDC_RADIO3                      1011

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        1003
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1010
#define _APS_NEXT_SYMED_VALUE           1000
#endif
#endif
