/*
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 * 02111-1307, USA.
 */

#include "../sets.h"
extern CSettings sets;
extern DWORD dwLastOkPop3Login;
long lNoRecurseS=0;
long lNoRecurse=0;

#include <string.h>
#include "SmtpPop3d.h"
#define MAXARGC 20

#define AUTHORIZATION 10
#define TRANSACTION 20
#define UPDATE 40
#define TERMINATE 80

#define AUTHORIZATION_TIMEOUT 15
#define TRANSACTION_TIMEOUT   30

BOOL SetTooltipText(LPCTSTR pszTip, BOOL bWithLog);

CString toString(const char* szFormat,...)
{
	va_list vaList;
	va_start(vaList,szFormat);
	CString sBuffer;
	sBuffer.FormatV(szFormat,vaList);
	va_end (vaList);
	return sBuffer;
}

// ������� ����� ��� �������������
class SimpleTracker
{
public:
	long* bValue;
	SimpleTracker(long& b){
		bValue=&b;
		InterlockedIncrement(bValue);
	};
	~SimpleTracker(){
		InterlockedDecrement(bValue);
	};
};

typedef struct cmdtable 
{
	char name[10];
	int  states;
	void  (*handler)(CMapiStuffClient *,int, char *[], StreamSocket&);
} cmdtable;


typedef struct cmdtableSmtp
{
	char name[10];
	int  states;
	void  (*handler)(CSmtpRequest* ,int, char *[], const char* szRawInput, StreamSocket&);
} cmdtableSmtp;

/* Global variables */
/*
int  state;
char username[N_BUFLEN];
struct passwd *userpw;

static char pop3msg[N_BUFFER];
static char smtpmsg[N_BUFFER];

#include <windows.h>
*/

/*
 * Appends src to string dst of size siz (unlike strncat, siz is the
 * full size of dst, not space left).  At most siz-1 characters
 * will be copied.  Always NUL terminates (unless siz <= strlen(dst)).
 * Returns strlen(src) + MIN(siz, strlen(initial dst)).
 * If retval >= siz, truncation occurred.
 */
size_t
strlcat(char* dst, const char *src, size_t siz)
{
	register char *d = dst;
	register const char *s = src;
	register size_t n = siz;
	size_t dlen;

	/* Find the end of dst and adjust bytes left but don't go past end */
	while (n-- != 0 && *d != '\0')
		d++;
	dlen = d - dst;
	n = siz - dlen;

	if (n == 0)
		return(dlen + strlen(s));
	while (*s != '\0') {
		if (n != 1) {
			*d++ = *s;
			n--;
		}
		s++;
	}
	*d = '\0';

	return(dlen + (s - src));	/* count does not include NUL */
}

/*
 * Copy src to string dst of size siz.  At most siz-1 characters
 * will be copied.  Always NUL terminates (unless siz == 0).
 * Returns strlen(src); if retval >= siz, truncation occurred.
 */

size_t strlcpy(char* dst, const char* src, size_t siz)
{
	register char *d = dst;
	register const char *s = src;
	register size_t n = siz;

	/* Copy as many bytes as will fit */
	if (n != 0 && --n != 0) {
		do {
			if ((*d++ = *s++) == 0)
				break;
		} while (--n != 0);
	}

	/* Not enough room in dst, add NUL and traverse rest of src */
	if (n == 0) {
		if (siz != 0)
			*d = '\0';		/* NUL-terminate dst */
		while (*s++)
			;
	}

	return(s - src - 1);	/* count does not include NUL */
}

/****** MISC FUNCTIONS ******/
/* get the next command from the client 
 * and put it in the global input buffer
 */
BOOL get_input(StreamSocket& ns, char input[N_BUFLEN])
{
	memset(input,0,sizeof(input));
	int len = ns.Read(input, N_BUFLEN-1);
	if(len == 0 || len == SOCKET_ERROR){
		return 0;
	}
	input[len]=0;
	while(input[len - 1] != '\n'){
		len += ns.Read(input + len, N_BUFLEN-1-len);
		input[len]=0;
		if(len == 0 || len == SOCKET_ERROR){
			return 0;
		}
	}
	return 1;
}

/***** COMMAND HANDLERS ******/
void not_spoken_cmd(CMapiStuffClient *request,int argc, char *argv[], StreamSocket& ns) {
	char pop3msg[N_BUFFER]={0};
	strcpy(pop3msg,"-ERR ");
	ns.Write(pop3msg, strlen(pop3msg));
	strcpy(pop3msg,argv[0]);
	ns.Write(pop3msg, strlen(pop3msg));
	strcpy(pop3msg," not spoken here.\015\012");
	ns.Write(pop3msg, strlen(pop3msg));
}

void pass_cmd(CMapiStuffClient *request,int argc, char *argv[], StreamSocket& ns) 
{
	char pop3msg[N_BUFFER]={0};
	if (request->szPop3Username[0] == '\0') 
	{
		strcpy(pop3msg,"-ERR Please log in with USER first\015\012");
		ns.Write(pop3msg, strlen(pop3msg));
		return;
	}
	
	if (argc < 2) 
	{
		strcpy(pop3msg,"-ERR Missing password argument\015\012");
		ns.Write(pop3msg, strlen(pop3msg));
		return;
	}
	std::string error="";
	int iErr=httpmail_authenticate_user(request, request->szPop3Username, argv[1], ns, error);
	if (!iErr) 
	{
		//LOG(("AUTH failed user=%s host=%s\015\012", N_BUFLEN, username, inet_client_name));
		if(error.size()==0){
			error="Username or password was incorrect.";
		}
		std::string out="-ERR";
		out+=error;
		out+="\015\012";
		strcpy(pop3msg,out.c_str());
		ns.Write(pop3msg, strlen(pop3msg));
		request->iPop3State = TERMINATE;
		return;
	}
	
	/* mailbox is open-- we go to transaction state
	* According to RFC 1939, a POP server should be able to handle
	* the RETR command immideately after entering the TRANSACTION
	* state. For this to work, we need to do an implicit STAT on the
	* mail store, otherwise RETR will fail. The STAT will also produce
	* the needed +OK response. To add insult to injury, we need to do
	* the 'main' STAT action (getting the list of messages from the server)
	* TWICE to make sure we get all the cookies we need to retrieve
	* messages. So, that httpmail_init() call is nothing more than a
	* 'bare bones', no output version of STAT.
	*/
	httpmail_init(request, ns);
	httpmail_stat(request, ns);
	request->iPop3State = TRANSACTION;
	/* log it */
}

void user_cmd(CMapiStuffClient *request,int argc, char *argv[], StreamSocket& ns) 
{
	char pop3msg[N_BUFFER]={0};
	if (argc < 2) 
	{
		strcpy(pop3msg,"-ERR Missing username argument\015\012");
		ns.Write(pop3msg, strlen(pop3msg));
		return;
	}
	strlcpy(request->szPop3Username,argv[1], N_BUFLEN);

	strcpy(pop3msg,"+OK User name accepted, password please\015\012");
	ns.Write(pop3msg, strlen(pop3msg));
}

void list_cmd(CMapiStuffClient *request,int argc, char *argv[], StreamSocket& ns) 
{
	char pop3msg[N_BUFFER]={0};
	if (argc == 1) 
	{
		httpmail_list(request, NULL, ns);
		return;
	}
	if (argc == 2) 
	{
		httpmail_list(request, argv[1], ns);
	}
}		

void stat_cmd(CMapiStuffClient *request,int argc, char *argv[], StreamSocket& ns) 
{
	httpmail_stat(request, ns);
}

void rset_cmd(CMapiStuffClient *request,int argc, char *argv[], StreamSocket& ns) 
{
	httpmail_rset(request, ns);
}

void uidl_cmd(CMapiStuffClient *request,int argc, char *argv[], StreamSocket& ns) 
{
	if (argc == 1) 
	{
		httpmail_uidl(request, NULL, ns);
		return;
	}
	if (argc == 2) 
	{
		httpmail_uidl(request, argv[1], ns);
	}
}		

void top_cmd(CMapiStuffClient *request,int argc, char *argv[], StreamSocket& ns) 
{
	char pop3msg[N_BUFFER]={0};
	if (argc < 2) 
	{
    	strcpy(pop3msg,"-ERR Missing arguments\015\012");
		ns.Write(pop3msg, strlen(pop3msg));
		return;
	}
	DWORD dwSize=0;
	if (argc > 2){
		dwSize=atol(argv[2]);
	}
	httpmail_top(request, argv[1], dwSize, ns);
}

void retr_cmd(CMapiStuffClient *request,int argc, char *argv[], StreamSocket& ns) 
{
	char pop3msg[N_BUFFER]={0};
	if (argc < 2) 
	{
	    strcpy(pop3msg,"-ERR Missing message number argument\015\012");
		ns.Write(pop3msg, strlen(pop3msg));
		return;
	}
	httpmail_retrieve(request, argv[1], ns);
}

void dele_cmd(CMapiStuffClient *request,int argc, char *argv[], StreamSocket& ns) 
{
	char pop3msg[N_BUFFER]={0};
	if (argc < 2)
	{
	    strcpy(pop3msg,"-ERR Missing message number argument\015\012");
		ns.Write(pop3msg, strlen(pop3msg));
		return;
	}
	httpmail_delete(request, argv[1], ns);
}

void noop_cmd(CMapiStuffClient *request,int argc, char *argv[], StreamSocket& ns)
{
	char pop3msg[N_BUFFER]={0};
	strcpy(pop3msg,"+OK let us wait.\015\012");
	ns.Write(pop3msg, strlen(pop3msg));
}

void quit_cmd(CMapiStuffClient *request,int argc, char *argv[], StreamSocket& ns)
{
	char pop3msg[N_BUFFER]={0};
	strcpy(pop3msg,"+OK see you later!\015\012");
	ns.Write(pop3msg, strlen(pop3msg));	
	if (request->iPop3State == TRANSACTION) 
	{
		request->iPop3State = UPDATE;
	} 
	else 
	{
		request->iPop3State = TERMINATE;
	}
	httpmail_quit(request, ns);
}

void exit_cmd(CMapiStuffClient *request,int argc, char *argv[], StreamSocket& ns) 
{
	char pop3msg[N_BUFFER]={0};
	strcpy(pop3msg,"-ERR Client timeout.  Exiting without update.\015\012");
	ns.Write(pop3msg, strlen(pop3msg));	
	request->iPop3State = TERMINATE;
}

/* 
 * Global jumptable for commands
 */
cmdtable commands[] = 	{ 	
  { "rpop", AUTHORIZATION, &not_spoken_cmd },
  { "apop", AUTHORIZATION, &not_spoken_cmd },
  { "auth", AUTHORIZATION, &not_spoken_cmd },
  { "user", AUTHORIZATION, &user_cmd },
  { "pass", AUTHORIZATION, &pass_cmd },
  { "list", TRANSACTION, &list_cmd },
  { "stat", TRANSACTION, &stat_cmd },
  { "dele", TRANSACTION, &dele_cmd },
  { "rset", TRANSACTION, &rset_cmd },
  { "noop", TRANSACTION, &noop_cmd },
  { "uidl", TRANSACTION, &uidl_cmd },
  { "top",  TRANSACTION, &top_cmd },
  { "retr", TRANSACTION, &retr_cmd },
  { "quit", (AUTHORIZATION | TRANSACTION), &quit_cmd },
  { "timeout", (AUTHORIZATION | TRANSACTION), &exit_cmd },
  { "", 0, NULL }
};

/* 
 * Global jumptable for commandsSmtp
 */
cmdtableSmtp commandsSmtp[] = 	{ 	
  { "RCPT", 0, &smtp_rcpt },
  { "DATA", 0, &smtp_data },
  { "MAIL", 0, &smtp_helo },
  { "NOOP", 0, &smtp_ok },
  { "RSET", 0, &smtp_rset },
  { "HELO", 0, &smtp_helo },
  { "EHLO", 0, &smtp_helo },
  { "QUIT", TERMINATE, &smtp_quit },
  { "", 0, NULL }
};


/******* MAIN LOOP ******/
void HandleSMTP(CSmtpRequest* smtpRequest,StreamSocket& ns)
{
	char smtpmsg[N_BUFFER]={0};
	char input[N_BUFLEN]={0};
	int   argc;
	char *argv[MAXARGC], *x;
	int   cmd_implemented;
	cmdtableSmtp *c;

	if(lNoRecurseS>0){
		strcpy(smtpmsg,"421 SMTP2MAPI proxy server by WiredPlane.com is busy now\015\012");
		ns.Write(smtpmsg, strlen(smtpmsg));
		return;
	}
	SimpleTracker lc(lNoRecurseS);
	strcpy(smtpmsg,"220 SMTP2MAPI ESMTP proxy server by WiredPlane.com ready\015\012");
	ns.Write(smtpmsg, strlen(smtpmsg));
	BOOL smtpStop=0;
	while(!smtpStop)
	{
		/* get the input from the client */	
		if(!get_input(ns,input)){
			strcpy(smtpmsg,"504 Command not implemented\015\012");
			ns.Write(smtpmsg, strlen(smtpmsg));
			return;
		}

		std::string inputRaw=input;
		/* init before continuing */
		cmd_implemented = 0;

		/* init argc, argv */
		for (argc = MAXARGC; argc; argv[--argc] = NULL);

		/* strip command from args --
		*  	assumes the cmd points to a properly null terminated string 
		*  	we'll strip off the crlf as well!! 
		*/
		for(x = input; *x != '\0'; x++) 
		{
			if (*x == ' ' || *x == '\n' || *x == '\r') 
			{
				*x = '\0';
				if (argv[argc] == NULL) 
				{ 
					continue; 
				}
				else 
				{
					argc++;
					if (argc >= MAXARGC) 
					{
						break;
					}
				}
			} 
			else 
			{
			if (argv[argc] == NULL)
				argv[argc] = x;
			}
		}
			
		if (!argc) 
		{
			sets.AddLog("SMTP: Unknown command");
			strcpy(smtpmsg,"504 Command not implemented\015\012");
			ns.Write(smtpmsg, strlen(smtpmsg));
			continue;
		}	

		/* cycle through jumptable */
		for (c = commandsSmtp; c->handler != NULL; c++) 
		{
			if (!stricmp(c->name, argv[0])) 
			{
				cmd_implemented++;
				(c->handler)(smtpRequest, argc, argv, inputRaw.c_str(), ns);
				sets.AddLog("SMTP: %s Executed successfully",argv[0]);
				if(c->states==TERMINATE){
					// �����!
					smtpStop=1;
				}
			}
		}

		if (!cmd_implemented) 
		{
			sets.AddLog("SMTP: Unknown command: %s",argv[0]);
			strcpy(smtpmsg,"504 Command not implemented\015\012");
			ns.Write(smtpmsg, strlen(smtpmsg));
		}

	}
}

void main_loopSmtp(StreamSocket& ns)
{
	static long lSmtpCount=0;
	lSmtpCount++;
	SetTooltipText(toString("SMTP: new connection (#%i)",lSmtpCount),1);
	CSmtpRequest smtpRequest;
	HandleSMTP(&smtpRequest, ns);
	SetTooltipText(toString("SMTP: connection #%i handled",lSmtpCount),1);
	SetTooltipText("",0);
};

void HandlePOP3(CMapiStuffClient* request,StreamSocket& ns)
{
	char pop3msg[N_BUFFER]={0};
	char input[N_BUFLEN]={0};
	int   argc;
	char *argv[MAXARGC], *x;
	int   cmd_implemented;
	cmdtable *c;

	request->iPop3State = AUTHORIZATION; 
	strcpy(pop3msg,"+OK POP3 MAPI2POP3 proxy server by WiredPlane.com ready\015\012");
	ns.Write(pop3msg, strlen(pop3msg));
	while(request->iPop3State < UPDATE){	
		/* make sure we've flushed all output before waiting on client */

		/* set timeout according to our state */
		switch (request->iPop3State) 
		{
		case AUTHORIZATION:
			request->iPop3Timeout = AUTHORIZATION_TIMEOUT;
			break;

		case TRANSACTION:
			request->iPop3Timeout = TRANSACTION_TIMEOUT;
			break;
		}

		/* get the input from the client */	
		if(!get_input(ns,input)){
			strcpy(pop3msg,"-ERR Command not implemented\015\012");
			ns.Write(pop3msg, strlen(pop3msg));
			return;
		}

		/* init before continuing */
		cmd_implemented = 0;

		/* init argc, argv */
		for (argc = MAXARGC; argc; argv[--argc] = NULL);

		/* strip command from args --
		*  	assumes the cmd points to a properly null terminated string 
		*  	we'll strip off the crlf as well!! 
		*/
		for(x = input; *x != '\0'; x++) 
		{
			if (*x == ' ' || *x == '\n' || *x == '\r') 
			{
				*x = '\0';
				if (argv[argc] == NULL) 
				{ 
					continue; 
				}
				else 
				{
					argc++;
					if (argc >= MAXARGC) 
					{
						break;
					}
				}
			} 
			else 
			{
				if (argv[argc] == NULL)
					argv[argc] = x;
			}
		}

		if (!argc) 
		{
			//strcpy(pop3msg,"-ERR Null command\015\012");
			strcpy(pop3msg,"-ERR Command not implemented\015\012");
			ns.Write(pop3msg, strlen(pop3msg));
			continue;
		}	

		/* cycle through jumptable */
		for (c = commands; c->handler != NULL; c++) 
		{
			if (!stricmp(c->name, argv[0])) 
			{
				cmd_implemented++;
				if (c->states & request->iPop3State) 
				{
					if(request->lMailLoading){
						strcpy(pop3msg,"-ERR Background message retrieval in progress. That command is not available right now.\015\012");
						ns.Write(pop3msg, strlen(pop3msg));
					}else{
						(c->handler)(request, argc, argv, ns);
					}
				} 
				else 
				{
					strcpy(pop3msg,"-ERR That command is not available right now.\015\012");
					ns.Write(pop3msg, strlen(pop3msg));
				}		
			}
		}

		if (!cmd_implemented) 
		{
			strcpy(pop3msg,"-ERR Command not implemented\015\012");
			ns.Write(pop3msg, strlen(pop3msg));
		}
	}
	/*
	if (request->iPop3Timed_out) 
	{
		if ((request->iPop3Timed_out == 1) || (request->iPop3Timed_out == 9)) {
			//client hangup?
			//LOG("Timeout occured host=%s\n", inet_client_name);
		} 
		return;
	}
	*/
	if (request->iPop3State == TERMINATE) 
	{
		//LOG("EXIT host=%s\n", inet_client_name);
		return;
	}
	if (request->iPop3State == UPDATE) 
	{
		//LOG(" OUT\n");
		request->iPop3State = TERMINATE;
	}
}

void main_loopPop3(StreamSocket& ns)
{
	static long lPop3Count=0;
	lPop3Count++;
	SetTooltipText(toString("POP3: new connection (#%i)",lPop3Count),1);
	CMapiStuffClient* request=new CMapiStuffClient();
	HandlePOP3(request,ns);
	if(request->lMailLoading==0){
		delete request;
		request=0;
		SetTooltipText(toString("POP3: connection #%i handled",lPop3Count),1);
	}else{
		request->bSelfDelete=1;
		SetTooltipText(toString("POP3: connection #%i handled, but loading was moved to the background",lPop3Count),1);
	}
	SetTooltipText("",0);
}
