/*
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 2, or (at your option)
* any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
* 02111-1307, USA.
*/
#include "stdafx.h"
#include "SmtpPop3d.h"
#include "..\MSMapi\MapiStuffclient.h"
#include "..\common.h"

extern CSettings sets;
extern HWND m_MainWnd;

// For Pop3 before Smtp authorization
CString sLastPop3User;
CString sLastPop3Pass;
DWORD dwLastOkPop3Login=0;

using namespace std;
DWORD WINAPI LoadMails(LPVOID p)
{
	BOOL bRes=0;
	CMapiStuffClient* request=(CMapiStuffClient*) p;
	request->bLoadedOK=0;
	{
		SimpleTracker lc(request->lMailLoading);
		SimpleLocker lcc(&request->csMAPIGuard);
		int iELRes=request->mapi_LoadExchange();
		if(iELRes<=0){
			request->bLoadedOK=iELRes;
			return iELRes;
		}
		if (request->mapi_Libraries.size()==0){
			request->bLoadedOK=-1;
			return -1;
		}
		{
			CString sUser=request->user.c_str();
			CString sPass=request->pass.c_str();
			if(sets.sPop3DefaultProfile==OPT_ASKUSER || sets.sPop3DefaultProfile==OPT_DEFAULT){
				sUser="";
				sPass="";
			}else if(sets.sPop3DefaultProfile!=OPT_FROMPOP3){
				sUser=sets.sPop3DefaultProfile;
			}
			sLastPop3User=sUser;
			sLastPop3Pass=sPass;
			request->sLogonProfile=sUser;
			request->sLogonPassword=sPass;
			request->sRestrictToStore=sets.sDefaultStore;
			request->sRestrictToFolder=sets.sDefaultFolder;
			// ���������� ���
			DWORD dwTime1=GetTickCount();
			int iESRes=request->mapi_OpenExchange(EXCH_PURPOSE_GETMAILS,0,sets.sPop3DefaultProfile==OPT_ASKUSER);
			if(iESRes<=0){
				request->bLoadedOK=iESRes;
				return iESRes;
			}
			DWORD dwTime2=GetTickCount();
			if(dwTime2-dwTime1<5000){
				Sleep(5000-(dwTime2-dwTime1));
			}
			int iEMRes=request->mapi_EnsureMessages(m_MainWnd,0);
			if(iEMRes<=0){
				bRes=iEMRes;
			}else{
				dwLastOkPop3Login=GetTickCount();
				bRes=1;
				sets.lStat_Ses++;
				sets.bChanged=1;
				request->bLoadedOK=1;
			}
		}
		SetTooltipText("");
	}
	request->bLoadedOK=bRes;
	if(request->bSelfDelete){
		// �������� ����� ��� �� ��������....
		// ������� ����
		delete request;
	}
	return bRes;
}

int httpmail_authenticate_user(CMapiStuffClient *request, char *user, char *pass, StreamSocket& ns, std::string& error)
{
	try{
		SetTooltipText("Checking POP3 user...");
		_log(0,"POP3: Checking POP3 login");
		BOOL bLoadingInProgress=0;

		if(request->lMailLoading>0){
			bLoadingInProgress=1;
		}
		if(bLoadingInProgress){
			_log(0,"POP3: message retrieval still in progress");
			error=" Your messages are loading in background. Try to connect later, Please.";
			return 0;
		}
		SimpleTracker lc(request->lMailLoading);
		request->user=user;
		request->pass=pass;
		DWORD dwThread=0;
		HANDLE hThread=::CreateThread(NULL, 0, LoadMails, LPVOID(request), 0, &dwThread);
		DWORD dwTimeOut=::WaitForSingleObject(hThread,sets.lPop3TimeOut*1000);
		::CloseHandle(hThread);
		if(dwTimeOut!=WAIT_OBJECT_0){
			request->bLoadingTimeout=true;
			_log(0,"POP3: message retrieval still in progress");
			error=" A lot of new messages found, they are currently loading in background. Try to connect later, please.";
			SetTooltipText("Downloading message(s)");
			return 0;
		}
		// ������ ����� ���������� ��� ��������
		long lRes=request->bLoadedOK;
		if(lRes!=1){
			CString sErr;
			sErr.Format("POP3: Exchange convisation error=%i",lRes);
			_log(0,sErr);
		}
		if(lRes==RET_NOPROFILE){
			_log(0,"POP3: Exchange profile not found. Check your settings (profile='%s').",request->sLogonProfile.c_str());
			error=" Exchange profile not found. Check your settings (profile='"+request->sLogonProfile+"').";
			return 0;
		}
		return lRes==1?1:0;
	}catch(...){
		_log(0,"auth: unknown exception");
		return 0;
	}
	return 0;
}

void httpmail_init(CMapiStuffClient *request, StreamSocket& ns)
{
	return;
}

HWND m_MainWnd=0;
void httpmail_stat(CMapiStuffClient *request, StreamSocket& ns)
{
	char pop3msg[N_BUFFER]={0};
	char buffer[N_BUFFER]={0};
	request->listdownloaded = 0;
	try{
		if(!request){
			strcpy(pop3msg, "-ERR Internal error\015\012");
			ns.Write(pop3msg, strlen(pop3msg));
			return;
		}
		_snprintf(buffer, N_BUFFER, "+OK %lu %lu\015\012", request->mapi_Messages.size(), request->maildrop_size);
		ns.Write(buffer, strlen(buffer));
		request->listdownloaded = 1;
	}catch(...){
		_log(0,"stat: unknown exception");
		strcpy(pop3msg, "-ERR Internal error (Exception occured)\015\012");
		ns.Write(pop3msg, strlen(pop3msg));
	}
}

void httpmail_list(CMapiStuffClient *request, char *arg, StreamSocket& ns)
{
	char pop3msg[N_BUFFER]={0};
	char buffer[N_BUFFER]={0};
	try{
		long i;
		
		if (!request->listdownloaded)
		{
			httpmail_stat(request, ns);
		}
		long visiblecount=request->mapi_Messages.size();
		if (arg == NULL)
		{
			strcpy(pop3msg, "+OK Mailbox scan listing follows\n");
			ns.Write(pop3msg, strlen(pop3msg));
			for (i = 0; i < visiblecount; i++) 
			{
				_snprintf(buffer, N_BUFFER, "%lu %u\015\012", (i + 1), request->mapi_Messages[i].len);
				ns.Write(buffer, strlen(buffer));
			}
			strcpy(pop3msg, ".\015\012");
			ns.Write(pop3msg, strlen(pop3msg));
			return;
		}
		
		if ((i = strtoul(arg, NULL, 10)) && (i <= visiblecount) && (i > 0)) 
		{
			_snprintf(buffer, N_BUFFER, "+OK %lu %u\015\012", i, request->mapi_Messages[i-1].len);
			ns.Write(buffer,strlen(buffer));
		} 
		else 
		{
			strcpy(pop3msg, "-ERR No such message\015\012");
			ns.Write(pop3msg, strlen(pop3msg));
		}
	}catch(...){
		_log(0,"list: unknown exception");
		strcpy(pop3msg, "-ERR Internal error (Exception occured)\015\012");
		ns.Write(pop3msg, strlen(pop3msg));
	}
}

void httpmail_rset(CMapiStuffClient *request, StreamSocket& ns)
{
	char pop3msg[N_BUFFER]={0};
	for(int i=0;i<request->mapi_Messages.size();i++){
		request->mapi_Messages[i].todelete=false;
	}
	strcpy(pop3msg, "+OK Mailbox has been reset\015\012");
	ns.Write(pop3msg, strlen(pop3msg));
}

void httpmail_top(CMapiStuffClient *request, char *arg, long dwSize, StreamSocket& ns)
{
	char pop3msg[N_BUFFER]={0};
	try{
		long i;
		long visiblecount=request->mapi_Messages.size();
		if ((i = strtoul(arg, NULL, 10)) && (i <= visiblecount) && (i > 0)) 
		{
			if (1)
			{
				//sets.lStat_Msg++;
				sets.bChanged=1;
				sprintf(pop3msg, "+OK %lu octets\015\012",request->mapi_Messages[i-1].len);
				ns.Write(pop3msg, strlen(pop3msg));
				CString sMsgOut=request->mapi_Messages[i-1].headers.c_str();
				ns.Write(sMsgOut.GetBuffer(1), strlen(sMsgOut));
				strcpy(pop3msg, "\015\012\015\012");
				ns.Write(pop3msg, strlen(pop3msg));
				CString sMsgOut2=request->mapi_Messages[i-1].body.c_str();
				if(dwSize!=0){
					int iPos=sMsgOut2.Find("\r\n");
					while(iPos!=-1 && (dwSize-1)){
						iPos+=2;
						iPos=sMsgOut2.Find("\r\n",iPos);
						dwSize--;
					}
					if(iPos!=-1){
						sMsgOut2=sMsgOut2.Left(iPos);
					}
				}
				ns.Write(sMsgOut2.GetBuffer(1), strlen(sMsgOut2));
				strcpy(pop3msg, "\015\012.\015\012");
				ns.Write(pop3msg, strlen(pop3msg));
			}
			else 
			{
				strcpy(pop3msg, "-ERR Error retrieving message\015\012");
				ns.Write(pop3msg, strlen(pop3msg));
			}
		}
		else 
		{
			strcpy(pop3msg, "-ERR No such message\015\012");
			ns.Write(pop3msg, strlen(pop3msg));
		}
	}catch(...){
		_log(0,"retrieve: unknown exception");
		strcpy(pop3msg, "-ERR Internal error (Exception occured)\015\012");
		ns.Write(pop3msg, strlen(pop3msg));
	}
}

void httpmail_retrieve(CMapiStuffClient *request, char *arg, StreamSocket& ns)
{
	char pop3msg[N_BUFFER]={0};
	int iExecutionPos=__LINE__;
	try{
		long i;
		iExecutionPos=__LINE__;
		long visiblecount=request->mapi_Messages.size();
		if ((i = strtoul(arg, NULL, 10)) && (i <= visiblecount) && (i > 0)) 
		{
			if (1)
			{
				CString szMsg;
				iExecutionPos=__LINE__;
				szMsg.Format("POP3: Retrieving message #%i (%s)",i,request->mapi_Messages[i-1].subj.c_str());
				SetTooltipText(szMsg);
				_log(0,szMsg);
				sets.lStat_Msg++;
				sets.bChanged=__LINE__;
				strcpy(pop3msg, "+OK Sending message\015\012");
				iExecutionPos=__LINE__;
				ns.Write(pop3msg, strlen(pop3msg));
				iExecutionPos=__LINE__;
				CString sMsgOut=request->mapi_Messages[i-1].headers.c_str();
				iExecutionPos=__LINE__;
				ns.Write(sMsgOut.GetBuffer(1), strlen(sMsgOut));
				iExecutionPos=__LINE__;
				strcpy(pop3msg, "\015\012\015\012");
				ns.Write(pop3msg, strlen(pop3msg));
				iExecutionPos=__LINE__;
				CString sMsgOut2=request->mapi_Messages[i-1].body.c_str();
				ns.Write(sMsgOut2.GetBuffer(1), strlen(sMsgOut2));
				iExecutionPos=__LINE__;
				strcpy(pop3msg, "\015\012.\015\012");
				ns.Write(pop3msg, strlen(pop3msg));
				iExecutionPos=__LINE__;
			}
			else 
			{
				iExecutionPos=__LINE__;
				strcpy(pop3msg, "-ERR Error retrieving message\015\012");
				ns.Write(pop3msg, strlen(pop3msg));
				iExecutionPos=__LINE__;
			}
		}
		else 
		{
			iExecutionPos=__LINE__;
			strcpy(pop3msg, "-ERR No such message\015\012");
			ns.Write(pop3msg, strlen(pop3msg));
			iExecutionPos=__LINE__;
		}
	}catch(...){
		_log(0,"retrieve: unknown exception (line=%i)",iExecutionPos);
		strcpy(pop3msg, "-ERR Internal error (Exception occured)\015\012");
		ns.Write(pop3msg, strlen(pop3msg));
	}
}

void httpmail_quit(CMapiStuffClient *request, StreamSocket& ns)
{
	if(!sets.lDoNotActDelReceived){
		request->mapi_EnsureMessages(m_MainWnd,1);
	}
}

void httpmail_delete(CMapiStuffClient *request, char *arg, StreamSocket& ns)
{
	char pop3msg[N_BUFFER]={0};
	try{
		long i;
		long visiblecount=request->mapi_Messages.size();
		if ((i = strtoul(arg, NULL, 10)) && (i <= visiblecount) && (i > 0)) 
		{
			request->mapi_Messages[i-1].todelete=true;
			if (request->mapi_Messages[i-1].todelete){
				_log(0,"POP3: Marking message #%i for deletion",i);
				strcpy(pop3msg, "+OK Message deleted\015\012");
				ns.Write(pop3msg, strlen(pop3msg));
			}
			else 
			{
				strcpy(pop3msg, "-ERR Error deleting message\015\012");
				ns.Write(pop3msg, strlen(pop3msg));
			}
		}
		else 
		{
			strcpy(pop3msg, "-ERR No such message\015\012");
			ns.Write(pop3msg, strlen(pop3msg));
		}
	}catch(...){
		_log(0,"delete: unknown exception");
		strcpy(pop3msg, "-ERR Internal error (Exception occured)\015\012");
		ns.Write(pop3msg, strlen(pop3msg));
	}
}

char *gen_uidl(char *dest, const char *source)
{
	int i, j;
	
	for (j = 0, i = strlen(source) - 1; i >= 0 && j < 31; i--, j++)
		dest[j] = (source[i] != '/') ? source[i] : 'Z';
	dest[j] = '\0';
	return dest;
}

void httpmail_uidl(CMapiStuffClient *request, char *arg, StreamSocket& ns)
{
	char pop3msg[N_BUFFER]={0};
	char buffer[N_BUFFER]={0};
	try{
		long i=0;
		char buf[32]={0};
		
		if (!request->listdownloaded)
		{
			httpmail_stat(request, ns);
		}
		long visiblecount=request->mapi_Messages.size();
		if (arg == NULL) 
		{
			strcpy(pop3msg, "+OK\015\012");
			ns.Write(pop3msg, strlen(pop3msg));
			
			for (i = 0; i < visiblecount; i++) 
			{
				_snprintf(buffer, N_BUFFER, "%lu %s\015\012", (i + 1), gen_uidl(buf, request->mapi_Messages[i].sid.c_str()));
				ns.Write(buffer, strlen(buffer));
			}
			strcpy(pop3msg, ".\015\012");
			ns.Write(pop3msg, strlen(pop3msg));
			return;
		}
		if ((i = strtoul(arg, NULL, 10)) && (i <= visiblecount) && (i > 0)) 
		{
			_snprintf(buffer, N_BUFFER, "%lu %s\015\012\015\012", i, gen_uidl(buf, request->mapi_Messages[i-1].sid.c_str()));
			ns.Write(buffer, strlen(buffer));
		} 
		else 
		{
			strcpy(pop3msg, "-ERR No such message\015\012");
			ns.Write(pop3msg, strlen(pop3msg));
		}
	}catch(...){
		_log(0,"uidl: unknown exception");
		strcpy(pop3msg, "-ERR Internal error (Exception occured)\015\012");
		ns.Write(pop3msg, strlen(pop3msg));
	}
}

void smtp_quit(CSmtpRequest* smtpRequest, int argc, char *argv[], const char* szRawInput, StreamSocket& ns)
{
	smtpRequest->smtppass="";
	smtpRequest->smtpuser="";
	smtpRequest->smtpRecip.clear();
	char smtpmsg[N_BUFFER]={0};
	strcpy(smtpmsg, "221 SMTP2MAPI closing transmission channel\015\012");
	ns.Write(smtpmsg, strlen(smtpmsg));
}

#define SMTP_READ_BUF	4048
CString get_input_body(StreamSocket& ns)
{
	char input[SMTP_READ_BUF]={0};
	CString sOut;
	sOut.GetBuffer(SMTP_READ_BUF*100);
	long len = 0;
	while(long(len = ns.Read(input, SMTP_READ_BUF-1))>0){
		input[len]=0;
		sOut += input;
		input[0]=0;
		if(sOut.Right(5)=="\r\n.\r\n"){
			sOut=sOut.Left(sOut.GetLength()-5);
			break;
		}
	}
	return sOut;
}

void smtp_data(CSmtpRequest* smtpRequest, int argc, char *argv[], const char* szRawInput, StreamSocket& ns)
{
	char smtpmsg[N_BUFFER]={0};
	SetTooltipText("Sending message...");
	strcpy(smtpmsg, "354 Receiving message\015\012");
	ns.Write(smtpmsg, strlen(smtpmsg));
	CString sMail=get_input_body(ns);
	if(sMail!="" || smtpRequest->smtpRecip.size()==0){
		HRESULT hres=0;
		bool bRes=false;
		CMapiStuffClient request;
		request.mapi_LoadExchange();
		if (request.mapi_Libraries.size()==0){
			strcpy(smtpmsg, "554 No MAPI found. Check your settings\015\012");
			ns.Write(smtpmsg, strlen(smtpmsg));
		}
		{
			CString sUser=smtpRequest->smtpuser;
			CString sPass=smtpRequest->smtppass;
			if(sets.dwPopBeforeSmtpTime){
				if(GetTickCount()-dwLastOkPop3Login<sets.dwPopBeforeSmtpTime*1000){
					sUser=sLastPop3User;
					sPass=sLastPop3Pass;
				}else{
					strcpy(smtpmsg, "554 Auth failed: Pop before Smtp requred\015\012");
					ns.Write(smtpmsg, strlen(smtpmsg));
					return;
				}
			}else{
				if(sets.sSmtpDefaultProfile!=""){
					sUser=sets.sSmtpDefaultProfile;
				}
			}
			if(sUser==OPT_FROMPOP3){
				sUser=sLastPop3User;
				sPass=sLastPop3Pass;
			}
			if(sUser==OPT_ASKUSER || sUser==OPT_DEFAULT){
				sUser="";
				sPass="";
			}
			request.sLogonProfile=sUser;
			request.sLogonPassword=sPass;
			request.mapi_OpenExchange(EXCH_PURPOSE_SENDMAILS,0,sets.sSmtpDefaultProfile==OPT_ASKUSER);
			if(request.mapi_EnsureSendMsg(m_MainWnd,smtpRequest->smtpRecip,sMail,hres)){
				bRes=true;
				smtp_ok(smtpRequest, 0, 0, 0, ns);
				sets.lStat_Msg++;
			}
		}
		if(!bRes){
			sprintf(smtpmsg, "554 Failed to send message using MAPI (0x%08X). Check MAPI settings\015\012",hres);
			ns.Write(smtpmsg, strlen(smtpmsg));
		}/*else{
			sprintf(smtpmsg, "250 OK\015\012");
			ns.Write(smtpmsg, strlen(smtpmsg));
		}*/
	}else{
		strcpy(smtpmsg, "554 Empty body/reclist not allowed\015\012");
		ns.Write(smtpmsg, strlen(smtpmsg));
	}
}

void smtp_rcpt(CSmtpRequest* smtpRequest, int argc, char *argv[], const char* szRawInput, StreamSocket& ns)
{
	char smtpmsg[N_BUFFER]={0};
	if(argc>0){
		CString sIn=szRawInput;
		CString sTo=CDataXMLSaver::GetInstringPart("TO:","\n",sIn+"\n");
		sTo.TrimLeft(" <>\n\t\r");
		sTo.TrimRight(" <>\n\t\r");
		if(sTo.GetLength()==0){
			sTo=argv[2];
		}
		if(sTo.GetLength()!=0){
			smtpRequest->smtpRecip.push_back(string(sTo));
		}
	}
	strcpy(smtpmsg, "250 OK\015\012");
	ns.Write(smtpmsg, strlen(smtpmsg));
}

void smtp_helo(CSmtpRequest* smtpRequest, int argc, char *argv[], const char* szRawInput, StreamSocket& ns)
{
	smtpRequest->smtppass="";
	smtpRequest->smtpuser="";
	smtpRequest->smtpRecip.clear();
	smtp_ok(smtpRequest, 0, 0, 0, ns);
}

void smtp_rset(CSmtpRequest* smtpRequest, int argc, char *argv[], const char* szRawInput, StreamSocket& ns)
{
	smtpRequest->smtpRecip.clear();
	smtp_ok(smtpRequest, 0, 0, 0, ns);
}

void smtp_ok(CSmtpRequest* smtpRequest, int argc, char *argv[], const char* szRawInput, StreamSocket& ns)
{
	char smtpmsg[N_BUFFER]={0};
	strcpy(smtpmsg, "250 OK\015\012");
	ns.Write(smtpmsg, strlen(smtpmsg));
}
