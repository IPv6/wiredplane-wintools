/*
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 * 02111-1307, USA.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <fcntl.h> 
#include <malloc.h>
#include <string>
#include <errno.h>

#include "../socket.h"

#define N_BUFLEN 1024
#define N_BUFFER 1024
#define N_MYDIR 1024
#define N_MYBUF 1024
#define N_PAIR 1024
#define N_XML_LENGTH 16
#define N_USERNAME 32
#define N_PASSWORD 32

#define PAM_SERVICE_NAME "SmtpPop3"

#define SYSLOGNAME "SmtpPop3"
#define SYSLOGFACILITY LOG_LOCAL7

#ifdef DEBUG
#define DPRINTF(args) printf( args)
#else
#define DPRINTF(args)
#endif

/* the OpenBSD strlcpy/strlcat functions */
size_t strlcpy(char *, const char*, size_t);
size_t strlcat(char *, const char*, size_t);

/* httpmail_ functions */
#include "..\MSMapi\MapiStuffClient.h"
void httpmail_quit(CMapiStuffClient *request, StreamSocket& ns);
int httpmail_authenticate_user(CMapiStuffClient *request, char *, char *, StreamSocket& ns, std::string& error);
void httpmail_init(CMapiStuffClient *request, StreamSocket& ns);
void httpmail_stat(CMapiStuffClient *request, StreamSocket& ns);
void httpmail_list(CMapiStuffClient *request, char *, StreamSocket& ns);
void httpmail_rset(CMapiStuffClient *request, StreamSocket& ns);
void httpmail_retrieve(CMapiStuffClient *request, char *, StreamSocket& ns);
void httpmail_delete(CMapiStuffClient *request, char *, StreamSocket& ns);
char *gen_uidl(char *, char *);
void httpmail_uidl(CMapiStuffClient *request, char *, StreamSocket& ns);
void httpmail_top(CMapiStuffClient *request, char *, long, StreamSocket& ns);
void smtp_quit(CSmtpRequest* smtpRequest, int argc, char *argv[], const char* szRawInput, StreamSocket& ns);
void smtp_data(CSmtpRequest* smtpRequest, int argc, char *argv[], const char* szRawInput, StreamSocket& ns);
void smtp_rcpt(CSmtpRequest* smtpRequest, int argc, char *argv[], const char* szRawInput, StreamSocket& ns);
void smtp_ok(CSmtpRequest* smtpRequest, int argc, char *argv[], const char* szRawInput, StreamSocket& ns);
void smtp_rset(CSmtpRequest* smtpRequest, int argc, char *argv[], const char* szRawInput, StreamSocket& ns);
void smtp_helo(CSmtpRequest* smtpRequest, int argc, char *argv[], const char* szRawInput, StreamSocket& ns);
void main_loopPop3(StreamSocket& ns);
void main_loopSmtp(StreamSocket& ns);
