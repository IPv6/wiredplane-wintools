#ifndef CONVERTERSESSION_H_INCLUDED
#define CONVERTERSESSION_H_INCLUDED

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <windows.h>
//#include <objidl.h>
//#include <malloc.h>
//#include <assert.h>
#include <comdef.h>
//#include <Guiddef.h>


#if !defined(INITGUID) || defined(USES_IID_IConverterSession)
// {4e3a7680-b77a-11d0-9da5-00c04fd65685} 
DEFINE_GUID(CLSID_IConverterSession, 0x4e3a7680, 0xb77a, 0x11d0, 0x9d, 0xa5, 0x0, 0xc0, 0x4f, 0xd6, 0x56, 0x85); 
// {4b401570-b77b-11d0-9da5-00c04fd65685} 
DEFINE_GUID(IID_IConverterSession, 0x4b401570, 0xb77b, 0x11d0, 0x9d, 0xa5, 0x0, 0xc0, 0x4f, 0xd6, 0x56, 0x85);
#endif // #if !defined(INITGUID) || defined(USES_IID_IConverterSession)

typedef enum tagENCODINGTYPE {
    IET_BINARY = 0,
    IET_BASE64 = 1,
    IET_UUENCODE = 2,
    IET_QP = 3,
    IET_7BIT = 4,
    IET_8BIT = 5,
    IET_INETCSET = 6,
    IET_UNICODE = 7,
    IET_RFC1522 = 8,
    IET_ENCODED = 9,
    IET_CURRENT = 10,
    IET_UNKNOWN = 11,
    IET_BINHEX40 = 12,
    IET_LAST = 13
} ENCODINGTYPE;

typedef enum tagCCSF
{
    CCSF_SMTP      = 0x0002,
    CCSF_NOHEADERS = 0x0004,
    CCSF_NO_MSGID  = 0x4000,
} CCSF;

class __declspec(uuid("4e3a7680-b77a-11d0-9da5-00c04fd65685")) CConverterSession;
/*#define CLSID_IConverterSession __uuidof(CConverterSession)*/
interface __declspec(uuid("4b401570-b77b-11d0-9da5-00c04fd65685")) IConverterSession;
_COM_SMARTPTR_TYPEDEF(IConverterSession,__uuidof(IConverterSession));
/*#define IID_IConverterSession __uuidof(IConverterSession)*/

/**
* Allows conversions between MIME objects and MAPI messages. 
* This can be useful in transporting messages across the Internet.
*
* @remarks Only these methods are supported in this interface: 
*
* IConverterSession::SetEncoding, IConverterSession::MAPIToMIMEStm, 
* and IConverterSession::MIMEToMAPI. 
*
* Call SetEncoding before using the other methods to perform conversion. 
*/
interface IConverterSession : public IUnknown
{
private:
    STDMETHOD(placeholder0)() PURE;
public:
    /**
    * Initializes the encoding to be used during conversion.
    *
    * @retval E_INVALIDARG The encoding type passed was invalid.
    */
    STDMETHOD(SetEncoding)(
        /**
        * An ENCODINGTYPE value. Only the following values are supported:
        *
        * IET_BASE64, IET_UUENCODE, IET_QP, IET_7BIT, IET_8BIT
        */
        ENCODINGTYPE et) PURE;

private:
    STDMETHOD(placeholder2)() PURE;
public:
    /**
    * Converts a MIME stream to a MAPI message.
    *
    * @retval E_INVALIDARG pstm is NULL, pmsg is NULL,
    *                      or ulFlags is invalid.
    */
    STDMETHOD(MIMEToMAPI)(
        /** [in] IStream interface to a MIME stream. */
        LPSTREAM pstm,
        /** [out] Pointer to the message to load. */
        LPMESSAGE pmsg,
        /** [in] This value must be NULL. */
        LPCSTR pszSrcSrv,
        /** [in] Flags. Zero (0) is the only supported value. */
        ULONG ulFlags) PURE;
    /**
    * Converts a MAPI message to a MIME stream.
    *
    * @retval E_INVALIDARG Invalid flags were passed,
    *                      or pmsg or pstm is NULL.
    *
    * @remarks Supported only for standard Outlook message types.
    */
    STDMETHOD(MAPIToMIMEStm)(
        /** [in] Pointer to the message to convert. */
        LPMESSAGE pmsg,
        /** [out] IStream interface to output the stream. */
        LPSTREAM pstm,
        /** [in] A flag of one of the following types:
        *  CCSF_NO_MSGID
        *    Do not include Message-Id field in outgoing messages.
        *  CCSF_NOHEADERS
        *    The converter should ignore the headers of the outside message. 
        *  CCSF_SMTP
        *    The converter is being passed an SMTP message.
        */
        ULONG ulFlags) PURE;
    STDMETHOD(placeholder5)() PURE;
    STDMETHOD(placeholder6)() PURE;
    STDMETHOD(placeholder7)() PURE;
    STDMETHOD(SetTextWrapping)(BOOL fWrapText,ULONG ulWrapWidth);
    STDMETHOD(placeholder9)() PURE;
    STDMETHOD(placeholder10)() PURE;
    STDMETHOD(placeholder11)() PURE;
}; 


/*
Friday, April 22, 2005, 15:37:28, you wrote:
|Smitha> I am programatically sending a mail from Outlook(using Ex
|Smitha> MAPI). How can I set custom Internet headers using Ex-MAPI
|Smitha> for this mail?

Take MAPI_GetCreateCustomSmtpHeaderTag() to get the custom header prop
ID and set a value using

IMessage* pMsg;
unsigned long ulPropId;
// ...
MAPI_GetCreateCustomSmtpHeaderTag(pMsg, "X-Smitha-Was-Here", &ulPropId,
true);
SPropValue CustomProp;
CustomProp.ulPropTag=ulPropId;
CustomProp.Value.lpszA="Yeah!";
HrSetOneProp(pMsg, &CustomProp);
// use MAPI_WritePropStream() (see below) if the prop is longer
pMsg->SaveChanges(KEEPOPENREADWRITE?

HRESULT MAPI_GetCreateCustomSmtpHeaderTag(IMAPIProp* pProp, const char*
pcszHeader, unsigned long* pulPropID, bool bCreate)
{
  assert(pProp);
  assert(pcszHeader);
  assert(pulPropID);
  HRESULT hRes;
  WCHAR *pwszHeader=NULL;
  static const GUID GUID_CUSTOM_SMTP_HEADER={0x00020386, 0x0000, 0x0000,
{0xC0, 0x00, 0x0, 0x00, 0x00, 0x00, 0x00, 0x046}};
  _SPropTagArray* lpSmtpHeaderPropTag=NULL;

  try
  {
    char2wstr(pcszHeader, &pwszHeader);
    MAPINAMEID SMTPHeaderMNID={(GUID*)&GUID_CUSTOM_SMTP_HEADER,
MNID_STRING, (LONG)pwszHeader};
    MAPINAMEID *rgpnameid[1]={&SMTPHeaderMNID};
    if(FAILED(hRes=pProp->GetIDsFromNames(1, rgpnameid,
bCreate?MAPI_CREATE:0, &lpSmtpHeaderPropTag))) throw hRes;
    *pulPropID=PROP_ID(lpSmtpHeaderPropTag->aulPropTag[0]);
  } // try
  catch(HRESULT hr)
  {
    hRes=hr;
  } // catch(HRESULT hr)
  if(pwszHeader) delete[] pwszHeader;
  if(lpSmtpHeaderPropTag) MAPIFreeBuffer(lpSmtpHeaderPropTag);
  return hRes;
}

HRESULT MAPI_WritePropStream(IMAPIProp* pProp, unsigned long ulProp, const
void* pv, unsigned long ulLen)
{
  assert(pProp);
  assert(PT_STRING8==PROP_TYPE(ulProp) || PT_UNICODE==PROP_TYPE(ulProp) ||
PT_BINARY==PROP_TYPE(ulProp)); // only strings and binary data are valid
for streaming
  assert(pv);
  
  HRESULT hRes=S_OK;
  IStream* pStream=NULL;
  unsigned long ul, ulWritten=0;
  
  try
  {
    if(FAILED(hRes=pProp->OpenProperty(ulProp, &IID_IStream, STGM_WRITE,
MAPI_CREATE|MAPI_MODIFY, (IUnknown**)&pStream))) throw hRes;
    while(ulLen)
    {
      ul=min((unsigned long)MAPI_CHUNK, ulLen);
      if(FAILED(hRes=pStream->Write(pv, ul, &ulWritten))) throw hRes;
      if(ulWritten!=ul) throw (long)ERROR_INVALID_BLOCK_LENGTH;
      pv=(void*)((char*)pv+ul);
      ulLen-=ul;
    } // while(ulLen)
    if(FAILED(hRes=pStream->Commit(STGC_DEFAULT))) throw hRes;
  }
  catch(HRESULT hr)
  {
    hRes=hr;
  }
  
  if(pStream) pStream->Release();
  return hRes;
}
*/
#endif // #ifndef CONVERTERSESSION_H_INCLUDED
