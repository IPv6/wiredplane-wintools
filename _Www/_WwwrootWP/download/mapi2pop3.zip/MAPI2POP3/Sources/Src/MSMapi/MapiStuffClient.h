// MapiStuffClient.h : Declaration of the CMapiStuffClient

#ifndef __MapiStuffCLIENT_H_
#define __MapiStuffCLIENT_H_

#include <shellapi.h>
#include <mapix.h>
#include <mapiutil.h>
#include <mspst.h>
#include <string>
#include <list>
#include <vector>
#include <map>

//#include "resource.h"       // main symbols
#include "afxmt.h"

/////////////////////////////////////////////////////////////////////////////
// CMapiStuffClient
class mapi_TEntryid
{
public:
	unsigned int size;
	ENTRYID *ab;
	mapi_TEntryid(){ab=0;size=0;}
	mapi_TEntryid(SPropValue *v) {ab=0;size=0; if (v->ulPropTag!=PR_ENTRYID) return; set(v->Value.bin.cb,(ENTRYID*)v->Value.bin.lpb);}
	mapi_TEntryid(const mapi_TEntryid &e) {ab=0;size=0; set(e.size,e.ab);}
	mapi_TEntryid(unsigned int asize,ENTRYID *eid) {ab=0;size=0; set(asize,eid);}
	mapi_TEntryid &operator= (const mapi_TEntryid *e) {set(e->size,e->ab); return *this;}
	mapi_TEntryid &operator= (const SPropValue *v) {set(0,0); if (PROP_TYPE(v->ulPropTag)!=PT_BINARY) return *this; set(v->Value.bin.cb,(ENTRYID*)v->Value.bin.lpb); return *this;}
	~mapi_TEntryid() {set(0,0);}
	void set(unsigned int asize, ENTRYID *eid) {if (ab!=0) delete[] ((char*)ab); size=asize; if (eid==0) ab=0; else {ab=(ENTRYID*)(new char[size]);memcpy(ab,eid,size);}}
	void clear() {set(0,0);}
	bool isempty() const {return (ab==0 || size==0);}
	std::string getSid()
	{
		std::string result;
		BYTE* pc=(BYTE*)ab;
		for(int i=0;i<size;i++) 
		{ // convert md to hex-represented string (hex-letters in upper case!)
			CString sHex;
			sHex.Format("%02x",(*pc));
			result += sHex;
			pc++;
		}
		return result;
	}
	bool isequal(IMAPISession *sesh, mapi_TEntryid const &e) const
	{ 
		if (isempty() || e.isempty()) 
			return false;
		ULONG res;
		HRESULT hr = sesh->CompareEntryIDs(size,ab,e.size,e.ab,0,&res);
		if (hr!=S_OK) 
			return false;
		return (res!=0);
	}
};

typedef struct { std::string name, path; bool supported;} mapi_TLibraryInfo;
enum mapi_TFolderType {mftInbox,mftOutbox,mftSent,mftDeleted,mftCalendar,mftContacts,mftJournal,mftNotes,mftTasks,mftSpecial,mftMail,mftStuff};
typedef struct {int depth; std::string name, path; mapi_TFolderType type; mapi_TEntryid eid;} mapi_TFolderInfo; // nb. path is the complete thing, and name is just the final bit of it
typedef struct {mapi_TEntryid eid;long len; bool todelete; std::string sid; std::string headers; std::string body;std::string subj; std::string date;} mapi_TMessageInfo;
enum mapi_TStoreType {mstProfile, mstProfileSecret, mstStore};
typedef struct { std::string profile, store; mapi_TStoreType type;} mapi_TStoreInfo;
typedef HRESULT (STDMETHODCALLTYPE RTFSYNC)(LPMESSAGE lpMessage, ULONG ulFlags, BOOL FAR *lpfMessageUpdated);
typedef HRESULT (STDMETHODCALLTYPE WRAPCOMPRESSEDRTFSTREAM)(LPSTREAM lpCompressedRTFStream, ULONG ulFlags, LPSTREAM FAR *lpUncompressedRTFStream);
//typedef HRESULT (STDMETHODCALLTYPE MAPISETONEPROP)(LPMAPIPROP lpMapiProp,LPSPropValue lpProp);
typedef void (STDMETHODCALLTYPE FREEPADRLIST)(LPADRLIST lpAdrlist);

#define RET_NOPROFILE	-100
#define EXCH_PURPOSE_GETMAILS		1
#define EXCH_PURPOSE_SENDMAILS		0
#define EXCH_PURPOSE_GETPROFILES	-1

class CSmtpRequest
{
public:
	std::vector<std::string> smtpRecip;
	CString smtpuser;
	CString smtppass;
};

class CMapiStuffClient
{
public:
	static bool got_libraries;
	int iPop3State;
	int listdownloaded;
	int iPop3Timeout;// Currently unused!
	bool bLoadingTimeout;
	CCriticalSection csMAPIGuard;
	long lMailLoading;
	BOOL bSelfDelete;
	char szPop3Username[2048];
	
	CMapiStuffClient()
	{
		szPop3Username[0]=0;
		iPop3Timeout=0;
		iPop3State=0;
		listdownloaded=0;
		bLoadedOK=0;
		bLoadingTimeout=false;
		hmapilib=0;
		got_libraries=false;                // have we built that list yet?
		maildrop_size=0;
		mapi_lib_path="";             // this is the pathname of what we've currently loaded.
		pMAPIAdminProfiles=0;
		pMAPIUninitialize=0;
		pMAPILogonEx=0;
		pMAPIFreeBuffer=0;
		pMAPIAllocateBuffer=0;
		pRTFSync=0;
		pWrapCompressedRTFStream=0;
		lMailLoading=0;
		bSelfDelete=0;
		//
		mapi_session=0;     // The session
		mapi_session_profile="";      // This is the profile name which session is logged onto.
		mapi_msgstore=0;       // The message store
		mapi_msgstore_name="";        // This is the name to which that message-store refers
		got_eids = false;             // a shortcut for whether or not all the following have been set
	}
	~CMapiStuffClient()
	{
		mapi_UnloadExchange();
	}
	//*****************//
public:
	int bLoadedOK;
	std::string user;
	std::string pass;
	static std::list<mapi_TLibraryInfo> mapi_Libraries;
	// ������� ����� 2
	BOOL mapi_LoadExchange();
	void mapi_UnloadExchange();
	BOOL mapi_OpenExchange(BOOL iPurpose, std::list<std::string>* pOutProfiles=0, BOOL bForceAskForProfile=FALSE);
	BOOL mapi_EnsureFolders(HWND h, const std::string profile, const std::string store, BOOL bNoMail=0);
	BOOL mapi_EnsureMessages(HWND h, BOOL bRetrieveOrDelete);
	HRESULT mapi_ForcePlaintext(IMessage *pMessage);
	BOOL mapi_retrMessage(IMessage *imsg,mapi_TMessageInfo& msg);
	bool mapi_EnsureSendMsg(HWND h,std::vector<std::string>& smtpRecip,const char* sMail, HRESULT& hr);
	HRESULT AddRecipientsFromList(std::vector<std::string>&,IMessage* &pMsg, CString& sCC, CString& sBCC);
	HRESULT AddPersonToEmail(IMessage* pMsg,const char* szEmail,long lRecipType,long lModifyType);
	bool isrtfhtml(const char *buf,unsigned int len);
	void decodertfhtml(char *buf,unsigned int *len);
	HRESULT mapi_AddOneOff(IAddrBook* pAdrBook, IMessage* pMsg, char* pszDisplayName, char* pszEmailAddress, char* pszAddrType, long lRecipientType);
	HRESULT mapi_WritePropStream(IMAPIProp* pProp, unsigned long ulProp, const void* pv, unsigned long ulLen);
	HRESULT pHrSetOneProp(LPMAPIPROP lpMapiProp,LPSPropValue lpProp);
	// These are initialized by mapi_OpenExchange(lib)
	std::list<mapi_TStoreInfo> mapi_Stores;
	// And so are these mapi functions
	// These are initialized by mapi_EnsureFolders(storeinfo)
	std::list<mapi_TFolderInfo> mapi_Folders;
	std::vector<mapi_TMessageInfo> mapi_Messages;
	HINSTANCE hmapilib;             // for loadlibrary(mapi32.dll). If this is non-null, we must freelibrary it at the end.
	std::string mapi_lib_path;             // this is the pathname of what we've currently loaded.
	//
	MAPIADMINPROFILES *pMAPIAdminProfiles;
	MAPIUNINITIALIZE *pMAPIUninitialize;
	MAPILOGONEX *pMAPILogonEx;
	MAPIFREEBUFFER *pMAPIFreeBuffer;
	MAPIALLOCATEBUFFER *pMAPIAllocateBuffer;
	FREEPADRLIST *pFreePadrlist;
	//MAPISETONEPROP *pHrSetOneProp;
	RTFSYNC *pRTFSync;
	WRAPCOMPRESSEDRTFSTREAM *pWrapCompressedRTFStream;
	long maildrop_size;
	//
	IMAPISession *mapi_session;     // The session
	std::string mapi_session_profile;      // This is the profile name which session is logged onto.
	IMsgStore *mapi_msgstore;       // The message store
	std::string mapi_msgstore_name;        // This is the name to which that message-store refers
	bool got_eids;             // a shortcut for whether or not all the following have been set
	mapi_TEntryid eid_inbox, eid_outbox, eid_sent, eid_deleted;
	mapi_TEntryid eid_calendar, eid_contacts, eid_journal, eid_notes, eid_tasks;
	std::string mapi_RegQueryString(HKEY key,const std::string name);
	// And all are freed, if necessary, by mapi_EnsureFinished.
	// I must implement these utility functions myself. That's because
	// they're not present in Outlook97's version of mapi32.dll.
	HRESULT pHrGetOneProp(LPMAPIPROP lpMapiProp, ULONG ulPropTag, LPSPropValue FAR *lppProp);
	void pFreeProws(LPSRowSet lpRows);
	HRESULT pHrQueryAllRows(LPMAPITABLE lpTable, LPSPropTagArray lpPropTags, LPSRestriction lpRestriction, LPSSortOrderSet lpSortOrderSet, LONG crowsMax, LPSRowSet FAR *lppRows);
	HRESULT SetReplyTo(LPMESSAGE lpMessage, LPSTR pszReplyTo);
	std::list<std::string> mapi_RegQuerySubkeys(HKEY key);
	void mapi_RecEnsureFolders(IMAPIFolder *parent, int depth, std::string prefix, std::list<mapi_TFolderInfo> *folders);
	void mapi_EnsureCrazyProfileDeleted(IProfAdmin *iprofadmin);
	mapi_TFolderType mapi_GetFolderType(mapi_TEntryid &eid, IMAPIFolder *f);
	void mapi_EnsureCommonEids();
	std::string sLogonProfile;
	std::string sLogonPassword;
	std::string sDefaultProfile;
	std::string sRestrictToProfile;
	std::string sRestrictToStore;
	std::string sRestrictToFolder;
};

class SimpleLocker
{
	CSyncObject* m_pObject;
public:
	SimpleLocker(CSyncObject* pObject)
	{
		m_pObject=pObject;
		m_pObject->Lock();
	};
	~SimpleLocker()
	{
		m_pObject->Unlock();
	};
	void lock()
	{
		m_pObject->Lock();
	};
	void unlock()
	{
		m_pObject->Unlock();
	};
};

#endif //__MapiStuffCLIENT_H_
