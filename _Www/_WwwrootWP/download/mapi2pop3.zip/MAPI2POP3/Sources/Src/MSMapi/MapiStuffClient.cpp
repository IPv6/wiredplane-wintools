// MapiStuffClient.cpp : Implementation of CMapiStuffClient
#include "stdafx.h"
#include "MapiStuffClient.h"
#include "..\common.h"
#include "CharsetDecoder.h"


// � 7�� ������
#ifndef _NO_EXXTRAINITS_FORVC6
//#define USES_IID_IMessage
//#define USES_IID_IMAPIProp
//#include <mapiguid.h>
#include <initguid.h>
DEFINE_OLEGUID(IID_IMAPIProp,		0x00020303, 0, 0);
DEFINE_OLEGUID(IID_IMessage,		0x00020307, 0, 0);
#endif

// These were omitted from the standard headers
#ifndef PR_MSG_EDITOR_FORMAT 
#define PR_MSG_EDITOR_FORMAT PROP_TAG( PT_LONG, 0x5909 )
#define EDITOR_FORMAT_DONTKNOW ((ULONG)0) 
#define EDITOR_FORMAT_PLAINTEXT ((ULONG)1) 
#define EDITOR_FORMAT_HTML ((ULONG)2) 
#define EDITOR_FORMAT_RTF ((ULONG)3) 
#endif

//0x3FDE0003
#ifndef PR_INTERNET_CPID
#define PR_INTERNET_CPID (PROP_TAG(PT_LONG,0x3FDE))
#endif

#ifndef PR_CREATOR_ENTRYID
#define PR_CREATOR_ENTRYID (PROP_TAG(PT_BINARY,0x3FF9))
#endif

#ifndef PR_CREATOR_NAME
#define PR_CREATOR_NAME (PROP_TAG(PT_TSTRING,0x3FF8))
#endif

#ifndef PR_BODY_HTML
#define PR_BODY_HTML (PROP_TAG(PT_TSTRING,0x1013))
#endif

#ifndef PR_HAS_NAMED_PROPERTIES
#define PR_HAS_NAMED_PROPERTIES (PROP_TAG(PT_BOOLEAN,0x664a))
#endif

#ifndef PR_SentRepresentingFlags
#define PR_SentRepresentingFlags (PROP_TAG(PT_LONG,0x401A))
#endif

#ifndef PR_SenderFlags
#define PR_SenderFlags (PROP_TAG(PT_LONG,0x4019))
#endif

//0x3FFD0003
#ifndef PR_MESSAGE_CODEPAGE
#define PR_MESSAGE_CODEPAGE (PROP_TAG(PT_LONG,0x3FFD))
#endif

//0x1035001E
#ifndef PR_INTERNET_MESSAGE_ID
#define PR_INTERNET_MESSAGE_ID (PROP_TAG(PT_TSTRING,1035))
#endif

#ifndef PR_ATTACH_CONTENT_ID
#define PR_ATTACH_CONTENT_ID (PROP_TAG(PT_TSTRING,0x3712))
#endif

#ifndef PR_ATTACH_CONTENT_LOCATION
#define PR_ATTACH_CONTENT_LOCATION (PROP_TAG(PT_TSTRING,0x3713))
#endif

#ifndef PR_ATTACH_FLAGS
#define PR_ATTACH_FLAGS (PROP_TAG(PT_LONG,0x3714))
#endif

#ifndef PR_NT_SECURITY_DESCRIPTOR
#define PR_NT_SECURITY_DESCRIPTOR (PROP_TAG(PT_BINARY,0x0E27))
#endif

#ifndef PR_ATTACH_TRANSPORT_NAME
#define PR_ATTACH_TRANSPORT_NAME (PROP_TAG(PT_TSTRING,0x370C))
#endif

#ifndef PR_ATTACH_MIME_SEQUENCE
#define PR_ATTACH_MIME_SEQUENCE (PROP_TAG(PT_LONG,0x3710))
#endif

#ifndef PR_SMTP_MESSAGE_ID
#define PR_SMTP_MESSAGE_ID (PROP_TAG(PT_TSTRING,0x1035))
#endif



struct CPS{const char* szN;long l;};
static CPS ps[]={
		{"iso-8859-6",      28596},
		{"windows-1256",    1256},
		{"iso-8859-4",      28594},
		{"windows-1257",    1257},
		{"iso-8859-2",      28592},
		{"windows-1250",    1250},
		{"gb2312",          936},
		{"hz-gb-2312",      52936},
		{"big5",            950},
		{"iso-8859-5",      28595},
		{"koi8-r",          20866},
		{"koi8-u",          21866},
		{"windows-1251",    1251},
		{"iso-8859-7",      28597},
		{"windows-1253",    1253},
		{"iso-8859-8-i",    38598},
		{"windows-1255",    1255},
		{"euc-jp",          51932},
		{"iso-2022-jp",     50220},
		{"csISO2022JP",     50221},
		{"iso-2022-jp",     932},
		{"ks_c_5601-1987",  949},
		{"euc-kr",          51949},
		{"iso-8859-3",      28593},
		{"iso-8859-15",     28605},
		{"windows-874",     874},
		{"iso-8859-9",      28599},
		{"windows-1254",    1254},
		{"utf-7",           65000},
		{"utf-8",           65001},
		{"us-ascii",        20127},
		{"windows-1258",    1258},
		{"iso-8859-1",      28591},
		{"Windows-1252",    1252},
		{0,    0}
	};
	
CString toString(const char* szFormat,...);
long GetCPCodeByName(const char* szCP)
{
	CPS* p=ps;
	while(p && p->szN!=0){
		if(stricmp(p->szN,szCP)==0){
			return p->l;
		}
		p++;
	}
	return 0;
}

const char* GetCPCodeByCode(long lCP)
{
	CPS* p=ps;
	while(p && p->szN!=0){
		if(p->l==lCP){
			return p->szN;
		}
		p++;
	}
	return 0;
}

extern CSettings sets;
std::string RemoveHeader(std::string& header, std::string name)
{
	std::string res;
	CString sHeaderLow=header.c_str();
	sHeaderLow.MakeLower();
	CString sNameLow=name.c_str();
	sNameLow.MakeLower();
	int iLen=header.size();
	if(iLen>0 ){
		int iPos1=sHeaderLow.Find(sNameLow+": ");
		if(iPos1!=0){
			iPos1=sHeaderLow.Find(CString("\r\n")+sNameLow+": ");
			if(iPos1!=-1){
				iPos1+=2;
			}
		}
		if(iPos1!=-1){
			int iPos2=header.find("\r\n",iPos1);
			if(iPos2!=-1){
				int iTextStart=iPos1+name.size()+2;
				res=header.substr(iTextStart,iPos2-iTextStart);
				header=header.substr(0,iPos1)+header.substr(iPos2+2);
			}
		}
	}
	return res;
}

bool AddHeader(std::string& header, std::string name, const char* vale)
{
	int iLen=header.size();
	if(iLen>1 && header[iLen-1]!='\r' && header[iLen-1]!='\n'){
		header+="\r\n";
	}
	header+=name;
	header+=": ";
	header+=vale;
	header+="\r\n";
	return true;
}

// unused
void KillOutlookPopup(void* pDummy)
{
	while(TRUE)
	{
		::Sleep(50);
		HWND hOutlook = ::FindWindowEx(NULL, NULL, _T("#32770"), _T("Microsoft Outlook"));
		if(hOutlook)
		{
			HWND hYes = ::FindWindowEx(hOutlook, NULL, _T("Button"), _T("&Yes"));
			if(hYes)
			{
				::EndDialog(hOutlook, ::GetDlgCtrlID(hYes));
			}
		}
	}
}


// the maximal number of attachment files
#define XY_MAX_ATTACHMENT 100

// helper function: GetTimeStamp
// return the timestamp string with the following format 
// to be used in the log file: 'yyyymmddHHMMSS(thread id)'
static CString GetTimeStamp()
{
	SYSTEMTIME sysTime;
	GetLocalTime(&sysTime);
	CString strRet;
	strRet.Format(_T("%04d%02d%02d%02d%02d%02d(%ld)"),sysTime.wYear,sysTime.wMonth,sysTime.wDay,sysTime.wHour,sysTime.wMinute,sysTime.wSecond,::GetCurrentThreadId());
	return strRet;
}

// helper function: Quote
// protect the special characters '<', '>', '/', and '\'
// in the input string
static CString Quote(const CString& strInput)
{
	int nSize = strInput.GetLength();
	CString strOutput;
	TCHAR* pOutput = strOutput.GetBuffer(2*nSize);
	for(int i=0,j=0;i<nSize;i++,j++)
	{
		switch(strInput[i])
		{
		case '<':
		case '/':
		case '>':
		case '\\':
			pOutput[j++] = '\\';
			break;
		default:
			break;
		}
		pOutput[j] = strInput[i];
	}
	strOutput.ReleaseBuffer(j);
	return strOutput;
}

// helper function: UnQuote
// exactly the opposite of Quote
static CString UnQuote(const CString& strInput)
{
	int nSize = strInput.GetLength();
	CString strOutput;
	TCHAR* pOutput = strOutput.GetBuffer(nSize);
	for(int i=0,j=0;i<nSize;i++,j++)
	{
		if(strInput[i]=='\\')
		{
			if(i<nSize-1)
			{
				switch(strInput[i+1])
				{
				case '<':
				case '/':
				case '>':
				case '\\':
					i++;
					break;
				default:
					break;
				}
			}
		}
		pOutput[j] = strInput[i];
	}
	strOutput.ReleaseBuffer(j);
	return strOutput;
}

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
#include <windows.h>
#include <shellapi.h>
#include <mapix.h>
#include <mapiutil.h>
#include <mspst.h>
#include <string>
#include <list>
#include <map>
using namespace std;
list<mapi_TLibraryInfo> CMapiStuffClient::mapi_Libraries;  // from the registry, a list of ex-mapi dlls
bool CMapiStuffClient::got_libraries=false;
/*
void mapi_EnsureCommonEids();
mapi_TFolderType mapi_GetFolderType(mapi_TEntryid &eid, IMAPIFolder *f);
void mapi_RecEnsureFolders(IMAPIFolder *parent, int depth, string prefix, list<mapi_TFolderInfo> *folders);
void mapi_EnsureCrazyProfileDeleted(IProfAdmin *iprofadmin);
list<string> mapi_RegQuerySubkeys(HKEY key);
string mapi_RegQueryString(HKEY key,const string name);
*/
// mapi_LoadExchange -- builds up a list of all the Extended MAPI libraries
// that have been installed on this machine, in the global mapi_Libraries
// list. This is a difficult task...
// In the olden days, there didn't exist such a list anywhere on the system.
// Very recently (with the advent of Outlook XP) it has introduced the
// idea that there should be a list under HKEY_LOCAL_MACHINE\Clients\Mail
// whereby every extended-MAPI is indicated with a "DLLPathEx" value.
// But in the olden days (with Outlook2000 in both IMO and CWG modes, and
// with Outlook97) it merely has a "DLLPath" value.
// So our plan is as follows:
// (1) For any DLLPathEx keys, we'll add them.
// (2) If one of those DLLPathEx happened to be for the "Microsoft Outlook"
// service, then it must have been XP or later, and so we can return immediately.
// (3) If Microsoft Outlook was not even installed (i.e. not in the list), then we
// can also return immediately.
// (4) Otherwise, there must have been Outlook97 or 2000 installed. So we
// will set a key under HKEY_LOCAL_MACHINE\SOFTWARE\Microsft\Windows Messaging Subsystem\MSMapiApps
// to indicate that our app will use the "Microsoft Outlook" mapi. Then, we
// add "mapi32.dll" into the list. On a modern system, when you LoadLibrary(mapi32.dll),
// this is merely a stubb: it actually looks into that list and figures out which mapi
// to use from there. Therefore, this will end up loading Outlook.
//
BOOL CMapiStuffClient::mapi_LoadExchange()
{
	if (got_libraries){
		return 1;
	}
	got_libraries=true;
	//
	// First, if the mapi stub has been installed, then we can check in the
	// registry for which MAPI libraries are present on this machine.
	bool uses_stub=false, IsOutlookInstalled=false, IsOutlookExListed=false;
	HKEY key; LONG res;
	res = RegOpenKeyEx(HKEY_LOCAL_MACHINE,"SOFTWARE\\Clients\\Mail",0,KEY_READ,&key);
	if (res==ERROR_SUCCESS){
		uses_stub=true;
		string defname = mapi_RegQueryString(key,"");   // Find out which one is the default
		list<string> names = mapi_RegQuerySubkeys(key); // Get the list of child keys
		RegCloseKey(key);
		for (list<string>::const_iterator i=names.begin(); i!=names.end(); i++){
			string name = *i;
			bool thisisoutlook = (name=="Microsoft Outlook");
			IsOutlookInstalled |= thisisoutlook;
			res = RegOpenKeyEx(HKEY_LOCAL_MACHINE,("SOFTWARE\\Clients\\Mail\\"+name).c_str(),0,KEY_READ,&key);
			if (res==ERROR_SUCCESS)
			{
				// Get the path, stored in "DLLPathEx"
				string path = mapi_RegQueryString(key,"DLLPathEx");
				if (path!="")
				{
					if (thisisoutlook) IsOutlookExListed=true;
					mapi_TLibraryInfo lib; lib.name=name; lib.path=path; lib.supported=true;
					if (name==defname) 
						mapi_Libraries.push_front(lib); 
					else 
						mapi_Libraries.push_back(lib);
				}
				RegCloseKey(key);
			}
		}
	}
	if (IsOutlookInstalled && IsOutlookExListed)
		return 1; // outlook XP is fine as it is.
	//
	// If it uses the stub technique, and Outlook is installed, we can set the registry
	// key to tell the stub to give us outlook
	if (uses_stub && IsOutlookInstalled){
		res = RegOpenKeyEx(HKEY_LOCAL_MACHINE,"SOFTWARE\\Microsoft\\Windows Messaging Subsystem\\MSMapiApps",0,KEY_SET_VALUE,&key);
		if (res!=ERROR_SUCCESS)
			return 1;
		char c[MAX_PATH]; GetModuleFileName(NULL,c,MAX_PATH);
		const char *d=c+strlen(c)-1;
		while (d>c && *d!='/' && *d!='\\' && *d!=':'){
			d--;
		}
		if (*d=='/' || *d=='\\' || *d==':'){
			d++;
		}
		res = RegSetValueEx(key,d,0,REG_SZ,(LPBYTE)"Microsoft Outlook",18);
		RegCloseKey(key);
		if (res!=ERROR_SUCCESS)
			return 1;
		mapi_TLibraryInfo outlib; outlib.name="Microsoft Outlook"; outlib.path="mapi32.dll";
		mapi_Libraries.push_back(outlib);
	}
	//
	// Otherwise, if it doesn't even use the stub, then we'll use the old-fashioned technique.
	if (!uses_stub){
		res = RegOpenKeyEx(HKEY_LOCAL_MACHINE,"SOFTWARE\\Microsoft\\Windows Messaging Subsystem",0,KEY_READ,&key);
		if (res!=ERROR_SUCCESS)
			return 1;
		DWORD type=0; DWORD size=10; char c[10]={0};
		res = RegQueryValueEx(key,"MAPIX",NULL,&type,(LPBYTE)c,&size);
		RegCloseKey(key);
		if (res!=ERROR_SUCCESS)
			return 1;
		if (strcmp(c,"1")!=0)
			return 1;
		mapi_TLibraryInfo deflib; deflib.name="Default"; deflib.path="mapi32.dll";
		mapi_Libraries.push_back(deflib);
	}
	return 1;
}

// mapi_OpenExchange -- builds up a list
// of all the profiles and message-stores listed in that mapi implementation.
// The list is heterogenous. The 'type' field in each item in the list
// says whether it's a store, or a profile, or a "secret profile" (one where
// we weren't able to get a list of its stores, presumably because this
// information is protected by a password).
BOOL CMapiStuffClient::mapi_OpenExchange(BOOL iPurpose, list<string>* pOutProfiles, BOOL bForceAskForProfile)
{
	static CCriticalSection cs;
	SimpleLocker l(&cs);
	SetTooltipText(toString("Opening Exchange (Proxy ver=%s)",VERSION),1);
	if(mapi_Libraries.size()==0){
		return -2;
	}
	string libpath=mapi_Libraries.front().path;
	if (mapi_lib_path==libpath){
		// We already enumed everything on this implementation of MAPI
		return 1;
	}
	mapi_UnloadExchange();
	mapi_lib_path=libpath;
	//
	// Load the library
	if (hmapilib==0) {
		hmapilib = LoadLibrary(libpath.c_str()); 
	}
	if (hmapilib==0) {
		return -2;
	}
	MAPIINITIALIZE *pMAPIInitialize = (MAPIINITIALIZE*)GetProcAddress(hmapilib,"MAPIInitialize");
	pMAPIAdminProfiles = (MAPIADMINPROFILES*)GetProcAddress(hmapilib,"MAPIAdminProfiles");
	pMAPILogonEx = (MAPILOGONEX*)GetProcAddress(hmapilib,"MAPILogonEx");
	pMAPIUninitialize = (MAPIUNINITIALIZE*)GetProcAddress(hmapilib,"MAPIUninitialize");
	pMAPIFreeBuffer = (MAPIFREEBUFFER*)GetProcAddress(hmapilib,"MAPIFreeBuffer");
	pFreePadrlist = (FREEPADRLIST*)GetProcAddress(hmapilib,"FreePadrlist");
	//pHrSetOneProp = (MAPISETONEPROP*)GetProcAddress(hmapilib,"HrSetOneProp");
	pRTFSync = (RTFSYNC*)GetProcAddress(hmapilib,"RTFSync");
	pWrapCompressedRTFStream = (WRAPCOMPRESSEDRTFSTREAM*)GetProcAddress(hmapilib,"WrapCompressedRTFStream");
	pMAPIAllocateBuffer = (MAPIALLOCATEBUFFER*)GetProcAddress(hmapilib,"MAPIAllocateBuffer");
	
	if (pMAPIInitialize==0 || pMAPIAdminProfiles==0 || pMAPILogonEx==0 || pMAPIUninitialize==0
		|| pMAPIFreeBuffer==0 || pRTFSync==0 || pWrapCompressedRTFStream==0
		|| pMAPIAllocateBuffer==0) {
		FreeLibrary(hmapilib);
		hmapilib=0;
		return -3;
	}
	HRESULT hr = pMAPIInitialize(NULL); 
	if (hr!=S_OK){
		//0x80040108 == MAPI_E_INVALID_OBJECT
		_log(0,"ERROR: MAPI initialization FAILED, hr=0x%08X",__LINE__,hr);
		FreeLibrary(hmapilib);
		hmapilib=0;
		return -4;
	}
	// List all the profiles
	BOOL bRes=1;
	IProfAdmin *iprofadmin=0;
	hr = pMAPIAdminProfiles(0,&iprofadmin);
	if (hr==S_OK && iprofadmin){
		list<string> profiles;
		if(pOutProfiles==0 && sRestrictToProfile.size()>0){
			sDefaultProfile=sRestrictToProfile;
			profiles.push_front(sRestrictToProfile); 
		}else{
			IMAPITable *proftable=0;
			hr = iprofadmin->GetProfileTable(0, &proftable);
			if (hr==S_OK){
				SizedSPropTagArray(2, proftablecols) = { 2, {PR_DISPLAY_NAME,PR_DEFAULT_PROFILE} };
				SRowSet *profrows=0;
				hr = pHrQueryAllRows(proftable,(SPropTagArray*)&proftablecols,NULL,NULL,0,&profrows);
				if (hr==S_OK){
					for (unsigned int i=0; i<profrows->cRows; i++){
						string name=""; bool isdefault=false;
						if (profrows->aRow[i].lpProps[0].ulPropTag==PR_DISPLAY_NAME) name=profrows->aRow[i].lpProps[0].Value.lpszA;
						if (profrows->aRow[i].lpProps[1].ulPropTag==PR_DEFAULT_PROFILE) isdefault=(0!=profrows->aRow[i].lpProps[1].Value.b);
						if (name!="" && name!="WPLabsTemp_Profile") {
							if (isdefault){
								// ��� ������������� ����� ��������� �������
								sDefaultProfile=name;
								profiles.push_front(name); 
							}else {
								profiles.push_back(name);
							}
						}
					}
					pFreeProws(profrows);
				}
				proftable->Release();
			}
		}
		if(iPurpose==EXCH_PURPOSE_GETPROFILES){
			if(pOutProfiles){
				pOutProfiles->merge(profiles);
			}
			return 1;
		}
		// For each profile we will attempt to log on and list the message-stores it contains.
		// Plan: we will build up a list of stores just for this profile. Then we will splice it
		// onto the main global list of stores -- either at the beginning (if this is the default
		// profile) or at the end.
		if(profiles.size()==0){
			return -5;
		}
		int iValidProfiles=0;
		for (list<string>::const_iterator profileI=profiles.begin(); profileI!=profiles.end(); profileI++)
		{
			string profile=*profileI;
			BOOL bTheSameAsDef=(strcmp(sDefaultProfile.c_str(),profile.c_str())==0);
			BOOL bInDefaultProfile=(sLogonProfile.length()==0 && bTheSameAsDef);
			if(bInDefaultProfile || strcmp(sLogonProfile.c_str(),profile.c_str())==0){
				iValidProfiles++;
				list<mapi_TStoreInfo> thesestores;
				IMAPISession *isession=0; bool issecret=true;
				char sPsw[512]={0};
				strcpy(sPsw,sLogonPassword.c_str());
				char szProfile[128]={0};
				strcpy(szProfile,profile.c_str());
				DWORD dwFlags=MAPI_NEW_SESSION|MAPI_EXTENDED|(sets.inService?MAPI_NT_SERVICE:0)|MAPI_TIMEOUT_SHORT;
				if(iPurpose!=EXCH_PURPOSE_GETMAILS){
					dwFlags|=MAPI_NO_MAIL;
				}else if(sets.lForceExchangeLE){
					dwFlags|=MAPI_FORCE_DOWNLOAD;
				};
				if(bInDefaultProfile && bForceAskForProfile && !sets.inService){
					szProfile[0]=0;// Asking user for profile!
					dwFlags|=MAPI_LOGON_UI;
					_log(0,"- Opening profile (manual)");
				}else{
					_log(0,"- Opening profile '%s'",szProfile);
				}
				hr = pMAPILogonEx(0,szProfile,sPsw,dwFlags,&isession);
				profile=szProfile;
				if (hr==S_OK && isession!=0){
					IMAPITable *mstable=0;
					hr = isession->GetMsgStoresTable(0, &mstable);
					if (hr==S_OK){
						issecret=false;
						SizedSPropTagArray(2, mstablecols) = { 2, {PR_RESOURCE_FLAGS,PR_DISPLAY_NAME} };
						SRowSet *msrows=0;
						hr = pHrQueryAllRows(mstable,(SPropTagArray*)&mstablecols,NULL,NULL,0,&msrows);
						if (hr==S_OK){
							for (unsigned int i=0; i<msrows->cRows; i++)
							{
								string name=""; 
								if (msrows->aRow[i].lpProps[1].ulPropTag==PR_DISPLAY_NAME) 
									name=msrows->aRow[i].lpProps[1].Value.lpszA;
								if(sRestrictToStore.size()>0 && sRestrictToStore.compare(name)!=0){
									continue;
								}
								bool isdefault=false;
								if (msrows->aRow[i].lpProps[0].ulPropTag==PR_RESOURCE_FLAGS) 
									isdefault=(msrows->aRow[i].lpProps[0].Value.ul&STATUS_DEFAULT_STORE)!=0;
								if (name!="")
								{
									mapi_TStoreInfo sinfo; 
									sinfo.profile=profile;
									sinfo.store=name; 
									sinfo.type=mstStore;
									if (isdefault) 
										thesestores.push_front(sinfo); 
									else 
										thesestores.push_back(sinfo);
								}
							}
							pFreeProws(msrows);
						}
						mstable->Release();
					}else{
						bRes=-8;
					}
					isession->Logoff(0,0,0);
					isession->Release();
				}else{
					bRes=-9;
				}
				mapi_TStoreInfo sinfo;  
				sinfo.profile=profile;
				sinfo.store="";
				if (issecret) 
					sinfo.type=mstProfileSecret; 
				else 
					sinfo.type=mstProfile;
				thesestores.push_front(sinfo);
				mapi_Stores.splice(mapi_Stores.end(),thesestores);
			}
		}
		iprofadmin->Release();
		if(iValidProfiles==0){
			// �� ������ ������� �� �����
			return RET_NOPROFILE;
		}
	}else{
		return -7;
	}
	return bRes;
}

BOOL CMapiStuffClient::mapi_EnsureMessages(HWND hwnd, BOOL bRetrieveOrDelete)
{
	if(!bRetrieveOrDelete){
		SetTooltipText("Loading message(s)...");
	}else{
		SetTooltipText("Deleting message(s)...");
	}
	if(!bRetrieveOrDelete){
		mapi_Messages.clear();
		maildrop_size=0;
	}
	int iOKCount=0;
	BOOL bStopFutherProcessing=0;
	for (list<mapi_TStoreInfo>::const_iterator iS=mapi_Stores.begin(); bStopFutherProcessing==0 && iS!=mapi_Stores.end(); iS++)
	{
		if(iS->store.length()>0){
			if(sRestrictToStore.size()>0 && sRestrictToStore.compare(iS->store)!=0){
				continue;
			}
			if(mapi_EnsureFolders(hwnd,iS->profile,iS->store,0)){
				for (list<mapi_TFolderInfo>::const_iterator i=mapi_Folders.begin(); bStopFutherProcessing==0 && i!=mapi_Folders.end(); i++)
				{
					if(!eid_outbox.isempty() && eid_outbox.isequal(mapi_session,i->eid)){
						// �������� ��� �� ����
						continue;
					}
					if(!eid_sent.isempty() && eid_sent.isequal(mapi_session,i->eid)){
						// �������� ��� �� ����
						continue;
					}
					if(!eid_deleted.isempty() && eid_deleted.isequal(mapi_session,i->eid)){
						// �������� ��� �� ����
						continue;
					}
					IMAPIFolder *ifolder=0; ULONG ftype=0;
					HRESULT hr = mapi_msgstore->OpenEntry(i->eid.size,i->eid.ab, NULL,(bRetrieveOrDelete==1)?MAPI_MODIFY:0,&ftype,(IUnknown**)&ifolder);
					if (ifolder && hr==S_OK){
						vector<SBinary> aMsgsToDelete;
						if (ftype==MAPI_FOLDER)
						{// ... and do something with the ifolder, like iterating over its messages
							iOKCount++;
							{// Loading emails in the folder
								IMAPITable *contents=0;
								HRESULT hr = ifolder->GetContentsTable(0,&contents);
								if (hr==S_OK){ 
									SizedSPropTagArray(8,foldcols) = {8, {PR_ENTRYID,PR_SUBJECT,PR_SENT_REPRESENTING_NAME,PR_MESSAGE_DELIVERY_TIME,PR_MESSAGE_SIZE,PR_TRANSPORT_MESSAGE_HEADERS,PR_INTERNET_MESSAGE_ID,PR_SMTP_MESSAGE_ID}};
									SRowSet *frows=0;
									hr = pHrQueryAllRows(contents,(SPropTagArray*)&foldcols,NULL,NULL,0,&frows);
									if (hr==S_OK){ 
										for (unsigned int m=0; bStopFutherProcessing==0 && m<frows->cRows; m++){
											// We'll first retrieve the basic header information of the message.
											// We must do this now, from the contents-table, because if the
											// message is offline and we're using Outlook2000/IMO then it's not
											// possible to IMessage::GetProps.
											// NB. In this headers, "sent-representing" is available, but none of the
											// other sender properties are.
											mapi_TEntryid eid;
											string subj,sndr,date;
											string headers;
											CString sid;
											long lSize=0;
											if (frows->aRow[m].lpProps[0].ulPropTag==PR_ENTRYID) 
												eid=&frows->aRow[m].lpProps[0];
											if (frows->aRow[m].lpProps[1].ulPropTag==PR_SUBJECT) 
												subj=frows->aRow[m].lpProps[1].Value.lpszA;
											if (frows->aRow[m].lpProps[2].ulPropTag==PR_SENT_REPRESENTING_NAME) 
												sndr=frows->aRow[m].lpProps[2].Value.lpszA;
											if (frows->aRow[m].lpProps[3].ulPropTag==PR_MESSAGE_DELIVERY_TIME)
											{ 
												FILETIME ft; FileTimeToLocalFileTime(&frows->aRow[m].lpProps[3].Value.ft, &ft); // Translate from UTC to current timezone
												SYSTEMTIME st; FileTimeToSystemTime(&ft,&st);
												const char *days[] = {"Sun ","Mon ","Tue ","Wed ","Thu ","Fri ","Sat "};
												const char *day=0; if (st.wDayOfWeek<=6) day=days[st.wDayOfWeek];
												const char *months[] = {"","Jan ","Feb ","Mar ","Apr ","May ","Jun ","Jul ","Aug ","Sep ","Oct ","Nov ","Dec "};
												const char *month=0; if (st.wMonth>=1 && st.wMonth<=12) month=months[st.wMonth];
												char c[128]={0};
												wsprintf(c,"%s, %02i %s %04i %02i:%02i:%02i",day,st.wDay,month,st.wYear,st.wHour,st.wMinute,st.wSecond); date=c;
												//GetDateFormat(MAKELCID(),DATE_SHORTDATE,0,0,c,sizeof(c));
												//CTime tm(st);
												//date=tm.FormatGmt();
											}
											if (frows->aRow[m].lpProps[4].ulPropTag==PR_MESSAGE_SIZE){
												lSize=frows->aRow[m].lpProps[4].Value.l;
											}
											if (frows->aRow[m].lpProps[5].ulPropTag==PR_TRANSPORT_MESSAGE_HEADERS){
												headers=frows->aRow[m].lpProps[5].Value.lpszA;
											}
											if (frows->aRow[m].lpProps[6].ulPropTag==PR_INTERNET_MESSAGE_ID){//PR_TNEF_CORRELATION_KEY
												CString sSid1=frows->aRow[m].lpProps[6].Value.lpszA;
												sSid1.TrimLeft(" <");
												sSid1.TrimRight(" >");
												sid+="_";
												sid+=sSid1;
											}
											if (sid=="" && frows->aRow[m].lpProps[7].ulPropTag==PR_SMTP_MESSAGE_ID){//PR_TNEF_CORRELATION_KEY
												CString sSid1=frows->aRow[m].lpProps[7].Value.lpszA;
												sSid1.TrimLeft(" <");
												sSid1.TrimRight(" >");
												sid+="_";
												sid+=sSid1;
											}
											// Now, 'message_details' shows the important stuff about the message,
											// so we could use it in (e.g.) error reports if some other bit of code fails.
											if (!eid.isempty())
											{
												sid.TrimLeft(" <");
												sid.TrimRight(" >");
												if(sid.GetLength()==0){
													sid=eid.getSid().c_str();
												}
												if(sets.lEmailShift){
													CString sCopy=sid;
													if(sCopy.GetLength()>10){
														sCopy=sCopy.Left(7)+"_"+sCopy.Right(7);
													}
													sid.Format("%s_%i",sCopy,sets.lEmailShift);
												}
												IMessage *imsg=0; ULONG msgtype=0;
												hr = ifolder->OpenEntry(eid.size, eid.ab, NULL, (bRetrieveOrDelete==1)?MAPI_MODIFY:0, &msgtype, (IUnknown**)&imsg);//MAPI_BEST_ACCESS
												if (hr==S_OK){ 
													if (msgtype==MAPI_MESSAGE){
														if(bRetrieveOrDelete==1){
															// ����� �� ��� ��������?
															string sThisMsgSid=sid;
															for(int i=0;i<mapi_Messages.size();i++){
																if(mapi_Messages[i].todelete && sThisMsgSid==mapi_Messages[i].sid && sThisMsgSid.find(DEF_UNDELETABLE)==-1){
																	SBinary sb;
																	sb.cb=mapi_Messages[i].eid.size;
																	sb.lpb=(BYTE*)mapi_Messages[i].eid.ab;
																	aMsgsToDelete.push_back(sb);
																}
															}
														}else{
															maildrop_size+=lSize;
															mapi_TMessageInfo msg;
															msg.eid.set(eid.size,eid.ab);
															msg.sid=sid;
															msg.len=lSize;
															msg.todelete=false;
															msg.date=date;
															msg.subj=subj;
															msg.headers=headers;
															char szNum[32]={0};
															sprintf(szNum,"Parsing message #%i...",mapi_Messages.size()+1);
															SetTooltipText(szNum);
															if(mapi_retrMessage(imsg,msg)){
																mapi_Messages.push_back(msg);
																if(sets.iMaxMessagesPerLoad && mapi_Messages.size()>sets.iMaxMessagesPerLoad){
																	// We do not want any more emails
																	bStopFutherProcessing=1;
																}
															}
														}
													}
													if(imsg){
														imsg->Release();
													}
												}
											}
										}
										pFreeProws(frows);
									}
									contents->Release();
								}
							}
						}
						if((bRetrieveOrDelete==1) && aMsgsToDelete.size()>0){
							ENTRYLIST msgList;
							msgList.cValues=aMsgsToDelete.size();
							msgList.lpbin=&(*aMsgsToDelete.begin());
							HRESULT hRes=ifolder->DeleteMessages(&msgList,0,0,0);
							_log(0,"- Actually deleting %i message(s)",aMsgsToDelete.size());
							if(hRes!=S_OK){
								_log(0,"ERROR: line %i, hr=0x%08X",__LINE__,hRes);
							}
						}
						ifolder->Release();
					}else{
						_log(0,"ERROR: line %i, hr=0x%08X",__LINE__,hr);
					}
				}
			}
		}
	}
	if(!bRetrieveOrDelete){
		if(mapi_Messages.size()>0){
			_log(0,"- Message(s) found: %i",mapi_Messages.size());
		}
	}
	return (iOKCount>0);
}

void RemoveCommonHeaderFields(CString& h)
{
	h=CString("\r\n")+h;
	CDataXMLSaver::StripInstringPart("\r\nFrom:","\r\n",h,0,1,2);
	CDataXMLSaver::StripInstringPart("\r\nDate:","\r\n",h,0,1,2);
	CDataXMLSaver::StripInstringPart("\r\nSubject:","\r\n",h,0,1,2);
	CDataXMLSaver::StripInstringPart("\r\nMessage-id:","\r\n",h,0,1,2);
	CDataXMLSaver::StripInstringPart("\r\nTo:","\r\n",h,0,1,2);
	CDataXMLSaver::StripInstringPart("\r\nImportance:","\r\n",h,0,1,2);
	CDataXMLSaver::StripInstringPart("\r\nCc:","\r\n",h,0,1,2);
	CDataXMLSaver::StripInstringPart("\r\nPriority:","\r\n",h,0,1,2);
	CDataXMLSaver::StripInstringPart("\r\nContent-type:","\r\n",h,0,1,2);
	CDataXMLSaver::StripInstringPart("\r\nMIME-Version:","\r\n",h,0,1,2);
	CDataXMLSaver::StripInstringPart("\r\nContent-transfer-encoding:","\r\n",h,0,1,2);
	h.TrimLeft();
	h.TrimRight();
}

#include "MapiConverter.h"
#include "../mimepp/mimepp.h"
// Defined in "MapiConverter.h"
#include <initguid.h>
DEFINE_GUID(CLSID_IConverterSession, 0x4e3a7680, 0xb77a, 0x11d0, 0x9d, 0xa5, 0x0, 0xc0, 0x4f, 0xd6, 0x56, 0x85);
DEFINE_GUID(IID_IConverterSession, 0x4b401570, 0xb77b, 0x11d0, 0x9d, 0xa5, 0x0, 0xc0, 0x4f, 0xd6, 0x56, 0x85);

BOOL CMapiStuffClient::mapi_retrMessage(IMessage *imsg,mapi_TMessageInfo& msg)
{
	BOOL bResult=1;
	HRESULT hr=S_OK;
	// 8004011D/8004010015 - ��������� ����������� � �������/������� ������ ��� ������ � ����
	BOOL bCCompat=sets.lUseBackwComp;
	if(!bCCompat){
		// ������� ������� ����� Outlook 2003 SP1
		IConverterSession* pConverterSession=0;
		hr=CoCreateInstance(CLSID_IConverterSession, NULL, CLSCTX_INPROC_SERVER, IID_IConverterSession, (void**)&pConverterSession);
		if(!FAILED(hr) && pConverterSession){
			hr=S_OK;
			void* pBuf=0;
			HGLOBAL hGlob=0;
			BOOL bLocked=0;
			IStream *pStream=0;
			try{
				if(FAILED(hr=pConverterSession->SetEncoding(IET_7BIT))){
					_log(0,"ERROR: line %i, %s",__LINE__,"SetEnc");
					throw hr;
				}
				hGlob=GlobalAlloc(GMEM_MOVEABLE, 0);                                        // allocate global memory
				if(!hGlob){
					_log(0,"ERROR: line %i, %s",__LINE__,"GlAlloc");
					throw (HRESULT)GetLastError();
				}
				hr=CreateStreamOnHGlobal(hGlob, false, &pStream);                           // open a stream on it
				if(FAILED(hr)){
					_log(0,"ERROR: line %i, %s",__LINE__,"StrOnHGlob");
					throw hr;
				}
				pConverterSession->SetTextWrapping(0,0xffff);
				hr=pConverterSession->MAPIToMIMEStm(imsg, pStream, CCSF_NO_MSGID|CCSF_SMTP);
				if(FAILED(hr)){
					_log(0,"ERROR: line %i, %s",__LINE__,"M2MIME");
					throw hr; 
				}
				if(FAILED(pStream->Commit(0))){
					_log(0,"ERROR: line %i, %s",__LINE__,"Commit");
					throw hr;
				}
				if(FAILED(hr=GetHGlobalFromStream(pStream, &hGlob))) {
					_log(0,"ERROR: line %i, %s",__LINE__,"GFromStr");
					throw hr;
				}
				bLocked=!!(pBuf=GlobalLock(hGlob));                                         // lock memory to get a pointer to buffer
				if(!bLocked){
					_log(0,"ERROR: line %i, %s",__LINE__,"Lock");
					throw (HRESULT)GetLastError();
				}
				STATSTG StatStg;
				if(FAILED(hr=pStream->Stat(&StatStg, STATFLAG_NONAME))){
					_log(0,"ERROR: line %i, %s",__LINE__,"Stat");
					throw hr;           // get stream statistics
				}
				if(StatStg.cbSize.QuadPart>=ULONG_MAX){
					_log(0,"ERROR: line %i, %s",__LINE__,"Size");
					throw (HRESULT)OLE_E_ENUM_NOMORE; // too large
				}
			}catch(HRESULT _hr){
				_log(0,"ERROR: line %i, hr=0x%08X",__LINE__,_hr);
				hr=_hr;
			}
			if(pBuf){
				msg.headers=(char*)pBuf;
			}
			if(pStream) pStream->Release();
			if(bLocked&&hGlob) GlobalUnlock(hGlob);                                       // unlock buffer if necessary
			if(hGlob) GlobalFree(hGlob);                                                  // free it
			pConverterSession->Release();
			if(!FAILED(hr)){
				// ���� \r\n
				int iDelimPos=msg.headers.find("\r\n\r\n");
				if(iDelimPos!=-1){
					char* szBodyStart=(char*)(msg.headers.c_str()+(iDelimPos+4));
					while(szBodyStart[0]=='\r'||szBodyStart[0]=='\n'){
						szBodyStart++;
					}
					msg.body=szBodyStart;
					msg.headers=msg.headers.substr(0,iDelimPos);
					// ��� ��������� ����
					CString sMsgId="<";
					sMsgId+=msg.sid.c_str();
					if(sets.lEmailShift){
						RemoveHeader(msg.headers,"Message-Id");
						char szTmp[128]={0};
						sprintf(szTmp,"%lu",sets.lEmailShift);
						//sMsgId+="_";
						//sMsgId+=szTmp;
						std::string subj=RemoveHeader(msg.headers,"Subject");
						subj+="_";
						subj+=szTmp;
						AddHeader(msg.headers,"Subject",subj.c_str());
						AddHeader(msg.headers,"X-Shifted-ID",szTmp);
					}
					sMsgId+=">";
					AddHeader(msg.headers,"Message-Id",sMsgId);
				}
				return 1;
			}
		}
	}
	bool AvailableOffline=false;
	// ��������� ��������� ���� ��� ��� ����������� ����������
	CString sHeadersLow=msg.headers.c_str();
	sHeadersLow.TrimLeft();
	sHeadersLow.TrimRight();
	RemoveCommonHeaderFields(sHeadersLow);
	msg.headers=sHeadersLow;
	sHeadersLow.MakeLower();
	LPSPropValue props=0;
	CString sCP;
	{// ���������� ����������� ����
		SizedSPropTagArray(14, mcols) = {14,{PR_MESSAGE_CLASS, PR_SENDER_NAME, PR_SENDER_EMAIL_ADDRESS, PR_RTF_IN_SYNC,PR_RECEIVED_BY_EMAIL_ADDRESS, PR_RECEIVED_BY_NAME, PR_RECEIVED_BY_ENTRYID,PR_IMPORTANCE,PR_PRIORITY,PR_DISPLAY_CC,PR_REPLY_RECIPIENT_NAMES,PR_MESSAGE_CODEPAGE,PR_SENDER_ADDRTYPE,PR_INTERNET_CPID}};
		ULONG pcount=0;
		HRESULT hr=0;
		hr = imsg->GetProps((SPropTagArray*)&mcols,0,&pcount,&props);
		// Outlook2000 in IMO gives this NO_ACCESS error messages that are header-only.
		// But Outlook97, and Outlook2000/CWG, and OutlookXP, don't give the error...
		// we'll test for them later on.
		if (hr==MAPI_E_NO_ACCESS)
			AvailableOffline=false;
		bool okay=true;
		if (hr!=S_OK && hr!=MAPI_W_ERRORS_RETURNED)
			okay=false;
		if (okay && props[0].ulPropTag!=PR_MESSAGE_CLASS)
			okay=false;
		if (okay && (strncmp(props[0].Value.lpszA,"IPM.Note",8)!=0 && strncmp(props[0].Value.lpszA,"IPF.Note",8)!=0))
			okay=false;
		if (!okay) {
			if (props!=0){
				pMAPIFreeBuffer(props);
				props=0;
			}
		}else{
			// Was it a received message, or one that the user sent?
			// (This isn't recorded explicitly. We'll use a heurstic instead:
			// if there's any sign that this message has been over the internet,
			// then presumably it's received. If there's no such sign, then
			// presumably it's just the local copy put into the 'Sent' folder)
			bool isrcvd = false;
			if (props[4].ulPropTag==PR_RECEIVED_BY_EMAIL_ADDRESS) isrcvd=true;
			if (props[5].ulPropTag==PR_RECEIVED_BY_NAME) isrcvd=true;
			if (props[6].ulPropTag==PR_RECEIVED_BY_ENTRYID) isrcvd=true;
			if (props[7].ulPropTag==PR_TRANSPORT_MESSAGE_HEADERS) isrcvd=true;
			// Retrieve the 'from' property
			// in the form Name <email@addr>
			CString from,sfromRaw,sfromRawName;
			if (props[1].ulPropTag==PR_SENDER_NAME){
				from=props[1].Value.lpszA;
				sfromRawName=props[1].Value.lpszA;
			}
			if (props[2].ulPropTag==PR_SENDER_EMAIL_ADDRESS){ 
				sfromRaw=props[2].Value.lpszA;
				if (from!="") from+=" ";
				from += "<";
				from += props[2].Value.lpszA;
				from += ">";
			}
			if (props[12].ulPropTag==PR_SENDER_ADDRTYPE && sfromRaw!=""){ 
				CString sAddrType=props[12].Value.lpszA;
				if(sAddrType.CompareNoCase("smtp")!=0 && sfromRaw.Find(sAddrType)==-1){
					from.Format("<MAPI2POP3_T[%s]N[%s]E[%s]>",sAddrType,sfromRawName,sfromRaw);
					from.Replace(" ","&nbsp");
					from=sfromRawName+" "+from;
				}
			}
			if (props[11].ulPropTag==PR_MESSAGE_CODEPAGE){
				long lPage=props[11].Value.l;
				if(lPage!=0){
					sCP.Format("Windows-%lu",lPage);
				}
			}
			if (props[13].ulPropTag==PR_INTERNET_CPID){
				long lCP=props[13].Value.l;
				sCP=GetCPCodeByCode(lCP);
			}
			if (from!="")
				AvailableOffline = true;
			AddHeader(msg.headers,"Date",msg.date.c_str());
			if(from.GetLength()>0){
				AddHeader(msg.headers,"From",from);
			}
			if(msg.subj.size()>0){
				AddHeader(msg.headers,"Subject",msg.subj.c_str());
			}
			string sSid="<";
			sSid+=msg.sid;
			sSid+=">";
			AddHeader(msg.headers,"Message-Id",sSid.c_str());
			// Retrieve the 'to' property
			// in the form Name <email@addr>, AnotherName <email@addr>
			CString to;
			IMAPITable *rtable=0;
			hr = imsg->GetRecipientTable(0,&rtable);
			if (hr==S_OK){ 
				SizedSPropTagArray(3,rcols) = {3, {PR_DISPLAY_NAME,PR_EMAIL_ADDRESS,PR_RECIPIENT_TYPE}};
				SRowSet *rrows=0;
				hr = pHrQueryAllRows(rtable,(SPropTagArray*)&rcols,NULL,NULL,0,&rrows);
				if (hr==S_OK){
					for (unsigned int r=0; r<rrows->cRows; r++)
					{ 
						string recipient;
						if (rrows->aRow[r].lpProps[0].ulPropTag==PR_DISPLAY_NAME) 
							recipient=rrows->aRow[r].lpProps[0].Value.lpszA;
						if (rrows->aRow[r].lpProps[1].ulPropTag==PR_EMAIL_ADDRESS)
						{ 
							if (recipient!="") 
								recipient+=" ";
							recipient += string("<")+rrows->aRow[r].lpProps[1].Value.lpszA+">";
						}
						if (recipient!=""){
							if (to!="") {
								to+=", ";
							}
							to += recipient.c_str();
						}
					}
					pFreeProws(rrows);
				}
				rtable->Release();
			}
			if (to!=""){
				AvailableOffline = true;
			}
			if(to.GetLength()>0){
				AddHeader(msg.headers,"To",to);
			}
			if (props[7].ulPropTag==PR_IMPORTANCE){
				long lImp=props[7].Value.l;
				CString sP="normal";
				if(lImp==IMPORTANCE_LOW){
					sP="low";
				}
				if(lImp==IMPORTANCE_HIGH){
					sP="high";
				}
				AddHeader(msg.headers,"Importance",sP);
			}
			if (props[8].ulPropTag==PR_PRIORITY){
				long lImp=props[8].Value.l;
				CString sP="normal";
				if(lImp==PRIO_NONURGENT){
					sP="non-urgent";
				}
				if(lImp==PRIO_URGENT){
					sP="urgent";
				}
				AddHeader(msg.headers,"Priority",sP);
			}
			if (props[9].ulPropTag==PR_DISPLAY_CC){
				CString szCC=props[9].Value.lpszA;
				szCC.Replace(";",",");
				if(szCC!=""){
					AddHeader(msg.headers,"cc",szCC);
				}
			}
			if (props[10].ulPropTag==PR_REPLY_RECIPIENT_NAMES){
				CString szReplyTo=props[10].Value.lpszA;
				szReplyTo.Replace(";",", ");
				if(szReplyTo!="" && to.Find(szReplyTo)==-1 && szReplyTo.Find("@")!=-1){
					AddHeader(msg.headers,"Reply-To",szReplyTo);
				}
			}
		}
	}
	// �������� ���� ���������
	msg.body="";
	BOOL bHTML=FALSE;
	// Get the body of the message if it was in HTML
	// into the buffer 'htmlbuf'
	char *htmlbuf=0; 
	BOOL bCharsetAlreadyset=0;
	unsigned int htmlsize=0;
	BOOL bAccessError=0;
	if(!sets.lGetAsTextEverything){
		IStream* istream;
		HRESULT hr = imsg->OpenProperty(PR_BODY_HTML, &IID_IStream, STGM_READ, 0, (IUnknown**)(&istream));
		if(hr==MAPI_E_NO_ACCESS){
			bAccessError=TRUE;
			bResult=0;
		}
		if (hr==S_OK){
			STATSTG stg = {0};
			hr = istream->Stat(&stg,STATFLAG_NONAME);
			if (hr==S_OK){ 
				htmlsize = stg.cbSize.LowPart;
				htmlbuf = new char[htmlsize+1];
				ULONG red=0; 
				hr = istream->Read(htmlbuf, htmlsize, &red);
				if (hr!=S_OK) 
					htmlsize=0;
				else 
					if (red<htmlsize) 
						htmlsize=red;
					htmlbuf[htmlsize]=0;
			}
			istream->Release();
		}
		// In actual fact, the PR_HTML_BODY that we just tested is rarely used.
		// More frequently, Microsoft encode the html message source into the RTF...
		// First we have to sync the rtf with the body, in case the messsagestore hasn't already.
		// (nb. it would have made more sense to query the support mask just once, rather than
		// for each message as we're doing here)
		if(htmlsize==0){
			LPSPropValue svmask; 
			bool mustsync=true;
			hr = pHrGetOneProp(mapi_msgstore, PR_STORE_SUPPORT_MASK, &svmask);
			if (hr==S_OK){ 
				if ((svmask->Value.ul&STORE_RTF_OK)!=0) 
					mustsync=false;
					/*else 
					if (props[3].ulPropTag==PR_RTF_IN_SYNC && props[3].Value.b!=0) 
					mustsync=false;
				*/
				pMAPIFreeBuffer(svmask);
				svmask=0;
			}
			if (mustsync){ 
				BOOL isupdated; 
				pRTFSync(imsg,RTF_SYNC_BODY_CHANGED,&isupdated);
				if (isupdated) 
					imsg->SaveChanges(0);
			}
			// Now it's synced if necessary. We can retrieve the RTF property
			hr= imsg->OpenProperty(PR_RTF_COMPRESSED, &IID_IStream, STGM_READ, 0, (IUnknown**)&istream);
			if (hr==S_OK){
				AvailableOffline = true;
				IStream *iunstream=0; // for the uncompressed stream
				pWrapCompressedRTFStream(istream,0,&iunstream);
				// bufsize is the size of the buffer we've allocated, and htmlsize is the
				// amount of text we've read in so far. If our buffer wasn't big enough,
				// we enlarge it and continue. We have to do this, instead of allocating
				// it up front, because Stream::Stat() doesn't work for the unc.stream
				unsigned int bufsize=10240; 
				htmlbuf = new char[bufsize];
				htmlsize=0; 
				bool done=false;
				while (!done){ 
					ULONG red=0; 
					hr = iunstream->Read(htmlbuf+htmlsize, bufsize-htmlsize, &red);
					if (hr!=S_OK) {
						htmlbuf[htmlsize]=0; done=true;
					}else{ 
						htmlsize+=red; done = (red < bufsize-htmlsize);
						if (!done){ 
							unsigned int newsize=2*htmlsize; 
							char *newbuf=new char[newsize];
							memcpy(newbuf,htmlbuf,htmlsize); 
							delete[] htmlbuf;
							htmlbuf=newbuf; bufsize=newsize;
						}
					}
				}
				htmlbuf[htmlsize]=0;
				iunstream->Release();
				istream->Release();
				// Now, assuming that this thing was an encoded RTF/HTML hybrid,
				// we can extract the original html.
				if (htmlbuf!=0){ 
					if (!isrtfhtml(htmlbuf,htmlsize)) {
						delete[] htmlbuf; 
						htmlbuf=0;
					}
					else 
						decodertfhtml(htmlbuf,&htmlsize);
				}
			}
		}
	}
	if(htmlbuf==0){
		char *bodybuf=0; unsigned int bodysize=0;
		IStream *istream=0;
		HRESULT hr = imsg->OpenProperty(PR_BODY, &IID_IStream, STGM_READ, 0, (IUnknown**)&istream);
		if(hr==MAPI_E_NO_ACCESS){
			bAccessError=TRUE;
			bResult=0;
		}
		if (hr==S_OK){ 
			AvailableOffline = true;
			STATSTG stg = {0};
			hr = istream->Stat(&stg,STATFLAG_NONAME);
			if (hr==S_OK)
			{ 
				bodysize = stg.cbSize.LowPart; // won't bother checking for >2gb messages!
				bodybuf = new char[bodysize+1];
				ULONG red; hr = istream->Read(bodybuf, bodysize, &red);
				if (hr!=S_OK) {
					bodysize=0;
				}else{ 
					if (red<bodysize) 
						bodysize=red;
				}
				bodybuf[bodysize]=0;
			}
			istream->Release();
		}
		bHTML=FALSE;
		if(bodybuf){
			msg.body=bodybuf;
			delete[] bodybuf;
		}
		if(bAccessError){
			bResult=0;
			sets.AddLog("Warning: undeletable message found! sid=%s",msg.sid.c_str());
			msg.body=_l("Message body: Access denied");
			msg.sid+=DEF_UNDELETABLE;
		}
	}else{
		bHTML=TRUE;
		if(htmlbuf){
			msg.body=htmlbuf;
			delete[] htmlbuf;
			htmlbuf=0;
		}
		if(bAccessError){
			bResult=0;
			sets.AddLog("Warning: undeletable message found! sid=%s",msg.sid.c_str());
			msg.body=_l("Message body: Access denied");
			msg.sid+=DEF_UNDELETABLE;
		}
		CString sLo=msg.body.c_str();
		sLo.MakeLower();
		bCharsetAlreadyset=(sLo.Find("charset=")!=-1);
	}
	// Check if there are any attachments
	int inAttCount=0;
	IMAPITable *atable=0;
	hr = imsg->GetAttachmentTable(0,&atable);
	if (hr==S_OK){ 
		SizedSPropTagArray(6,acols) = {6, {PR_ATTACH_SIZE,PR_ATTACH_NUM,PR_ATTACH_METHOD,PR_ATTACH_LONG_FILENAME,PR_ATTACH_MIME_TAG,PR_ATTACH_CONTENT_ID}};
		SRowSet *arows=0;
		hr = pHrQueryAllRows(atable,(SPropTagArray*)&acols,NULL,NULL,0,&arows);
		if (hr==S_OK){
			for (unsigned int i=0; i<(arows->cRows); i++){
				inAttCount++;
				AvailableOffline=true;
				long dwAttachMethod=0;
				long dwAttachSize=0;
				string sFName,sMime,sConID;
				IAttach* iatt=0;
				if (arows->aRow[i].lpProps[1].ulPropTag==PR_ATTACH_NUM){
					long lNum=arows->aRow[i].lpProps[1].Value.l;
					imsg->OpenAttach(lNum,0,0,&iatt);
				}
				if (arows->aRow[i].lpProps[3].ulPropTag==PR_ATTACH_LONG_FILENAME){
					sFName=arows->aRow[i].lpProps[3].Value.lpszA;
					//sFName=GetPathPart(sFName.c_str(),0,0,1,1);
				}
				if (arows->aRow[i].lpProps[4].ulPropTag==PR_ATTACH_MIME_TAG){
					sMime=arows->aRow[i].lpProps[4].Value.lpszA;
				}
				if (arows->aRow[i].lpProps[0].ulPropTag==PR_ATTACH_SIZE){
					dwAttachSize=arows->aRow[i].lpProps[0].Value.l;
				}
				if (arows->aRow[i].lpProps[2].ulPropTag==PR_ATTACH_METHOD){
					dwAttachMethod=arows->aRow[i].lpProps[2].Value.l;
				}
				if (arows->aRow[i].lpProps[5].ulPropTag==PR_ATTACH_CONTENT_ID){
					sConID=arows->aRow[i].lpProps[5].Value.lpszA;
				}
				if(iatt){
					// ������ ������
					if(dwAttachMethod==ATTACH_BY_REF_ONLY){
						LPSPropValue sPath;
						if(pHrGetOneProp(iatt, PR_ATTACH_PATHNAME, &sPath)==S_OK){
							msg.body+="\r\n";
							msg.body+="--";
							msg.body+=MYDELIMITER;
							msg.body+="Content-Disposition: inline;\r\n";
							msg.body+="\r\n";
							msg.body+=sPath->Value.lpszA;
						}
					}else{
						IStream *istream=0;
						HRESULT hr = iatt->OpenProperty(PR_ATTACH_DATA_BIN, &IID_IStream, STGM_READ, 0, (IUnknown**)&istream);
						if (hr==S_OK){
							STATSTG stg = {0};
							hr = istream->Stat(&stg,STATFLAG_NONAME);
							if(hr==S_OK){
								long bodysize = stg.cbSize.LowPart; // won't bother checking for >2gb messages!
								char* bodybuf = new char[bodysize+1];
								ULONG red;
								hr = istream->Read(bodybuf, bodysize, &red);
								if (hr!=S_OK) {
									bodysize=0;
								}else {
									if (red<bodysize) 
										bodysize=red;
								}
								bodybuf[bodysize]=0;
								msg.body+="\r\n";
								msg.body+="--";
								msg.body+=MYDELIMITER;
								msg.body+="\r\n";
								if(sMime.size()>0){
									msg.body+="Content-Type: ";
									msg.body+=sMime.c_str();
									msg.body+="; name=\""+sFName+"\"";
									msg.body+="\r\n";
								}
								if(sConID.size()>0){
									msg.body+="Content-ID: <";
									msg.body+=sConID.c_str();
									msg.body+=">\r\n";
								}
								msg.body+="Content-Disposition: attachment; ";
								msg.body+="filename=\""+sFName+"\"\r\nContent-transfer-encoding: base64;\r\n";
								msg.body+="\r\n";
								if(bodysize){
									char* szOutBuffer=new char[bodysize*2];
									CBase64XXX dc(0);
									msg.body+=dc.Encode(bodybuf,bodysize);
								}
								delete[] bodybuf;
							}
						}
						istream->Release();
					}
				}
				if(iatt){
					iatt->Release();
				}
			}
			pFreeProws(arows);
		}
		atable->Release();
	}
	if(props){
		pMAPIFreeBuffer(props);
	}
	// ��������!
	CString sType="text/plain";
	RemoveHeader(msg.headers,"Content-type");
	if(bHTML){
		sType="text/html";
	}
	if(sCP!="" && (!bHTML || (bHTML && !bCharsetAlreadyset))){
		sType+="; charset="+sCP;
	}
	AddHeader(msg.headers,"Content-type",sType);
	if(inAttCount){
		RemoveHeader(msg.headers,"MIME-Version");
		RemoveHeader(msg.headers,"Content-Type");
		AddHeader(msg.headers,"Content-Type","multipart/mixed; boundary=\""MYDELIMITER"\"");
		AddHeader(msg.headers,"MIME-Version","1.0");
		string sprefix=string("--")+string(MYDELIMITER);
		sprefix+="\r\n";
		if(bHTML){
			sprefix+="Content-type: text/html";
		}else{
			sprefix+="Content-type: text/plain";
		}
		sprefix+="\r\n";
		sprefix+="Content-Transfer-Encoding: 8bit";
		sprefix+="\r\n";
		sprefix+="\r\n";
		msg.body=sprefix+msg.body;
		msg.body+="\r\n";
		msg.body+="--";
		msg.body+=MYDELIMITER;
		msg.body+="--";
		msg.body+="\r\n";
	}

	return bResult;
}

// MAPI_ENSUREFOLDERS -- given a profile name and a store name, this builds
// up a list of all the folders in that store. Note that, in truth, the folders
// form a tree. We will flatten the tree to obtain our list. For each item
// we will record its depth, and its complete path, as well as just its name.
// To open a message-store might involve displaying a password dialog.
// For this reason, once we have opened a message-store and a profile, we
// leave both of them open, in global static variables mapi_session and mapi_msgstore.
// That means that subsequent calls for the same profile/store will not
// require another login.
//
BOOL CMapiStuffClient::mapi_EnsureFolders(HWND hwnd, const std::string profile, const string store, BOOL bNoMail)
{
	static CCriticalSection cs;
	SimpleLocker l(&cs);
	HRESULT hr = S_FALSE;
	if (mapi_session_profile==profile && mapi_msgstore_name==store)
		return 1;
	// First thing we do is clean out anything we've allocated before.
	mapi_Folders.clear();
	if (mapi_session_profile!=profile || mapi_msgstore_name!=store)
	{
		mapi_msgstore_name=""; 
		got_eids=false; 
		if (mapi_msgstore!=0) 
			mapi_msgstore->Release(); 
		mapi_msgstore=0;
	}
	if (mapi_session_profile!=profile)
	{
		mapi_session_profile=""; 
		if (mapi_session!=0) {
			mapi_session->Logoff(0,0,0); 
			mapi_session->Release();
		}
	}
	if (hmapilib==0 || pMAPILogonEx==0) 
		return 0;
	//
	// Now we can log on to the specified profile...
	if (mapi_session_profile!=profile || mapi_session==0)
	{
		char sPsw[512]={0};
		strcpy(sPsw,sLogonPassword.c_str());
		hr = pMAPILogonEx(PtrToUlong(hwnd),(char*)profile.c_str(),sPsw,(sLogonPassword.length()==0?MAPI_LOGON_UI:0)|MAPI_NEW_SESSION|MAPI_EXTENDED|(bNoMail?MAPI_NO_MAIL:0),&mapi_session);//MAPI_PASSWORD_UI
		if (hr!=S_OK) 
			return 0;
		mapi_session_profile=profile;
	}
	// ... and find the specified store.
	if (mapi_msgstore_name!=store)
	{
		// task is to get the store we know by name. We do this by enumerating
		// all the message-stores in the table, and picking out the one with the right name.
		IMAPITable *mstable=0;
		hr = mapi_session->GetMsgStoresTable(0, &mstable);
		if (hr==S_OK)
		{
			SizedSPropTagArray(2, mstablecols) = { 2, {PR_ENTRYID,PR_DISPLAY_NAME} };
			SRowSet *msrows;
			hr = pHrQueryAllRows(mstable,(SPropTagArray*)&mstablecols,NULL,NULL,0,&msrows);
			if (hr==S_OK)
			{
				for (unsigned int i=0; i<msrows->cRows && mapi_msgstore==0; i++)
				{
					string name=""; mapi_TEntryid eid;
					if (msrows->aRow[i].lpProps[1].ulPropTag==PR_DISPLAY_NAME) name=msrows->aRow[i].lpProps[1].Value.lpszA;
					if(sRestrictToFolder.size()>0 && sRestrictToFolder.compare(name)!=0){
						continue;
					}
					if (msrows->aRow[i].lpProps[0].ulPropTag==PR_ENTRYID) eid=&msrows->aRow[i].lpProps[0];
					if (name==store && !eid.isempty())
					{
						hr = mapi_session->OpenMsgStore(PtrToUlong(hwnd),msrows->aRow[i].lpProps[0].Value.bin.cb,(LPENTRYID)msrows->aRow[i].lpProps[0].Value.bin.lpb, NULL, MDB_NO_DIALOG|MDB_WRITE, &mapi_msgstore);//MDB_NO_DIALOG|MDB_WRITE|MDB_NO_MAIL
						if (hr!=S_OK)
							mapi_msgstore=0;
					}
					
				}
				pFreeProws(msrows);
			}
			mstable->Release();
		}
		if (mapi_msgstore==0) {
			mapi_session->Logoff(0,0,0);
			mapi_session->Release();
			mapi_session=0;
			mapi_session_profile="";
			return 0;
		}
	}
	//
	// Now we have the msgstore. Let's get the human (intepersonal) subtree.
	// All the email folders are children of the human subtree.
	IMAPIFolder *ipmroot=0; mapi_TEntryid eid;
	LPSPropValue ipm_eid;
	hr = pHrGetOneProp(mapi_msgstore, PR_IPM_SUBTREE_ENTRYID, &ipm_eid);
	if (hr==S_OK)
	{
		eid = ipm_eid;
		pMAPIFreeBuffer(ipm_eid);
	}
	if (!eid.isempty())
	{
		ULONG ipmroottype;
		hr = mapi_msgstore->OpenEntry(eid.size,eid.ab,NULL,0,&ipmroottype,(IUnknown**)&ipmroot);
		if (hr==S_OK)
		{
			if (ipmroottype!=MAPI_FOLDER) {ipmroot->Release(); ipmroot=0;}
		}
	}
	if (ipmroot==0) 
		return 0;
	// the following recursive call does the work! puts the tree under "ipmroot" into mapi_Folders.
	mapi_RecEnsureFolders(ipmroot,0,"",&mapi_Folders);
	ipmroot->Release();
	return 1;
}

// REC-ENSURE-FOLDERS -- Given an IMAPIFolder, we recursively retrieve
// all the folders it contains, and stick them into the 'folders' list.
// Here, "depth" and "prefix" are straightforward recursive counters
// of how deep we are in the tree.
//
void CMapiStuffClient::mapi_RecEnsureFolders(IMAPIFolder *parent, int depth, string prefix, list<mapi_TFolderInfo> *folders)
{
	if (folders==0) return; if (parent==0) return;
	
	// NB. We cannot call parent->GetHierarchyTable. That's because GetHierarchyTable
	// tries to open it will full (read/write) access, but Outlook2000/IMO only supports
	// readonly access, hence giving an MAPI_E_NO_ACCESS error. Therefore, we get
	// the hierarchy in this roundabout way, in readonly mode.
	IMAPITable *hierarchy=0; HRESULT hr=0;
	const GUID local_IID_IMAPITable = {0x00020301,0,0, {0xC0,0,0,0,0,0,0,0x46}};
	hr = parent->OpenProperty(PR_CONTAINER_HIERARCHY,&local_IID_IMAPITable,0,0,(IUnknown**)&hierarchy);
	if (hr!=S_OK) return;
	// and query for all the rows
	SizedSPropTagArray(3, cols) = {3, {PR_ENTRYID,PR_DISPLAY_NAME,PR_SUBFOLDERS} };
	SRowSet *rows=0;
	hr = pHrQueryAllRows(hierarchy,(SPropTagArray*)&cols, NULL, NULL, 0, &rows);
	hierarchy->Release();
	if (hr!=S_OK) {pFreeProws(rows); return;}
	// Note: the entry-ids returned by the list are just short-term list-specific
	// entry-ids. But we want to put long-term entry-ids in our 'folder' list.
	// That's why it's necessary to open the folder...
	
	// Go through all the rows. For each entry, if it is a message-folder add it, and potentially recurse
	for (unsigned int i=0; i<rows->cRows; i++)
	{
		BOOL subfolders = rows->aRow[i].lpProps[2].Value.b;
		string name(rows->aRow[i].lpProps[1].Value.lpszA);
		IMAPIFolder *subf=0; ULONG subftype=0;
		hr = parent->OpenEntry(rows->aRow[i].lpProps[0].Value.bin.cb,
			(LPENTRYID)rows->aRow[i].lpProps[0].Value.bin.lpb, NULL,
			0, &subftype, (IUnknown**)&subf);
		if (hr==S_OK)
		{
			if (subftype == MAPI_FOLDER)
			{
				LPSPropValue veid=0;
				hr = pHrGetOneProp(subf, PR_ENTRYID, &veid); // get its long-term eid
				if (hr==S_OK){
					mapi_TFolderInfo f;
					f.depth=depth; f.name=name; f.path=prefix+name;
					f.eid = veid;
					f.type = mapi_GetFolderType(f.eid,subf);
					bool usefolder = (f.type==mftInbox||f.type==mftMail);//||f.type==mftSent||f.type==mftStuff
					if (usefolder){
						if(sets.sFolderMask!="" && sets.sFolderMask!="*"){
							if(!PatternMatchList(name.c_str(),sets.sFolderMask)){
								continue;
							}
						}
						folders->push_back(f);
					}
					pMAPIFreeBuffer(veid);
					if (usefolder && subfolders) 
						mapi_RecEnsureFolders(subf,depth+1,prefix+name+"\\",folders);
				}
			}
			subf->Release();
		}
	}
	
	pFreeProws(rows);
}

// GET-FOLDER-TYPE -- given a folder and its long-term entry-id,
// returns its type (inbox/outbox/calendar/...). There are three
// techniques for doing this; we do them all, in order of preference.
//
mapi_TFolderType CMapiStuffClient::mapi_GetFolderType(mapi_TEntryid &eid, IMAPIFolder *f)
{
	// 1. Most assured way to get the type of a folder is to check
	// whether it's long-term ENTRYID is the same as one of the
	// standard ones. See the EnsureCommonEids() routine for an
	// explanation of how we retrieve the standard ones.
	mapi_EnsureCommonEids();
	if (eid.isequal(mapi_session,eid_inbox)) return mftInbox;
	if (eid.isequal(mapi_session,eid_outbox)) return mftOutbox;
	if (eid.isequal(mapi_session,eid_sent)) return mftSent;// ���� �� ��������
	if (eid.isequal(mapi_session,eid_deleted)) return mftDeleted;// ���� �� ��������
	// 2. Second best way, specific to Outlook, is to see if
	// it's equal to one of the Outlook specific ones.
	if (eid.isequal(mapi_session,eid_calendar)) return mftCalendar;
	if (eid.isequal(mapi_session,eid_contacts)) return mftContacts;
	if (eid.isequal(mapi_session,eid_journal)) return mftJournal;
	if (eid.isequal(mapi_session,eid_notes)) return mftNotes;
	if (eid.isequal(mapi_session,eid_tasks)) return mftTasks;
	// 3. Third best way (and the only other way) is to check
	// it's PR_CONTAINER_CLASS property. The documentation says
	// that this shouldn't be used, but apparently the documentation
	// is out of date. The documentation says that everything
	// begins with IPM, but I'm sure I've seen an IPF somewhere.
	LPSPropValue sp;
	HRESULT hr = pHrGetOneProp(f, PR_CONTAINER_CLASS, &sp);
	if (hr!=S_OK) return mftStuff;
	string s(sp->Value.lpszA);
	pMAPIFreeBuffer(sp);
	if (s.length()>3 && s[0]=='I' && s[1]=='P') s[2]='.'; // not sure IPM or IPF.
	const char *c=s.c_str();
	if (strncmp(c,"IP..Note",8)==0) return mftMail;
	else if (strncmp(c,"IP..Imap",9)==0) return mftMail;
	else if (strncmp(c,"IP..Appointment",15)==0) return mftCalendar;
	else if (strncmp(c,"IP..Contact",11)==0) return mftContacts;
	else if (strncmp(c,"IP..Journal",11)==0) return mftJournal;
	else if (strncmp(c,"IP..StickyNote",14)==0) return mftNotes;
	else if (strncmp(c,"IP..Task",8)==0) return mftTasks;
	else if (strncmp(c,"IP..",4)==0) return mftSpecial;
	else return mftStuff;
}



// ENSURE-COMMON-EIDS -- There are some standard ENTRYIDs for some standard
// folders. This function sets up these in global variables. Note that they
// are specific to the current library, profile and message-store. For an
// explanation of how to retrieve each type, see inside the procedure.
//
void CMapiStuffClient::mapi_EnsureCommonEids()
{
	if (got_eids) 
		return;
	ULONG pcount=0;
	LPSPropValue props=0;
	eid_inbox.clear(); eid_outbox.clear(); eid_sent.clear(); eid_deleted.clear();
	eid_calendar.clear(); eid_contacts.clear(); eid_journal.clear(); eid_notes.clear(); eid_tasks.clear();
	got_eids=true;
	if (mapi_msgstore==0)
		return;
	DWORD size=0;
	ENTRYID *eid=0;
	HRESULT hr=0;
	// 1. INBOX special folder -- in fact, the user can designate any folder as
	// an inbox. All we can do is check where incoming IPM.Note messages (i.e. emails)
	// are placed.
	hr = mapi_msgstore->GetReceiveFolder("IPM.Note",0,&size,&eid,NULL);
	if (hr==S_OK){
		eid_inbox.set(size,eid);
	}
	// 2. Other special folders. The message-store has properties for these.
	SizedSPropTagArray(4, cols) = { 4, {PR_VALID_FOLDER_MASK, PR_IPM_OUTBOX_ENTRYID, PR_IPM_SENTMAIL_ENTRYID, PR_IPM_WASTEBASKET_ENTRYID} };
	hr = mapi_msgstore->GetProps((SPropTagArray*)&cols,0,&pcount,&props);
	if (hr==S_OK || hr==MAPI_W_ERRORS_RETURNED){
		LONG mask;
		if (props[0].ulPropTag!=PT_ERROR){
			mask=props[0].Value.ul;
		}else{
			mask=0;
		}
		if ((mask&FOLDER_IPM_OUTBOX_VALID) && props[1].ulPropTag!=PT_ERROR && props[1].ulPropTag==PR_IPM_OUTBOX_ENTRYID){
			eid_outbox.set(props[1].Value.bin.cb, (ENTRYID*)props[1].Value.bin.lpb);
		}
		if ((mask&FOLDER_IPM_SENTMAIL_VALID) && props[2].ulPropTag!=PT_ERROR && props[2].ulPropTag==PR_IPM_SENTMAIL_ENTRYID) {
			eid_sent.set(props[2].Value.bin.cb, (ENTRYID*)props[2].Value.bin.lpb);
		}
		if ((mask&FOLDER_IPM_WASTEBASKET_VALID) && props[3].ulPropTag!=PT_ERROR && props[3].ulPropTag==PR_IPM_WASTEBASKET_ENTRYID) {
			eid_deleted.set(props[3].Value.bin.cb, (ENTRYID*)props[3].Value.bin.lpb);
		}
		pMAPIFreeBuffer(props);
	}
	// 3. The outlook specials. The inbox has properties for these.
	if (eid_inbox.isempty())
		return;
	ULONG intype;
	IMAPIFolder *infolder=0;
	hr = mapi_msgstore->OpenEntry(eid_inbox.size, eid_inbox.ab, NULL, 0, &intype, (IUnknown**)&infolder);
	if (hr!=S_OK)
		return;
	if (intype!=MAPI_FOLDER) {
		infolder->Release();
		return;
	}
	SizedSPropTagArray(5, spec) = {5, {0x36D00102, 0x36D10102, 0x36D20102, 0x36D30102, 0x36D40102}};
	hr = infolder->GetProps((SPropTagArray*)&spec,0,&pcount,&props);
	if (hr==S_OK || hr==MAPI_W_ERRORS_RETURNED)
	{
		if (props[0].ulPropTag!=PT_ERROR) eid_calendar.set(props[0].Value.bin.cb, (ENTRYID*)props[0].Value.bin.lpb);
		if (props[1].ulPropTag!=PT_ERROR) eid_contacts.set(props[1].Value.bin.cb, (ENTRYID*)props[1].Value.bin.lpb);
		if (props[2].ulPropTag!=PT_ERROR) eid_journal.set(props[2].Value.bin.cb, (ENTRYID*)props[2].Value.bin.lpb);
		if (props[3].ulPropTag!=PT_ERROR) eid_notes.set(props[3].Value.bin.cb, (ENTRYID*)props[3].Value.bin.lpb);
		if (props[4].ulPropTag!=PT_ERROR) eid_tasks.set(props[4].Value.bin.cb, (ENTRYID*)props[4].Value.bin.lpb);
		pMAPIFreeBuffer(props);
	}
}

// mapi_UnloadExchange -- releases any interfaces that we might have obtained
// through the other functions.
void CMapiStuffClient::mapi_UnloadExchange()
{
	got_eids=false;
	maildrop_size=0;
	mapi_Folders.clear();
	mapi_Messages.clear();
	mapi_msgstore_name=""; if (mapi_msgstore!=0) mapi_msgstore->Release(); mapi_msgstore=0;
	mapi_session_profile=""; if (mapi_session!=0) {mapi_session->Logoff(0,0,0);mapi_session->Release();mapi_session=0;}
	mapi_Stores.clear();
	if (hmapilib!=0)
	{
		IProfAdmin *iprofadmin=0;
		HRESULT hr = pMAPIAdminProfiles(0,&iprofadmin);
		if (hr==S_OK)
		{
			mapi_EnsureCrazyProfileDeleted(iprofadmin);
			iprofadmin->Release();
		}
	}
	mapi_lib_path=""; 
	if (hmapilib!=0) {
		SetTooltipText("Closing Exchange",1);
		pMAPIUninitialize();
		FreeLibrary(hmapilib);
		hmapilib=0;
	}
}



// MAPI_ENSURECRAZYPROFILEDELETED -- In case we had created a temporary profile,
// this function ensures that it is deleted.
// Note: it is a *SEVERE* error if you try to delete a profile that's not there.
// Under Outlook2000 in IMO, attempting to do this will delete every message-store
// of the main profile. Gulp! Hence, our care in this function...
//
void CMapiStuffClient::mapi_EnsureCrazyProfileDeleted(IProfAdmin *iprofadmin)
{
	bool gotcrazy=false;
	IMAPITable *proftable=0;
	HRESULT hr = iprofadmin->GetProfileTable(0, &proftable);
	if (hr==S_OK)
	{
		SizedSPropTagArray(2, proftablecols) = { 2, {PR_DISPLAY_NAME,PR_DEFAULT_PROFILE} };
		SRowSet *profrows=0;
		hr = pHrQueryAllRows(proftable,(SPropTagArray*)&proftablecols,NULL,NULL,0,&profrows);
		if (hr==S_OK)
		{
			for (unsigned int i=0; i<profrows->cRows; i++)
			{
				string name="";
				if (profrows->aRow[i].lpProps[0].ulPropTag==PR_DISPLAY_NAME) name=profrows->aRow[i].lpProps[0].Value.lpszA;
				if (name=="WPLabsTemp_Profile") gotcrazy=true;
			}
			pFreeProws(profrows);
		}
		proftable->Release();
	}
	if (gotcrazy) iprofadmin->DeleteProfile("WPLabsTemp_Profile",0);
}

// DECODERTFHTML -- Given an uncompressed RTF body of the message,
// and assuming that it contains encoded-html, this function
// turns it onto regular html.
// [in] (buf,*len) indicate the start and length of the uncompressed RTF body.
// [out] the buffer is overwritten with the HTML version, null-terminated,
// and *len indicates the length of this HTML.
//
// Notes: (1) because of how the encoding works, the HTML version is necessarily
// shorter than the encoded version. That's why it's safe for the function to
// place the decoded html in the same buffer that formerly held the encoded stuff.
// (2) Some messages include characters \'XX, where XX is a hexedecimal number.
// This function simply converts this into ASCII. The conversion will only make
// sense if the right code-page is being used. I don't know how rtf specifies which
// code page it wants.
// (3) By experiment, I discovered that \pntext{..} and \liN and \fi-N are RTF
// markup that should be removed. There might be other RTF markup that should
// also be removed. But I don't know what else.
//
void CMapiStuffClient::decodertfhtml(char *buf,unsigned int *len)
{
	// c -- pointer to where we're reading from
	// d -- pointer to where we're writing to. Invariant: d<c
	// max -- how far we can read from (i.e. to the end of the original rtf)
	// ignore_tag -- stores 'N': after \mhtmlN, we will ignore the subsequent \htmlN.
	char *c=buf, *max=buf+*len, *d=buf; int ignore_tag=-1;
	// First, we skip forwards to the first \htmltag.
	while (c<max && strncmp(c,"{\\*\\htmltag",11)!=0) c++;
	//
	// Now work through the document. Our plan is as follows:
	// * Ignore { and }. These are part of RTF markup.
	// * Ignore \htmlrtf...\htmlrtf0. This is how RTF keeps its equivalent markup separate from the html.
	// * Ignore \r and \n. The real carriage returns are stored in \par tags.
	// * Ignore \pntext{..} and \liN and \fi-N. These are RTF junk.
	// * Convert \par and \tab into \r\n and \t
	// * Convert \'XX into the ascii character indicated by the hex number XX
	// * Convert \{ and \} into { and }. This is how RTF escapes its curly braces.
	// * When we get \*\mhtmltagN, keep the tag, but ignore the subsequent \*\htmltagN
	// * When we get \*\htmltagN, keep the tag as long as it isn't subsequent to a \*\mhtmltagN
	// * All other text should be kept as it is.
	while (c<max)
	{
		if (*c=='{') c++;
		else if (*c=='}') c++;
		else if (strncmp(c,"\\*\\htmltag",10)==0)
		{
			c+=10; int tag=0; while (*c>='0' && *c<='9') {tag=tag*10+*c-'0'; c++;}
			if (*c==' ') c++;
			if (tag==ignore_tag) {while (c<max && *c!='}') c++; if (*c=='}') c++;}
			ignore_tag=-1;
		}
		else if (strncmp(c,"\\*\\mhtmltag",11)==0)
		{
			c+=11; int tag=0; while (*c>='0' && *c<='9') {tag=tag*10+*c-'0'; c++;}
			if (*c==' ') c++;
			ignore_tag=tag;
		}
		else if (strncmp(c,"\\par",4)==0) {strcpy(d,"\r\n"); d+=2; c+=4; if (*c==' ') c++;}
		else if (strncmp(c,"\\tab",4)==0) {strcpy(d,"   "); d+=3; c+=4; if (*c==' ') c++;}
		else if (strncmp(c,"\\li",3)==0)
		{
			c+=3; while (*c>='0' && *c<='9') c++; if (*c==' ') c++;
		}
		else if (strncmp(c,"\\fi-",4)==0)
		{
			c+=4; while (*c>='0' && *c<='9') c++; if (*c==' ') c++;
		}
		else if (strncmp(c,"\\'",2)==0)
		{
			unsigned int hi=c[2], lo=c[3];
			if (hi>='0' && hi<='9') hi-='0'; else if (hi>='A' && hi<='Z') hi=hi-'A'+10; else if (hi>='a' && hi<='z') hi=hi-'a'+10;
			if (lo>='0' && lo<='9') lo-='0'; else if (lo>='A' && lo<='Z') lo=lo-'A'+10; else if (lo>='a' && lo<='z') lo=lo-'a'+10;
			*((unsigned char*)d) = (unsigned char)(hi*16+lo);
			c+=4; d++;
		}
		else if (strncmp(c,"\\pntext",7)==0) {c+=7; while (c<max && *c!='}') c++;}
		else if (strncmp(c,"\\htmlrtf",8)==0)
		{
			c++; while (c<max && strncmp(c,"\\htmlrtf0",9)!=0) c++;
			if (c<max) c+=9; if (*c==' ') c++;
		}
		else if (*c=='\r' || *c=='\n') c++;
		else if (strncmp(c,"\\{",2)==0) {*d='{'; d++; c+=2;}
		else if (strncmp(c,"\\}",2)==0) {*d='}'; d++; c+=2;}
		else {*d=*c; c++; d++;}
	}
	*d=0; d++;
	*len = (unsigned int)(d-buf);
}


bool CMapiStuffClient::isrtfhtml(const char *buf,unsigned int len)
{
	// We look for the words "\fromhtml" somewhere in the file.
	// If the rtf encodes text rather than html, then instead
	// it will only find "\fromtext".
	for (const char *c=buf; c<buf+len; c++)
	{
		if (strncmp(c,"\\from",5)==0) return strncmp(c,"\\fromhtml",9)==0;
	} return false;
}

// These three utility functions are not provided with Outlook97. That's
// why I'm reimplementing them here.
HRESULT CMapiStuffClient::pHrGetOneProp(IMAPIProp *obj, ULONG tag, LPSPropValue*pProp)
{
	if (pProp==0) return E_POINTER;
	ULONG pcount; HRESULT hr;
	SizedSPropTagArray(1, cols) = { 1, {tag}};
	hr = obj->GetProps((SPropTagArray*)&cols,0,&pcount,pProp);
	if (hr==S_OK) return S_OK;
	if (hr==MAPI_W_ERRORS_RETURNED) {
		pMAPIFreeBuffer(*pProp); 
		return MAPI_E_NOT_FOUND;
	}
	return hr;
}

HRESULT CMapiStuffClient::pHrSetOneProp(LPMAPIPROP obj,LPSPropValue lpProp)
{
	HRESULT hr = obj->SetProps(1,lpProp,0);
	return hr;
}

void CMapiStuffClient::pFreeProws(SRowSet *r)
{
	if (r==0) return;
	for (unsigned int i=0; i<r->cRows; i++)
	{
		LPSPropValue pv = r->aRow[i].lpProps;
		pMAPIFreeBuffer(pv);
	}
	pMAPIFreeBuffer(r);
}

HRESULT CMapiStuffClient::pHrQueryAllRows(IMAPITable *table, SPropTagArray *tags, SRestriction *res,
									   SSortOrderSet *sort, LONG crowsMax, SRowSet **rows)
{
	if (tags!=0) table->SetColumns(tags,0);
	if (res!=0) table->Restrict(res,0);
	if (sort!=0) table->SortTable(sort,0);
	if (crowsMax==0) crowsMax=0x0FFFFFFF;
	HRESULT hr = MAPI_E_BUSY;
	while (hr==MAPI_E_BUSY)
	{
		hr = table->QueryRows(crowsMax,TBL_NOADVANCE,rows);
		if (hr==MAPI_E_BUSY)
		{
			hr=table->WaitForCompletion(0,1000,NULL);
			if (hr!=MAPI_E_NO_SUPPORT) hr=MAPI_E_BUSY;
		}
	}
	return hr;
}

// Here are just some internal functions for accessing the registry...
//
list<string> CMapiStuffClient::mapi_RegQuerySubkeys(HKEY key)
{
	list<string> ss; LONG res; DWORD index=0; char buf[1024]; FILETIME ft;
	while (true)
	{
		DWORD size=1024;
		res = RegEnumKeyEx(key,index,buf,&size,NULL,NULL,NULL,&ft);
		if (res!=ERROR_SUCCESS) return ss;
		ss.push_back(buf);
		index++;
	}
}

string CMapiStuffClient::mapi_RegQueryString(HKEY key,const string name)
{
	DWORD type, size=0; LONG res;
	res = RegQueryValueEx(key,name.c_str(),NULL,&type,NULL,&size);
	if (res!=ERROR_SUCCESS) return "";
	if (type!=REG_SZ && type!=REG_EXPAND_SZ) return "";
	char *c=new char[size+1];
	res = RegQueryValueEx(key,name.c_str(),NULL,&type,(BYTE*)c,&size);
	if (res!=ERROR_SUCCESS) {delete[] c; return "";}
	if (type==REG_EXPAND_SZ)
	{
		char dummy[1]; DWORD esize=ExpandEnvironmentStrings(c,dummy,0);
		if (esize!=0)
		{
			char *d=new char[esize+1];
			ExpandEnvironmentStrings(c,d,esize+1);
			delete[] c; c=d;
		}
	}
	string r(c);
	delete[] c;
	return r;
}

//////////////////////////////////////////////////////////////////////
// add an "One-Off" (created on the fly) recipient to a message
//////////////////////////////////////////////////////////////////////
HRESULT CMapiStuffClient::mapi_AddOneOff(IAddrBook* pAdrBook, IMessage* pMsg, char* pszDisplayName, char* pszEmailAddress, char* pszAddrType, long lRecipientType)
{
# define PVAL(ID, TAG) pAdrList->aEntries[ID].rgPropVals[TAG]
	
	if(!pszDisplayName) pszDisplayName=pszEmailAddress;
	HRESULT hRes=S_OK;
	LPADRLIST pAdrList=NULL;
	enum {NAME, ADDR, MAIL, RECP, EID, NUM_RECIP_PROPS};
	LPSPropValue pPropArray = NULL;	
	try
	{
		if(FAILED(hRes=pMAPIAllocateBuffer(CbNewSRowSet(1), (LPVOID*)&pAdrList))) throw hRes;
		if(FAILED(hRes=pMAPIAllocateBuffer(NUM_RECIP_PROPS*sizeof(SPropValue), (LPVOID*)&pPropArray))) throw hRes;
		pAdrList->aEntries[0].rgPropVals=pPropArray;
		// Setup the One Time recipient by indicating how many recipients and how many properties will be set on each recipient
		pAdrList->cEntries=1;
		pAdrList->aEntries[0].cValues=NUM_RECIP_PROPS;
		
		// Set the SPropValue members == the desired values
		PVAL(0, NAME).ulPropTag = PR_DISPLAY_NAME;
		PVAL(0, NAME).Value.lpszA = pszDisplayName;
		PVAL(0, ADDR).ulPropTag = PR_ADDRTYPE;
		PVAL(0, ADDR).Value.lpszA = pszAddrType;
		PVAL(0, MAIL).ulPropTag = PR_EMAIL_ADDRESS;
		PVAL(0, MAIL).Value.lpszA = pszEmailAddress;
		PVAL(0, RECP).ulPropTag = PR_RECIPIENT_TYPE;
		PVAL(0, RECP).Value.l = lRecipientType;
		PVAL(0, EID).ulPropTag = PR_ENTRYID;
		
		// Create the One-off address and get an EID for it
		if(FAILED(
			hRes=pAdrBook->CreateOneOff(
			PVAL(0, NAME).Value.lpszA,
			PVAL(0, ADDR).Value.lpszA,
			PVAL(0, MAIL).Value.lpszA,
			MAPI_SEND_NO_RICH_INFO, // don't send rich info (TNEF/"winmail.dat")
			&PVAL(0, EID).Value.bin.cb,
			(LPENTRYID*)(&PVAL(0,EID).Value.bin.lpb))
			)) throw hRes;
		if(FAILED(hRes=pAdrBook->ResolveName(0L, 0L, NULL, pAdrList))) throw hRes;
		
		// If everything goes right, add the new recipient to the message object passed
		if(FAILED(hRes=pMsg->ModifyRecipients(MODRECIP_ADD,pAdrList))) throw hRes;
	} // try
	catch(HRESULT hr)
	{
		hRes=hr;
	}
	
	// Always release any newly created objects and allocated memory
	if (pPropArray)	
		pMAPIFreeBuffer(pPropArray);
	if (pAdrList){
		pMAPIFreeBuffer(pAdrList);//pFreePadrlist();
	}
	return hRes;
# undef PVAL
}

//////////////////////////////////////////////////////////////////////
// write a property to object from memory using IStream interface
//////////////////////////////////////////////////////////////////////
HRESULT CMapiStuffClient::mapi_WritePropStream(IMAPIProp* pProp, unsigned long ulProp, const void* pv, unsigned long ulLen)
{
# define MAPI_CHUNK 512
	
	//assert(PT_STRING8==PROP_TYPE(ulProp) || PT_UNICODE==PROP_TYPE(ulProp) || PT_BINARY==PROP_TYPE(ulProp)); // only strings and binary data are valid for streaming
	
	HRESULT hRes=S_OK;
	IStream* pStream=NULL;
	unsigned long ul, ulWritten=0;
	
	try
	{
		if(FAILED(hRes=pProp->OpenProperty(ulProp, &IID_IStream, STGM_WRITE, MAPI_CREATE|MAPI_MODIFY, (IUnknown**)&pStream))) throw hRes;
		while(ulLen)
		{
			ul=min((unsigned long)MAPI_CHUNK, ulLen);
			if(FAILED(hRes=pStream->Write(pv, ul, &ulWritten))) throw hRes;
			if(ulWritten!=ul) throw (long)ERROR_INVALID_BLOCK_LENGTH;
			pv=(void*)((char*)pv+ul);
			ulLen-=ul;
		} // while(ulLen)
		if(FAILED(hRes=pStream->Commit(STGC_DEFAULT))) throw hRes;
	}
	catch(HRESULT hr)
	{
		hRes=hr;
	}
	
	if(pStream) pStream->Release();
	return hRes;
	
# undef MAPI_CHUNK
} 


CString NormalizeEncoding(CString& str, CString sDefCharset)
{
	// ����� ����� rpmfind ����� ����� mimelib �� KDE � ������� �� ����
	CString m_sCharset;
    str=DecodeHeaderValue(str, &m_sCharset);
	if (m_sCharset.GetLength()==0){
		m_sCharset=sDefCharset;
	}
    if (m_sCharset.GetLength()>0){
        str = CCharsetDecoder(m_sCharset).Decode(str);
	}
	return m_sCharset;
}


HRESULT CMapiStuffClient::SetReplyTo(LPMESSAGE lpMessage, LPSTR pszReplyTo)
{
    HRESULT hRes = S_OK;
    LPADRLIST lpAddrList = NULL;
    LPADRBOOK lpAddrBook = NULL;
    SPropValue pspvReply[2];
    LPFLATENTRYLIST lpReplyEntryList = NULL;
    LPFLATENTRY lpReplyEntry = NULL;
    int cValues = 2;
    ULONG i = 0;
	
    // Allocate an address list structure.
    int cb = CbNewADRLIST(1);
	
    hRes = pMAPIAllocateBuffer(cb, (LPVOID *)&lpAddrList);
    if (FAILED(hRes)) goto Cleanup;
	
    ZeroMemory(lpAddrList, cb);
	
    hRes = pMAPIAllocateBuffer(cValues * sizeof(SPropValue),(LPVOID FAR *)&lpAddrList->aEntries[0].rgPropVals);
    if (FAILED(hRes)) goto Cleanup;
	
    // Open the address book to resolve Reply To recipient.
    hRes = mapi_session->OpenAddressBook(0, NULL, 0, &lpAddrBook);
    if (FAILED(hRes)) goto Cleanup;
	
    // Set up address list structure.
    lpAddrList->cEntries = 1;
    lpAddrList->aEntries[0].rgPropVals[0].ulPropTag = PR_DISPLAY_NAME;
    lpAddrList->aEntries[0].rgPropVals[0].Value.lpszA = pszReplyTo;
	
    lpAddrList->aEntries[0].rgPropVals[1].ulPropTag = PR_RECIPIENT_TYPE;
    lpAddrList->aEntries[0].rgPropVals[1].Value.l = MAPI_TO;
    lpAddrList->aEntries[0].cValues = cValues;
	
    // Resolve name.
    hRes = lpAddrBook->ResolveName(0, 0, NULL, lpAddrList);
    if (FAILED(hRes)) goto Cleanup;
	
    // Get the Entry ID.
    for (i = 0; i < lpAddrList->aEntries[0].cValues; i++)
    {
        if (lpAddrList->aEntries[0].rgPropVals[i].ulPropTag == PR_ENTRYID)
        {
            // Allocate a new FLATENTRY structure for
            // the PR_REPLY_RECIPIENT_ENTRIES property.
            cb = CbNewFLATENTRY(lpAddrList->aEntries[0].rgPropVals[i].Value.bin.cb);
            hRes = pMAPIAllocateBuffer(cb, (LPVOID *)&lpReplyEntry);
            if (FAILED(hRes)) goto Cleanup;
            ZeroMemory((VOID *)lpReplyEntry, cb);
			
            // Copy the bits of the Entry ID into the FLATENTRY structure.
            CopyMemory(lpReplyEntry->abEntry,
				lpAddrList->aEntries[0].rgPropVals[i].Value.bin.lpb,
				lpAddrList->aEntries[0].rgPropVals[i].Value.bin.cb);
            lpReplyEntry->cb = lpAddrList->
				aEntries[0].rgPropVals[i].Value.bin.cb;
			
            // Allocate a new FLATENTRYLIST structure.
            // This is what is stored in PR_REPLY_RECIPIENT_ENTRIES.
            cb = CbNewFLATENTRYLIST(cb);
            hRes = pMAPIAllocateBuffer(cb, (LPVOID *)&lpReplyEntryList);
            if (FAILED(hRes)) goto Cleanup;
            ZeroMemory((VOID *)lpReplyEntryList, cb);
			
            // Copy the bits of the FLATENTRY into the FLATENTRYLIST.
            lpReplyEntryList->cEntries  = 1;
            lpReplyEntryList->cbEntries = CbFLATENTRY(lpReplyEntry);
            CopyMemory(lpReplyEntryList->abEntries,
				lpReplyEntry, CbFLATENTRY(lpReplyEntry));
			
            // Force exit from the loop.
            i = lpAddrList->aEntries[0].cValues;
        }
    }
	
    // Set PR_REPLY_RECIPIENT_NAMES.
    pspvReply[0].ulPropTag = PR_REPLY_RECIPIENT_NAMES;
    pspvReply[0].Value.lpszA = pszReplyTo;
	
    // Set PR_REPLY_RECIPIENT_ENTRIES.
    pspvReply[1].ulPropTag = PR_REPLY_RECIPIENT_ENTRIES;
    // Allocate memory in the lpb to hold the FLATENTRYLIST
    hRes = pMAPIAllocateBuffer(CbFLATENTRYLIST(lpReplyEntryList),
		(LPVOID *)&pspvReply[1].Value.bin.lpb);
    // Copy the memory into the SPropValue.
    CopyMemory(pspvReply[1].Value.bin.lpb,
		lpReplyEntryList,
		CbFLATENTRYLIST(lpReplyEntryList));
    pspvReply[1].Value.bin.cb = CbFLATENTRYLIST(lpReplyEntryList);
	
    // Set the properties.
    hRes = lpMessage->SetProps(2,pspvReply,NULL);
	
Cleanup:
    if (lpReplyEntry) pMAPIFreeBuffer(lpReplyEntry);
    if (lpReplyEntryList) pMAPIFreeBuffer(lpReplyEntryList);
	if (lpAddrList->aEntries[0].rgPropVals) pMAPIFreeBuffer(lpAddrList->aEntries[0].rgPropVals);
    if (lpAddrList)	pMAPIFreeBuffer(lpAddrList);//pFreePadrlist(lpAddrList);
    if (lpAddrBook) lpAddrBook->Release();
    return hRes;
}

HRESULT CMapiStuffClient::AddPersonToEmail(IMessage* pMsg,const char* szEmail,long lRecipType,long lModifyType)
{
	HRESULT hr=S_OK;
	LPADRBOOK pAdrBook = NULL;
	hr = mapi_session->OpenAddressBook(0, 0, MAPI_ACCESS_MODIFY, &pAdrBook );
	if (!FAILED(hr)){
		ADRLIST * pal = NULL;
		LPSPropValue pPropArray = NULL;
		// Prepare recipients list...
		pMAPIAllocateBuffer(CbNewADRLIST(1), (LPVOID *) &pal);
		pMAPIAllocateBuffer(4 * sizeof(SPropValue), (LPVOID*) &pPropArray);
		int iRCCount=0;
		pPropArray[iRCCount].ulPropTag = PR_RECIPIENT_TYPE;
		pPropArray[iRCCount].Value.l = lRecipType;
		iRCCount++;
		CString sType="SMTP";
		CString sAddr=Format("[smtp:%s]",szEmail);
		if((sAddr.Find("T[")!=-1 && sAddr.Find("N[")!=-1 && sAddr.Find("E[")!=-1)||(sAddr.Find("/O=")!=-1)){
			CString sFullAddr=szEmail;
			sFullAddr.Replace("&nbsp"," ");
			CString sInternalEmail="";
			if(sAddr.Find("/O=")!=-1){
				sType="EX";
				sAddr=CDataXMLSaver::GetInstringPartGreedly("/CN=",">",sFullAddr+">");
				sInternalEmail=sFullAddr;
			}else{
				sType=CDataXMLSaver::GetInstringPart("T[","]",sFullAddr);
				sAddr=CDataXMLSaver::GetInstringPart("N[","]",sFullAddr);
				sInternalEmail=CDataXMLSaver::GetInstringPart("E[","]",sFullAddr);
			}
			sInternalEmail.Replace("\\",Format("\\x%02x",'\\'));
			sInternalEmail.Replace(" ",Format("\\x%02x",' '));
			sInternalEmail.Replace("/",Format("\\x%02x",'/'));
			sInternalEmail.Replace("`",Format("\\x%02x",'`'));
			sInternalEmail.Replace("'",Format("\\x%02x",'\''));
			sAddr=Format("%s[%s:%s]",sAddr,sType,sInternalEmail);
		}
		pPropArray[iRCCount].ulPropTag = PR_DISPLAY_NAME;
		pPropArray[iRCCount].Value.lpszA = sAddr.GetBuffer(10);
		iRCCount++;
		pPropArray[iRCCount].ulPropTag = PR_ADDRTYPE;
		pPropArray[iRCCount].Value.lpszA = sType.GetBuffer(10);  // Exchange address type
		iRCCount++;
		pal->cEntries = 1;
		pal->aEntries[0].ulReserved1 = 0;
		pal->aEntries[0].cValues = iRCCount;   // This "3" is important, otherwise the ResolveName fails!
		pal->aEntries[0].rgPropVals = pPropArray;
		// Call IAdrBook::ResolveName method to resolve display names in our list to entry IDs.
		hr = pAdrBook->ResolveName(0, 0, NULL, pal);
		if (!FAILED(hr)){
			// Insert our recipients list into the message
			hr = pMsg->ModifyRecipients(lModifyType, pal);
		}
		if (pPropArray){
			pMAPIFreeBuffer(pPropArray);
			pPropArray=0;
		}
		if (pal){
			pMAPIFreeBuffer(pal);
			pal=0;
		}
		pAdrBook->Release();
	}
	return hr;
}

HRESULT CMapiStuffClient::AddRecipientsFromList(vector<string>& smtpRecip,IMessage* &pMsg, CString& sCC, CString& sBCC)
{
	sCC.TrimLeft();
	sCC.TrimRight();
	sBCC.TrimLeft();
	sBCC.TrimRight();
	HRESULT hr=S_OK;
	int iRecipCount=0;
	for (vector<string>::const_iterator i=smtpRecip.begin(); i!=smtpRecip.end(); i++){
		long lRecipType=MAPI_TO;
		if(sCC.Find(i->c_str())!=-1){
			lRecipType=MAPI_CC;
		}else if(iRecipCount>0 || sBCC.Find(i->c_str())!=-1){
			lRecipType=MAPI_BCC;
		}
		long lModifyType=(iRecipCount==0?0:MODRECIP_ADD);
		hr=AddPersonToEmail(pMsg,i->c_str(),lRecipType,lModifyType);
		if(FAILED(hr)){
			return hr;
		}
		iRecipCount++;
	}
	return hr;
}

// Force a message to be sent in plaintext (no multipart/alternative or HTML/RTF)
//
HRESULT CMapiStuffClient::mapi_ForcePlaintext(IMessage *pMessage)
{
	// http://support.microsoft.com/default.aspx?scid=kb;en-us;816477
	static const GUID PlaintxtGUID={0x00062008, 0x0000, 0x0000, {0xC0, 0x00,
		0x0, 0x00, 0x00, 0x00, 0x00, 0x046}};
	MAPINAMEID PlaintxtNameID={(GUID*)&PlaintxtGUID, MNID_ID, 0x8582L};
	MAPINAMEID *rgpnameid[1]={&PlaintxtNameID};
	SPropTagArray* lpSPropTags=NULL;
	SPropValue PropPR_MSG_EDITOR_FORMAT={PR_MSG_EDITOR_FORMAT, 0,EDITOR_FORMAT_PLAINTEXT}, *pPlaintextProp=NULL;
	HRESULT hr=S_OK;
	
	try
	{
		if(FAILED(hr=pHrSetOneProp(pMessage, &PropPR_MSG_EDITOR_FORMAT))) throw
			hr;
		if(SUCCEEDED(pMessage->GetIDsFromNames(1, rgpnameid, 0,
			&lpSPropTags)))
		{
			// http://support.microsoft.com/default.aspx?scid=kb;en-us;816477
			if(
				SUCCEEDED(pHrGetOneProp(pMessage, PROP_TAG(PT_BOOLEAN,
				PROP_ID(lpSPropTags->aulPropTag[0])), &pPlaintextProp)) &&
				pPlaintextProp->Value.b==TRUE
				)
			{
				pPlaintextProp->Value.b=FALSE;
				if(FAILED(hr=pHrSetOneProp(pMessage, pPlaintextProp))) throw hr;
			} // if(SUCCEEDED(HrGetOneProp( ...
		} // if(SUCCEEDED(hRes=pMsg->GetIDsFromNames(1, rgpnameid, 0,&lpSPropTags)))
		//if(FAILED(hr=pMessage->SaveChanges(KEEP_OPEN_READWRITE))) throw hr;
	} // try
	catch(long l)
	{
		hr=l;
	}
	
	if(pPlaintextProp) pMAPIFreeBuffer(pPlaintextProp);
	if(lpSPropTags)    pMAPIFreeBuffer(lpSPropTags);
	return hr;
}

bool CMapiStuffClient::mapi_EnsureSendMsg(HWND hwnd, vector<string>& smtpRecip,const char* email, HRESULT& hr)
{
	if(eid_outbox.isempty()){
		for (list<mapi_TStoreInfo>::const_iterator iS=mapi_Stores.begin(); iS!=mapi_Stores.end(); iS++){
			if(iS->store.length()>0){
				mapi_EnsureFolders(hwnd,iS->profile,iS->store,sets.lDoNotActSend?1:0);
				if(!eid_outbox.isempty()){
					break;
				}
			}
		}
	}
	if(eid_outbox.isempty() || smtpRecip.size()==0){
		_log(0,"ERROR: no outbox found or recipients list is empty");
		return false;
	}
	mapi_TEntryid* outFolderId=&eid_outbox;
	IMAPIFolder *ifolder=0; ULONG ftype=0;
	hr = mapi_msgstore->OpenEntry(outFolderId->size,outFolderId->ab, NULL, MAPI_MODIFY,&ftype,(IUnknown**)&ifolder);
	if(hr != S_OK){
		_log(0,"ERROR: Failed to open outbox");
		return false;
	}
	_log(0,"- Sending message to '%s' (recipents count=%i)",smtpRecip[0].c_str(),smtpRecip.size());
	bool bRes=false;
	IMessage* pMsg=0;
	// Create a message in there
	hr = ((IMAPIFolder *) ifolder)->CreateMessage(NULL, 0, &pMsg);
	if(hr == S_OK){
		BOOL bReady=0;
		if(!sets.lUseBackwCompSmtp){
			// ������� ������� ����� Outlook 2003 SP1
			IConverterSession* pConverterSession=0;
			hr=CoCreateInstance(CLSID_IConverterSession, NULL, CLSCTX_INPROC_SERVER, IID_IConverterSession, (void**)&pConverterSession);
			if(!FAILED(hr) && pConverterSession){
				BOOL bHtml=0;
				CString sEnc=CDataXMLSaver::GetInstringPart("Content-Type:","\r\n",email);
				sEnc.MakeLower();
				if(sEnc.Find("html")!=-1 || sEnc.Find("mult")!=-1){
					bHtml=1;
				}
				hr=S_OK;
				void* pBuf=0;
				HGLOBAL hGlob=0;
				BOOL bLocked=0;
				IStream *pStream=0;
				IMessage* pMsg2=0;
				// Create a message in there
				try{
					int ccbc=256*smtpRecip.size();
					hr = ((IMAPIFolder *) ifolder)->CreateMessage(NULL, 0, &pMsg2);
					if(hr!=S_OK) throw hr;
					if(FAILED(hr=pConverterSession->SetEncoding(IET_7BIT))) throw hr;
					int iLen=strlen(email)+10+ccbc;
					hGlob=GlobalAlloc(GMEM_MOVEABLE, iLen);
					if(!hGlob) throw (HRESULT)GetLastError();
					char* szMime=(char*)GlobalLock(hGlob);
					memset(szMime,0,iLen);
					strcpy(szMime,email);
					GlobalUnlock(hGlob);
					hr=CreateStreamOnHGlobal(hGlob,false,&pStream);
					if(hr!=S_OK) throw hr;
					if(FAILED(pStream->Commit(0))) throw hr;
					hr=pConverterSession->MIMEToMAPI(pStream, pMsg2, 0, 0);
					if(hr!=S_OK) throw hr;
					CString sTo=CDataXMLSaver::GetInstringPart("To:","\r\n",email);
					CString sCC=CDataXMLSaver::GetInstringPart("CC:","\r\n",email);
					int iCount=0;
					for (vector<string>::const_iterator i=smtpRecip.begin(); i!=smtpRecip.end(); i++){
						if(sTo.Find(i->c_str())==-1 && sCC.Find(i->c_str())==-1 ){
							AddPersonToEmail(pMsg2,i->c_str(),MAPI_BCC,MODRECIP_ADD);
						}
						iCount++;
					}
					bRes=true;
				}catch(HRESULT _hr){
					_log(0,"ERROR: line %i, hr=0x%08X",__LINE__,_hr);
					bRes=false;
					hr=_hr;
				}
				if(pStream){
					pStream->Release();
					pStream=0;
				}
				if(pConverterSession){
					pConverterSession->Release();
					pConverterSession=0;
				}
				if(hGlob){
					GlobalFree(hGlob);
					hGlob=0;
				}
				if(bRes){
					if(hr==S_OK){
						bReady=1;
						if(pMsg2){
							// �������� � ����� ��������� From
							SizedSPropTagArray ( 2, includeTags );
							includeTags.cValues = 2;
							includeTags.aulPropTag[0] = PR_CREATOR_ENTRYID;
							includeTags.aulPropTag[1] = PR_CREATOR_NAME;
							hr = ((LPMAPIPROP) pMsg)->CopyProps((LPSPropTagArray)&includeTags, NULL, NULL,&IID_IMAPIProp, pMsg2, 0, NULL); 
							// ������� �������������
							SizedSPropTagArray ( 8, deleteTags );
							deleteTags.cValues = 8;
							deleteTags.aulPropTag[0] = PR_SENT_REPRESENTING_SEARCH_KEY;
							deleteTags.aulPropTag[1] = PR_SENT_REPRESENTING_ENTRYID;
							deleteTags.aulPropTag[2] = PR_SENT_REPRESENTING_NAME;
							deleteTags.aulPropTag[3] = PR_SENT_REPRESENTING_ADDRTYPE;
							deleteTags.aulPropTag[4] = PR_SENT_REPRESENTING_EMAIL_ADDRESS;
							deleteTags.aulPropTag[5] = PR_SentRepresentingFlags;
							deleteTags.aulPropTag[6] = PR_MESSAGE_FLAGS;
							deleteTags.aulPropTag[7] = PR_SENTMAIL_ENTRYID;
							hr = ((LPMAPIPROP) pMsg2)->DeleteProps((LPSPropTagArray)&deleteTags, NULL); 
							// �������� � ����� ���������
							hr = ((LPMESSAGE) pMsg2)->CopyTo(0, NULL, 0, 0, NULL,(LPIID) &IID_IMessage, pMsg, 0, NULL);
							/*ULONG ulVals=0;
							LPSPropValue pPropVals = NULL;
							LPSPropValue pNewProps = NULL;
							hr = pMsg2->GetProps(NULL,0,&ulVals,&pPropVals);
							if(0 && (hr==S_OK || hr==MAPI_W_ERRORS_RETURNED)){
								pMAPIAllocateBuffer((ulVals + 5) * sizeof(SPropValue), (LPVOID*) &pNewProps);
								// Copy original data in
								for (int ul = 0; ul < ulVals; ul++)
								{
									if(pPropVals[ul].ulPropTag==PR_MESSAGE_FLAGS){
										pNewProps[ul].ulPropTag = PR_DELETE_AFTER_SUBMIT;
										pNewProps[ul].Value.b = 1;
									}else if(pPropVals[ul].ulPropTag==PR_ACCESS){
										pNewProps[ul].ulPropTag = PR_DELETE_AFTER_SUBMIT;
										pNewProps[ul].Value.b = 1;
										
									}else if(pPropVals[ul].ulPropTag==PR_HAS_NAMED_PROPERTIES){
										pNewProps[ul].ulPropTag = PR_DELETE_AFTER_SUBMIT;
										pNewProps[ul].Value.b = 1;
									}else if(pPropVals[ul].ulPropTag==PR_ENTRYID){
										pNewProps[ul].ulPropTag = PR_DELETE_AFTER_SUBMIT;
										pNewProps[ul].Value.b = 1;
									}else
									{
										pNewProps[ul].ulPropTag = pPropVals[ul].ulPropTag;
										pNewProps[ul].Value.bin = pPropVals[ul].Value.bin;
									}
								}
								//pNewProps[ulVals].ulPropTag = PR_TRANSPORT_MESSAGE_HEADERS;
								//pNewProps[ulVals++].Value.lpszA = sHeaders.GetBuffer(10);
								hr = pMsg->SetProps(ulVals,pNewProps,NULL);
								if (pNewProps)
									pMAPIFreeBuffer(pNewProps);
								if (pPropVals)
									pMAPIFreeBuffer(pPropVals); 
							}*/
						}
						if(hr==S_OK){
							SPropValue newMsgProps[1];
							newMsgProps[0].ulPropTag = PR_DELETE_AFTER_SUBMIT;
							newMsgProps[0].Value.b = 1;
							// Set the properties.
							hr=pMsg->SetProps(1,newMsgProps,NULL);
							if(!bHtml){
								// ���������� ���� � �����
								mapi_ForcePlaintext(pMsg);
							}
							// Save changes in the message object.
							pMsg->SaveChanges(KEEP_OPEN_READWRITE);
						}else{
							bRes=false;
						}
					}
				}
				if(pMsg2) {
					pMsg2->Release();
					pMsg2=0;
				}
			}
		}
		if(!bReady)
		{
#ifndef _USE_MIME_
			AfxMessageBox("Error: failed to send message using Exchange Interface.\r\nPossible reason: old Outlook/Exchange used\r\n\r\nYou should obtain licensed version of Mimepp.dll\r\nand recompile this application with _USE_MIME_ flag!");
#endif
#ifdef _USE_MIME_
			{
				mimepp::Initialize();
				mimepp::Message message(email);
				LPSPropValue pPropVals = NULL;
				LPSPropValue pNewProps = NULL;
				do{
					// ����� ��� ��������� ���� ��������
					message.parse();
					CString sCType=message.headers().contentType().text().c_str();
					CString sCharset=message.headers().contentType().charset().c_str();
					// Get properties.
					ULONG ulVals;
					hr = pMsg->GetProps(NULL,0,&ulVals,&pPropVals);
					if (FAILED(hr)) break;

					// Allocate another (bigger) SPropValue array
					pMAPIAllocateBuffer((ulVals + 6) * sizeof(SPropValue), (LPVOID*) &pNewProps);

					// Copy original data in
					for (int ul = 0; ul < ulVals; ul++)
					{
						pNewProps[ul].ulPropTag = pPropVals[ul].ulPropTag;
						pNewProps[ul].Value.bin = pPropVals[ul].Value.bin;
					}
					// Introduce subject
					CString sSubj=message.headers().fieldBody("Subject").getString().c_str();
					if(sCharset!=""){
						NormalizeEncoding(sSubj,sCharset);
					}
					pNewProps[ulVals].ulPropTag = PR_SUBJECT_A;
					pNewProps[ulVals++].Value.lpszA = (char*)sSubj.GetBuffer(1);

					if(!sets.lDoNotActSend){
						// Introduce PR_DELETE_AFTER_SUBMIT
						// This is needed, otherwise a copy stays in the Outbox
						pNewProps[ulVals].ulPropTag = PR_DELETE_AFTER_SUBMIT;
						pNewProps[ulVals++].Value.b = TRUE;
					}

					CString sHeaders=email;
					int iHeadersEndPos=sHeaders.Find("\r\n\r\n");
					if(iHeadersEndPos!=-1){
						sHeaders=sHeaders.Left(iHeadersEndPos);
					}else{
						sHeaders="Transport-headers: missing";
					}
					RemoveCommonHeaderFields(sHeaders);
					pNewProps[ulVals].ulPropTag = PR_TRANSPORT_MESSAGE_HEADERS;
					pNewProps[ulVals++].Value.lpszA = sHeaders.GetBuffer(10);

					FILETIME ft;
					CoFileTimeNow(&ft);				
					pNewProps[ulVals].ulPropTag = PR_CREATION_TIME;
					memcpy(&pNewProps[ulVals++].Value.ft,&ft,sizeof(pNewProps[ulVals++].Value.ft));

					pNewProps[ulVals].ulPropTag = PR_MESSAGE_DELIVERY_TIME;
					memcpy(&pNewProps[ulVals++].Value.ft,&ft,sizeof(pNewProps[ulVals++].Value.ft));

					if(sCharset!=""){
						long lFindCode=GetCPCodeByName(sCharset);
						if(lFindCode!=0){
							pNewProps[ulVals].ulPropTag = PR_INTERNET_CPID;
							pNewProps[ulVals++].Value.l = lFindCode;
						}
					}
					// Set props
					hr = pMsg->SetProps(ulVals,pNewProps,NULL);
					if (FAILED(hr)) break;

					// Reply-To
					CString sReplyTo=message.headers().fieldBody("Reply-To").getString().c_str();
					sReplyTo.TrimLeft();
					sReplyTo.TrimRight();
					if(sReplyTo.GetLength()!=0){
						SetReplyTo(pMsg,sReplyTo.GetBuffer(256));
					}
					// ��������� �������� �����
					CString sCC=message.headers().fieldBody("Cc").text().c_str();
					CString sBCC=message.headers().fieldBody("Bcc").text().c_str();
					hr=AddRecipientsFromList(smtpRecip,pMsg,sCC,sBCC);
					if (FAILED(hr)) break;// ��� ����� - ���� �� ����� ��������� �� ������
					//----------------------------------------------------
					//----------------------------------------------------
					//----------------------------------------------------
					mimepp::Entity* pMsgBody=&message;
					BOOL bHtml=FALSE;
					sCType.MakeLower();
					if(sCType.Find("html")!=-1){
						bHtml=TRUE;
					}
					int iAttachIndex=0;
					if(message.body().numBodyParts()>0){
						int iIndex=0;
						iAttachIndex=1;
						if(sCType.Find("alternative")!=-1 && message.body().numBodyParts()>=1){
							iAttachIndex=2;
							iIndex=1;
						}
						pMsgBody=&message.body().bodyPartAt(iIndex);
						CString sCType2=message.body().bodyPartAt(iIndex).headers().fieldBody("Content-type").text().c_str();
						sCType2.MakeLower();
						if(sCType2.Find("html")!=-1){
							bHtml=TRUE;
						}
					}
					CString szBody=pMsgBody->body().getString().c_str();
					if(sCharset!=""){
						NormalizeEncoding(szBody,sCharset);
					}
					if(szBody && strlen(szBody)>0){
						// ��������� ����
						UINT iBodyProp=PR_BODY;
						if(bHtml){
							iBodyProp=PR_BODY_HTML;
						}
						CString sType=pMsgBody->headers().contentTransferEncoding().type().c_str();
						sType.MakeUpper();
						int iSize=strlen(szBody);
						if(sType.Find("QUOTED")!=-1){
							mimepp::QuotedPrintableDecoder decoder;
							mimepp::CharBuffer bufIn;
							bufIn.chars=(char*)szBody.GetBuffer(-1);
							bufIn.pos=0;
							bufIn.endPos=iSize;
							mimepp::ByteBuffer bufOut;
							BYTE* buffer=new BYTE[iSize];
							bufOut.bytes=buffer;
							bufOut.pos=0;
							bufOut.endPos=iSize;
							decoder.start();
							decoder.decodeSegment(&bufIn,&bufOut);
							iSize=bufOut.pos;
							mapi_WritePropStream(pMsg,iBodyProp,szBody,strlen(szBody));
							delete[] buffer;
						}else if(sType.Find("64")!=-1){
							mimepp::Base64Decoder decoder;
							mimepp::CharBuffer bufIn;
							bufIn.chars=(char*)szBody.GetBuffer(-1);;
							bufIn.pos=0;
							bufIn.endPos=iSize;
							mimepp::ByteBuffer bufOut;
							BYTE* buffer=new BYTE[iSize];
							bufOut.bytes=buffer;
							bufOut.pos=0;
							bufOut.endPos=iSize;
							decoder.start();
							decoder.decodeSegment(&bufIn,&bufOut);
							iSize=bufOut.pos;
							mapi_WritePropStream(pMsg,iBodyProp,szBody,strlen(szBody));
							delete[] buffer;
						}else{
							mapi_WritePropStream(pMsg,iBodyProp,szBody,strlen(szBody));
						}
					}
					// ������
					for(int iAttNum=iAttachIndex;iAttNum<message.body().numBodyParts();iAttNum++){
						mimepp::BodyPart* pAttBody=&message.body().bodyPartAt(iAttNum);
						if(pAttBody){
							std::string szContID=pAttBody->headers().contentId().text().c_str();
							std::string szFName=pAttBody->headers().contentDisposition().filename().c_str();
							std::string sFileName=GetPathPart(szFName.c_str(),0,0,1,1);
							std::string sFileExt=GetPathPart(szFName.c_str(),0,0,0,1);
							ULONG ulNum=0;
							IAttach* pAttach=0;
							pMsg->CreateAttach(0, 0, &ulNum, &pAttach);

							LPSPropValue spvAttach=0;
							int iPropsNum=(strlen(szContID.c_str())==0)?6:7;
							pMAPIAllocateBuffer(iPropsNum * sizeof(SPropValue), (LPVOID*) &spvAttach);

							spvAttach[0].ulPropTag = PR_ATTACH_FILENAME;
							spvAttach[0].Value.lpszA = (char*)sFileName.c_str();

							spvAttach[1].ulPropTag = PR_DISPLAY_NAME;
							spvAttach[1].Value.lpszA = (char*)sFileName.c_str();

							spvAttach[2].ulPropTag = PR_ATTACH_METHOD;
							spvAttach[2].Value.l = ATTACH_BY_VALUE;

							spvAttach[3].ulPropTag = PR_ATTACH_LONG_FILENAME;
							spvAttach[3].Value.lpszA = (char*)sFileName.c_str();

							spvAttach[4].ulPropTag = PR_RENDERING_POSITION;
							spvAttach[4].Value.l = 0xFFFFFFFF;

							spvAttach[5].ulPropTag = PR_ATTACH_EXTENSION;
							spvAttach[5].Value.lpszA = (char*)sFileExt.c_str();

							if(strlen(szContID.c_str())>0){
								spvAttach[6].ulPropTag = PR_ATTACH_CONTENT_ID;
								spvAttach[6].Value.lpszA = (char*)szContID.c_str();
							}

							hr=pAttach->SetProps(iPropsNum, spvAttach, NULL);
							pMAPIFreeBuffer(spvAttach);
							const char* szAttach=pAttBody->body().getString().c_str();
							CString sType=pAttBody->headers().contentTransferEncoding().type().c_str();
							sType.MakeUpper();
							if(sType.Find("QUOTED")!=-1){
								int iSize=strlen(szAttach);
								mimepp::QuotedPrintableDecoder decoder;
								mimepp::CharBuffer bufIn;
								bufIn.chars=(char*)szAttach;
								bufIn.pos=0;
								bufIn.endPos=iSize;
								mimepp::ByteBuffer bufOut;
								bufOut.bytes=new BYTE[iSize];
								bufOut.pos=0;
								bufOut.endPos=iSize;
								decoder.start();
								decoder.decodeSegment(&bufIn,&bufOut);
								iSize=bufOut.pos;
								mapi_WritePropStream(pAttach,PR_ATTACH_DATA_BIN,bufOut.bytes,iSize);
								delete[] bufOut.bytes;
							}else if(sType.Find("64")!=-1){
								int iSize=strlen(szAttach);
								mimepp::Base64Decoder decoder;
								mimepp::CharBuffer bufIn;
								bufIn.chars=(char*)szAttach;
								bufIn.pos=0;
								bufIn.endPos=iSize;
								mimepp::ByteBuffer bufOut;
								bufOut.bytes=new BYTE[iSize];
								bufOut.pos=0;
								bufOut.endPos=iSize;
								decoder.start();
								decoder.decodeSegment(&bufIn,&bufOut);
								iSize=bufOut.pos;
								mapi_WritePropStream(pAttach,PR_ATTACH_DATA_BIN,bufOut.bytes,iSize);
								delete[] bufOut.bytes;
							}else{
								mapi_WritePropStream(pAttach,PR_ATTACH_DATA_BIN,szAttach,strlen(szAttach));
							}
							hr = pAttach->SaveChanges(KEEP_OPEN_READWRITE);
							//if (FAILED(hr)) break;
						}
					}
					if(!bHtml){
						// ���������� ���� � �����
						mapi_ForcePlaintext(pMsg);
					}
				}while(0);
				if (pNewProps)
					pMAPIFreeBuffer(pNewProps);
				if (pPropVals)
					pMAPIFreeBuffer(pPropVals); 
				if(hr == S_OK){
					bRes=true;
				}
				mimepp::Finalize();
			}
#endif
		}
		if(pMsg && bRes){
			//----------------------------------------------------
			// Save changes
			hr = pMsg->SaveChanges(KEEP_OPEN_READWRITE);
			if (!FAILED(hr)){
				if(!sets.lDoNotActSend){
					// Submit
					hr = pMsg->SubmitMessage(0);
					if (FAILED(hr)){
						bRes=false;
					}
				}
			}
			pMsg->Release();
		}
	}
	ifolder->Release();
	//http://msdn.microsoft.com/library/default.asp?url=/library/en-us/devguidesp/html/sp_inbox_and_ce_messaging_snmx.asp
	//http://www.wrconsulting.com/Software/Publications/Exchange/Contents.htm
	return bRes;
}
//http://msdn.microsoft.com/library/default.asp?url=/library/en-us/olintapi/html/oliaIConverterSession_HV01154520.asp
/*
Also try to set the PR_InetMailOverrideFormat property (0x59020003) to
ENCODING_PREFERENCE | BODY_ENCODING_TEXT | ENCODING_MIME.
PR_InetMailOverrideFormat = &H59020003
ENCODING_PREFERENCE = &H00020000
BODY_ENCODING_TEXT_AND_HTML = &H00100000
ENCODING_MIME = &H00040000

PR_MSG_EDITOR_FORMAT = 0H59090003
EDITOR_FORMAT_PLAINTEXT = 1
EDITOR_FORMAT_HTML = 2
*/

