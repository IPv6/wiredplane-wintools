/////////////////////////////// Defines ///////////////////////////////////////
#ifndef __CSD_H__
#define __CSD_H__

#ifndef __AFXTEMPL_H__
#pragma message("POP3 classes require afxtempl.h in your PCH")																				  
#endif

#ifndef _WINSOCKAPI_
#pragma message("POP3 classes require afxsock.h or winsock.h in your PCH")
#endif

/////////////////////////////// Classes ///////////////////////////////////////
class CMIMECode  
{
public:
    CMIMECode();
    virtual ~CMIMECode();
	
    virtual CString Decode( LPCTSTR szDecoding, int nSize = -1, int* iOutBufferByteLen=0) = 0;
    virtual CString Encode( LPCTSTR szEncoding, int nSize = -1) = 0;
};

class CQuoted : public CMIMECode  
{
public:
    int m_linelength;
    CQuoted(int linelength=76);
    virtual ~CQuoted();
    virtual CString Decode( LPCTSTR szDecoding, int nSize = -1, int* iOutBufferByteLen=0);
    virtual CString Encode( LPCTSTR szEncoding, int nSize = -1);
protected:
    static const CString code;
    static const CString extended_code;
};

class CBase64 : public CMIMECode  
{
public:
    CBase64();
    virtual ~CBase64();
	
	// Override the base class mandatory functions
    virtual CString Decode( LPCTSTR szDecoding, int nSize = -1, int* iOutBufferByteLen=0);
    virtual CString Encode( LPCTSTR szEncoding, int nSize = -1);
	
protected:
    void write_bits( UINT nBits, int nNumBts, LPTSTR szOutput, int& lp );
    UINT read_bits( int nNumBits, int* pBitsRead, int& lp );
	
    int m_nInputSize;
    int m_nBitsRemaining;
    ULONG m_lBitStorage;
    LPCTSTR m_szInput;
	
    static int m_nMask[];
    static CString m_sBase64Alphabet;
private:
};

#include <mlang.h>
#include <atlbase.h>
class CCharsetDecoder  
{
public:
    CString m_sCharSetName;
    CCharsetDecoder(CString sCharSetName): m_sCharSetName(sCharSetName) {};
    CCharsetDecoder(UINT CodePage);
    ~CCharsetDecoder(){};
    CString Encode(CString sString); // Encodes the string in default charset (e.g. 1251 for Russian) to the given codepage
    CString Decode(CString sString); // Decodes the string in the given charset (e.g. koi8-r/*=20866)*/ to the default charset
	BOOL isKnown();
private:
    CString Recode(CString sString, bool bEncode, bool* bRes=NULL);
};

CString DecodeHeaderValue(CString Encoded, CString *pCharset);
int b64decode(char *from,char *to,int from_length);
int b64get_encode_buffer_size(int from_length,int output_quads_per_line);
int b64strip_encoded_buffer(char *buf,int length);
int b64encode(const char *from,char *to,int length,int quads);
#endif

