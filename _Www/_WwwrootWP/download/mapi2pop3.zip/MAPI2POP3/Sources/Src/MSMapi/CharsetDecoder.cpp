#include "stdafx.h"
#include "CharsetDecoder.h"
//////////////// Macros //////////////////////////////////////////////
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


//////////////// Implementation //////////////////////////////////////
/*
CString CPop3Message::GetHeaderItem(const CString& sName, int nItem) const
{
	//Value which will be returned by this function
	CString sField;
	
	//Get the message header (add an extra "\r\n" at the
	//begining to aid in the parsing)  
	CString sHeader(_T("\r\n"));
	sHeader += GetHeader();
	CString sUpCaseHeader(sHeader);
	sUpCaseHeader.MakeUpper();
	
	CString sUpCaseName(sName);
	sUpCaseName.MakeUpper();
	
	//Find the specified line in the header
	CString sFind(CString(_T("\r\n")) + sUpCaseName + _T(":"));
	int nFindLength = sFind.GetLength();
	int nFindStart = sUpCaseHeader.Find(sFind);
	int nFind = nFindStart;
	for (int i=0; i<nItem; i++) 
	{
		//Get ready for the next loop around
		sUpCaseHeader = sUpCaseHeader.Right(sUpCaseHeader.GetLength() - nFind - nFindLength);
		nFind = sUpCaseHeader.Find(sFind);
		
		if (nFind == -1)
			return _T(""); //Not found
		else
			nFindStart += (nFind + nFindLength);
	}
	
	if (nFindStart != -1)
		nFindStart += (3 + sName.GetLength());
	if (nFindStart != -1)
	{
		BOOL bFoundEnd = FALSE;
		int i = nFindStart;
		int nLength = sHeader.GetLength();
		do
		{
			//Examine the current 3 characters
			TCHAR c1 = _T('\0');
			if (i < nLength)
				c1 = sHeader[i];
			TCHAR c2 = _T('\0');
			if (i < (nLength-1))
				c2 = sHeader[i+1];
			TCHAR c3 = _T('\0');
			if (i < (nLength-2))
				c3 = sHeader[i+2];
			
			//Have we found the terminator
			if ((c1 == _T('\0')) ||
				((c1 == _T('\r')) && (c2 == _T('\n')) && (c3 != _T(' ')) && c3 != _T('\t')))
			{
				bFoundEnd = TRUE;
			}
			else
			{
				//Move onto the next character	
				++i;
			}
		}
		while (!bFoundEnd);
		sField = sHeader.Mid(nFindStart, i - nFindStart);
		
		//Remove any embedded "\r\n" sequences from the field
		int nEOL = sField.Find(_T("\r\n"));
		while (nEOL != -1)
		{
			sField = sField.Left(nEOL) + sField.Right(sField.GetLength() - nEOL - 2);
			nEOL = sField.Find(_T("\r\n"));
		}
		
		//Replace any embedded "\t" sequences with spaces
		int nTab = sField.Find(_T('\t'));
		while (nTab != -1)
		{
			sField = sField.Left(nTab) + _T(' ') + sField.Right(sField.GetLength() - nTab - 1);
			nTab = sField.Find(_T('\t'));
		}
		
		//Remove any leading or trailing white space from the Field Body
		sField.TrimLeft();
		sField.TrimRight();
	}
	
	return sField;
}

CString CPop3Message::GetHeader() const
{
	//Value which will be returned by this function
	CString sHeader;
	
	//Find the divider between the header and body
	CString sMessage(m_pszMessage);
	int nFind = sMessage.Find(_T("\r\n\r\n"));
	if (nFind != -1)
		sHeader = sMessage.Left(nFind);
	else
	{
		//No divider, then assume all the text is the header
		sHeader = sMessage;
	}
	
	return sHeader;
}
*/
/////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////
CString DecodeHeaderValue(CString Encoded, CString *pCharset)
{
    Encoded.TrimLeft();
    Encoded.TrimRight();
    CString Result;
    int i = 0, len = Encoded.GetLength();
    while(i < len)
    {
        if (Encoded[i] == 61 // Equal sign (=)
            && (i<len-1 && Encoded[i+1] == _T('?')))
        { // this is a encoded_word start.
            int ce = Encoded.Find(_T('?'), i+2);
            if (ce > 0)
            {
                if (pCharset) *pCharset = Encoded.Mid(i+2, ce-i-2);
                // for now we do not care about this field;
                // scan for the next '?'
				
                int ee=Encoded.Find(_T('?'), ce+1);
                if (ee > 0)
                {
                    CString word_encoding = Encoded.Mid(ce+1, ee-ce-1);
                    word_encoding.MakeUpper();
                    int we = Encoded.Find(_T('?'), ee+1);
                    if (we > 0)
                    {
                        CString encoded_word = Encoded.Mid(ee+1, we-ee-1);
                        CMIMECode *pDecoder = NULL;
                        if (word_encoding == "Q")
                            pDecoder = new CQuoted;
                        if (word_encoding == "B")
                            pDecoder = new CBase64;
                        Result+= pDecoder ? pDecoder->Decode(encoded_word, we-ee-1) 
                            : encoded_word;
                        delete pDecoder; // it's safe to call delete on NULL pointers (ANSI)
                        i=we+2;
                        continue; // The word succesfully decoded;
                    }
                }
            }
        }
        // Here we fall in case of any error
        Result+=Encoded[i++]; // Simply skip one char;
    }
    return Result;
}

// The 7-bit alphabet used to encode binary information
CString CBase64::m_sBase64Alphabet = 
_T( "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/" );

int CBase64::m_nMask[] = { 0, 1, 3, 7, 15, 31, 63, 127, 255 };

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CBase64::CBase64()
{
}

CBase64::~CBase64()
{
}

CString CBase64::Encode(LPCTSTR szEncoding, int nSize)
{
    CString sOutput = _T( "" );
	LPTSTR buffer = sOutput.GetBuffer(nSize*2);
    int nNumBits = 6;
    UINT nDigit;
    int lp = 0;
	
    ASSERT( szEncoding != NULL );
    if( szEncoding == NULL )
        return sOutput;
    m_szInput = szEncoding;
    m_nInputSize = nSize;
	
    m_nBitsRemaining = 0;
    nDigit = read_bits( nNumBits, &nNumBits, lp );
    while( nNumBits > 0 )
    {
        sOutput += m_sBase64Alphabet[ (int)nDigit ];
        nDigit = read_bits( nNumBits, &nNumBits, lp );
    }
    // Pad with '=' as per RFC 1521
    while( sOutput.GetLength() % 4 != 0 )
    {
        sOutput += '=';
    }
	sOutput.ReleaseBuffer(-1);
    return sOutput;
}

// The size of the output buffer must not be less than
// 3/4 the size of the input buffer. For simplicity,
// make them the same size.
CString CBase64::Decode(LPCTSTR szDecoding, int nSize, int* iOutBufferByteLen)
{
    CString sInput, Result;
    int c, lp =0;
    int nDigit;
    int nDecode[ 256 ];
    LPTSTR szOutput = Result.GetBuffer(nSize); // Output is never longer than input
	
    ASSERT( szDecoding != NULL );
    if( szDecoding == NULL )
        return _T("");
    sInput = szDecoding;
    if( sInput.GetLength() == 0 )
        return _T("");
    m_lBitStorage = 0;
    m_nBitsRemaining = 0;
	
    // Build Decode Table
    //
    for( int i = 0; i < 256; i++ ) 
        nDecode[i] = -2; // Illegal digit
    for( i=0; i < 64; i++ )
    {
        nDecode[ m_sBase64Alphabet[ i ] ] = i;
        nDecode[ m_sBase64Alphabet[ i ] | 0x80 ] = i; // Ignore 8th bit
        nDecode[ '=' ] = -1; 
        nDecode[ '=' | 0x80 ] = -1; // Ignore MIME padding char
        nDecode[ '\n'] = -1; // Skip the CR/LFs
        nDecode[ '\r'] = -1;
    }
	
    // Decode the Input
    //
    for( lp = 0, i = 0; lp < sInput.GetLength(); lp++ )
    {
        c = sInput[ lp ];
        nDigit = nDecode[ c & 0x7F ];
        if( nDigit < -1 ) 
        {
            return _T("");
        } 
        else if( nDigit >= 0 ) 
            // i (index into output) is incremented by write_bits()
            write_bits( nDigit & 0x3F, 6, szOutput, i );
    }
	if(!iOutBufferByteLen){
		Result.ReleaseBuffer(i);
	}else{
		*iOutBufferByteLen=i;
		Result.LockBuffer();
	}
    return Result;
}

UINT CBase64::read_bits(int nNumBits, int * pBitsRead, int& lp)
{
    ULONG lScratch;
    while( ( m_nBitsRemaining < nNumBits ) && 
		( lp < m_nInputSize ) ) 
    {
        int c = m_szInput[ lp++ ];
        m_lBitStorage <<= 8;
        m_lBitStorage |= (c & 0xff);
        m_nBitsRemaining += 8;
    }
    if( m_nBitsRemaining < nNumBits ) 
    {
        lScratch = m_lBitStorage << ( nNumBits - m_nBitsRemaining );
        *pBitsRead = m_nBitsRemaining;
        m_nBitsRemaining = 0;
    } 
    else 
    {
        lScratch = m_lBitStorage >> ( m_nBitsRemaining - nNumBits );
        *pBitsRead = nNumBits;
        m_nBitsRemaining -= nNumBits;
    }
    return (UINT)lScratch & m_nMask[nNumBits];
}


void CBase64::write_bits(UINT nBits,
                         int nNumBits,
                         LPTSTR szOutput,
                         int& i)
{
    UINT nScratch;
	
    m_lBitStorage = (m_lBitStorage << nNumBits) | nBits;
    m_nBitsRemaining += nNumBits;
    while( m_nBitsRemaining > 7 ) 
    {
        nScratch = m_lBitStorage >> (m_nBitsRemaining - 8);
        szOutput[ i++ ] = nScratch & 0xFF;
        m_nBitsRemaining -= 8;
    }
}

const CString CQuoted::code = _T("0123456789ABCDEF");
const CString CQuoted::extended_code = _T("0123456789abcdef");
CQuoted::CQuoted(int linelength):m_linelength(linelength)
{
	
}

CQuoted::~CQuoted()
{
	
}

CString CQuoted::Encode( LPCTSTR szEncoding, int nSize )
{
    CString Result;
    if (nSize < 0)
        nSize = strlen(szEncoding);
    // Estimate the buffer size;
    // we will need max 3 bytes for each incoming octet 
    // and 3 additional bytes for each line
    LPTSTR buffer = Result.GetBuffer(3*(nSize+3*nSize/(m_linelength))); 
    int chunklen;
    int bufpos=0, linepos=0;
    for (int i = 0; i<nSize; i++)
    {
        // test if the szEncoding[i] allows literal representation
        chunklen=((szEncoding[i]>32 && szEncoding[i]<=60) ||
            (szEncoding[i]>61 && szEncoding[i]<=126)) ? 1 : 3;
        // test if line break needed
        if (linepos+chunklen>m_linelength-1)
        { // insert linebreak
            buffer[bufpos++]= 61; // Equal sign
            buffer[bufpos++]= 13; // Line 
            buffer[bufpos++]= 10; //  break
            linepos=0;
        }
        if (chunklen == 1)
        {
            buffer[bufpos++] = szEncoding[i]; // literal
            linepos++;
        }
        else
        {
            buffer[bufpos++]= 61; // Equal sign
            buffer[bufpos++]= code[(szEncoding[i] >> 4) & 0xF]; //high nibble
            buffer[bufpos++]= code[szEncoding[i] & 0xF]; //  low nibble
            linepos+=3;
        }
    }
    Result.ReleaseBuffer(bufpos);
    return Result;
}

CString CQuoted::Decode( LPCTSTR szDecoding, int nSize, int* iOutBufferByteLen)
{
    CString Result;
    if (nSize < 0)
        nSize = strlen(szDecoding);
    // Guess the buffer size
    LPTSTR szOutput = Result.GetBuffer(nSize);
    int i=0, outpos=0;
    while(szDecoding[i])
    {
        if (szDecoding[i] == 61) // Equal Sign
        { // try to decode the following chunk
            int octet;
            if (sscanf(szDecoding+i+1, _T("%2x"), &octet)>0)
            {
                szOutput[outpos++]=octet;
                i+=3;
                continue;
            }
            else 
            {
                // is this a CR/LF?
                if (szDecoding[i+1] == 13)
                {
                    i+=2; // simply skip the CR...
                    if (szDecoding[i] == 10) i++; //...and, probably, LF
                    continue;
                }
            }
        }
        // decoding error occured! try to recover by outputting the 
        // untransformed octet and starting over from the very beginning;
        szOutput[outpos++] = szDecoding[i++];
    }
	if(!iOutBufferByteLen){
		Result.ReleaseBuffer(outpos);
	}else{
		*iOutBufferByteLen=outpos;
		Result.LockBuffer();
	}
    return Result;
}

BOOL CCharsetDecoder::isKnown()
{
	bool bRes=FALSE;
	Recode("abcABC", false, &bRes);
	return bRes;
}

CString CCharsetDecoder::Decode(CString sString)
{
    return Recode(sString, false);
}

CString CCharsetDecoder::Encode(CString sString)
{
    return Recode(sString, true);
}

CString CCharsetDecoder::Recode(CString sString, bool bEncode, bool* bRes)
{
	if(m_sCharSetName.CompareNoCase("quoted-printable")==0){
		CQuoted objDecoder;
        CString sRes=objDecoder.Decode(sString, -1) ;
		return sRes;
	}
    CString sResult;
    HRESULT hr;
    CComPtr<IMultiLanguage> pLang;
    hr = CoCreateInstance(CLSID_CMultiLanguage, NULL, CLSCTX_INPROC_SERVER, IID_IMultiLanguage, (LPVOID*)&pLang);
    if (hr == S_OK)
    {
        CComBSTR bsCharsetName = m_sCharSetName; // all required conversions are done here;
        MIMECSETINFO info;
        hr = pLang->GetCharsetInfo(bsCharsetName, &info);
        if (hr == S_OK)
        {
            DWORD dwMode=0;
            UINT SrcSize=sString.GetLength(), DstSize=SrcSize;
            hr = bEncode ? 
                pLang->ConvertString(&dwMode, info.uiCodePage, 
                info.uiInternetEncoding, (BYTE*)LPCSTR(sString), &SrcSize, 
                (BYTE *)sResult.GetBuffer(DstSize), &DstSize)
                :
			pLang->ConvertString(&dwMode, info.uiInternetEncoding, 
                info.uiCodePage, (BYTE*)LPCSTR(sString), &SrcSize, 
                (BYTE *)sResult.GetBuffer(DstSize), &DstSize);
            if (hr == S_OK)
            {
                sResult.ReleaseBuffer(DstSize);
				if(bRes){
					*bRes=TRUE;
				}
                return sResult;
            }
        }
    }
	if(bRes){
		*bRes=FALSE;
	}
    return sString;
}

CCharsetDecoder::CCharsetDecoder(UINT CodePage)
{
    CComPtr<IMultiLanguage> pLang;
    HRESULT hr;
    hr = CoCreateInstance(CLSID_CMultiLanguage, NULL, CLSCTX_INPROC_SERVER, IID_IMultiLanguage, (LPVOID*)&pLang);
    if (hr == S_OK)
    {
		//CComBSTR bsCharsetName = m_sCharSetName; // all required conversions are done here;
        MIMECPINFO info;
        hr = pLang->GetCodePageInfo(CodePage, &info);
        if (hr == S_OK)
        {
            m_sCharSetName = info.wszHeaderCharset;
        }
    }
}


//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CMIMECode::CMIMECode()
{
	
}

CMIMECode::~CMIMECode()
{
	
}
//-------------------------------------------------------------------------- 

char ntc(unsigned char n)
{
	if (n<26) return 'A'+n;
	if (n<52) return 'a'-26+n;
	if (n<62) return '0'-52+n;
	if (n==62) return '+';
	return '/';
}

unsigned char ctn(char c)
{
	if (c=='/') return 63;
	if (c=='+') return 62;
	if ((c>='A')&&(c<='Z')) return c-'A';
	if ((c>='a')&&(c<='z')) return c-'a'+26;
	if ((c>='0')&&(c<='9')) return c-'0'+52;
	if (c=='=') return 80;
	return 100;
}


int b64encode(const char *from,char *to,int length,int quads)
{
	// 3 8bit numbers become four characters 
	int i =0;
	char *tot=to;
	int qc=0;  // Quadcount
	unsigned char c;
	unsigned char d;
	
	
	while(i<length)
	{
		c=from[i];
		*to++=ntc(c/4);
		c=c*64;
		
		i++;
		
		if (i>=length) 
		{
			*to++=ntc(c/4);
			*to++='=';
			*to++='=';
			break;
		}
		
		d=from[i];
		*to++=ntc(c/4+d/16);
		d=d*16;
		
		i++;
		
		if (i>=length) 
		{
			*to++=ntc(d/4);
			*to++='=';
			break;
		}
		
		c=from[i];
		*to++=ntc(d/4+c/64);
		c=c*4;
		
		i++;
		
		*to++=ntc(c/4);
		
		qc++; // qz will never be zero, quads = 0 means no linebreaks
		if (qc==quads)
		{
			*to++='\n';
			qc=0;
		}
		
	}
	
	// if ((quads!=0)&&(qc!=0)) *to++='\n'; // Insert last linebreak 
	return to-tot;
}

int b64decode(char *from,char *to,int length)
{
	unsigned char c,d,e,f;
	char A,B,C;
	int i;
	int add;
	char *tot=to;
	for (i=0;i+3<length;)
	{
		add=0;
		A=B=C=0;
		c=d=e=f=100;
		
		while ((c==100)&&(i<length))    c=ctn(from[i++]);
		while ((d==100)&&(i<length))    d=ctn(from[i++]);
		while ((e==100)&&(i<length))    e=ctn(from[i++]);
		while ((f==100)&&(i<length))    f=ctn(from[i++]);
		
		if (f==100) return -1; // Not valid end
		
		if (c<64) 
		{
			A+=c*4;
			if (d<64) 
			{
				A+=d/16;
				B+=d*16;
				if (e<64) 
				{
					B+=e/4;
					C+=e*64;
					if (f<64) 
					{
						C+=f;
						to[2]=C;
						add+=1;
					}
					to[1]=B;
					add+=1;
				}
				to[0]=A;
				add+=1;
			}
		}
		to+=add;
		if (f==80) return to-tot; // end because '=' encountered 
	}
	return to-tot;
}

int b64get_encode_buffer_size(int l,int q)
{
	int ret;
	ret = (l/3)*4;
	if (l%3!=0) ret +=4;
	if (q!=0)
	{
		ret += (ret/(q*4));
		// if (ret%(q/4)!=0) ret ++;   // Add space for trailing \n
	}
	return ret;
}

int b64strip_encoded_buffer(char *buf,int length)
{
	int i;
	int ret=0;
	
	for (i=0;i<length;i++) if (ctn(buf[i])!=100) buf[ret++] = buf [i];
	
	return ret;
}

