//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by pop3httpproxy.rc
//
#define IDACTIONS                       3

#define ID_WEBSITE                      3
#define IDMINIMIZE                      3
#define IDBROWSE                        3
#define IDDELETE                        4
#define IDEXPAND                        4
#define ID_FOLDERACTIONS1               4
#define ID_FOLDERACTIONS2               5
#define ID_OPEN                         6
#define IDAPPLY                         6
#define ID_ENTCODE                      7
#define ID_WNDS                         7
#define IDC_LPANE                       13
#define IDC_OPTIONSLIST                 14
#define IDC_QHELP_TXT                   15
#define ID_FOLDERTITLE                  16
#define IDC_QHELP                       18
#define IDS_SERVICENAME                 100
#define IDR_Pop3httpproxy               100
#define IDR_MAINICOX                    201
#define IDC_EDIT                        201
#define IDD_DIALOG1                     202
#define IDB_IMAGELIST                   203
#define IDD_OPTIONS_DIALOG              204
#define IDD_DIALOG2                     205

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        206
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         202
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
