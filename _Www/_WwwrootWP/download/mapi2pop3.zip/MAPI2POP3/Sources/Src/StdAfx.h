// stdafx.h : include file for standard system include files,
//      or project specific include files that are used frequently,
//      but are changed infrequently

#if !defined(AFX_STDAFX_H__F9AFE155_3E4E_4C41_90D4_F7F690EEE963__INCLUDED_)
#define AFX_STDAFX_H__F9AFE155_3E4E_4C41_90D4_F7F690EEE963__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define STRICT
#ifndef _WIN32_WINNT
#define _WIN32_WINNT 0x0400
#endif
#define _NO_XMLHOTKEYSUPPORT
#define _ATL_APARTMENT_THREADED
#define VC_EXTRALEAN		// Exclude rarely-used stuff from Windows headers
#include <afxwin.h>         // MFC core and standard components
#include <afxext.h>         // MFC extensions
#include <afxdisp.h>        // MFC Automation classes
#include <afxdtctl.h>		// MFC support for Internet Explorer 4 Common Controls
#include <afxcmn.h>			// MFC support for Windows Common Controls
#include <Winsock2.h>
#include <afxsock.h>		// MFC socket extensions
#include <atlconv.h>
#include <atlbase.h>
#include <afxtempl.h>
#include <winsvc.h>
#include <stdio.h>
#include <process.h>

#include "resource.h"
#include "..\SmartWires\SystemUtils\Macros.h"
#include "..\SmartWires\SmartWndSizer\SmartWndSizer.h"
#include "..\SmartWires\GUIClasses\systemtr.h"
#include "..\SmartWires\GUIClasses\IListCtrl.h"
#include "..\SmartWires\GUIClasses\DLG_Options.h"
#include "..\SmartWires\SystemUtils\SupportClasses.h"
#include "..\SmartWires\SystemUtils\DataXMLSaver.h"
#include "..\SmartWires\SystemUtils\FileInfo.h"

#include <atlbase.h>
//You may derive a class from CComModule and use it if you want to override
//something, but do not change the name of _Module
class CServiceModule : public CComModule
{
public:
	HRESULT RegisterServer(BOOL bRegTypeLib, BOOL bService);
	HRESULT UnregisterServer();
	void Init(_ATL_OBJMAP_ENTRY* p, HINSTANCE h, UINT nServiceNameID, const GUID* plibid = NULL);
    void Start();
	void ServiceMain(DWORD dwArgc, LPTSTR* lpszArgv);
    void Handler(DWORD dwOpcode);
    void Run();
    BOOL IsInstalled();
    BOOL Install();
    BOOL Uninstall();
	LONG Unlock();
	void LogEvent(LPCTSTR pszFormat, ...);
    void SetServiceStatus(DWORD dwState);
    void SetupAsLocalServer();

//Implementation
private:
	static void WINAPI _ServiceMain(DWORD dwArgc, LPTSTR* lpszArgv);
    static void WINAPI _Handler(DWORD dwOpcode);

// data members
public:
    TCHAR m_szServiceName[256];
    SERVICE_STATUS_HANDLE m_hServiceStatus;
    SERVICE_STATUS m_status;
	DWORD dwThreadID;
	BOOL m_bService;
};

class CMyApp : public CWinApp
      {
      public:
         virtual BOOL InitInstance();
         virtual int ExitInstance();
      protected:
      BOOL m_bRun;
};

extern CServiceModule _Module;
#include <atlcom.h>

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.
#define ALERTBOX
#ifdef ALERTBOX
void AlertBox(const char* szTitle, const char* szText, DWORD dwTime);
#endif
void _log(DWORD dwLevel,const char* szString,...);
BOOL SetTooltipText(LPCTSTR pszTip, BOOL bWithLog=0);
#define EXECRYPTOR_SALT	"MP1"
#endif // !defined(AFX_STDAFX_H__F9AFE155_3E4E_4C41_90D4_F7F690EEE963__INCLUDED)
