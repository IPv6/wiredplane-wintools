
#include <errno.h>
#include <assert.h>

#include "socket.h"

INT32 StreamSocket::Init()
{
	CoInitialize(0);
	WORD wVersionRequested;
    WSADATA wsaData;
    wVersionRequested = MAKEWORD(2, 2);
    return WSAStartup(wVersionRequested, &wsaData);
}

INT32 StreamSocket::DeInit()
{
	int iRes=WSACleanup();
	CoUninitialize();
	return iRes;
}

INT32 StreamSocket::Create()
{
    m_fd = socket(AF_INET, SOCK_STREAM, 0);
	
	//socket options//
	UINT32 optval = 1;
    setsockopt(m_fd, SOL_SOCKET, SO_REUSEADDR, (const char FAR*)&optval, sizeof(optval));
    //optval = -1;
    //setsockopt(m_fd, IPPROTO_TCP, TCP_NODELAY, (char *)&optval, sizeof(optval));
	//////////////////
	
    return m_fd;
}

INT32 StreamSocket::Close()
{
	return m_fd = closesocket(m_fd);
}

INT32 StreamSocket::Write(char *buffer, UINT32 length)
{
    assert(m_fd > 0);
    return send(m_fd, buffer, length, 0);
}

INT32 StreamSocket::Read(char *buffer, UINT32 length)
{
    assert(m_fd > 0);
    return recv(m_fd, buffer, length, 0);
}

INT32 StreamSocket::Peek(char *buffer, UINT32 length)
{
    assert(m_fd > 0);
    INT32 ret = recv(m_fd, buffer, length, MSG_PEEK);
	
    if (ret == SOCKET_ERROR)
	{
        if (this->Error() == WSAEMSGSIZE)
            return length;
	}
	
    return ret;
}

INT32 StreamSocket::Connect(in_addr *address, UINT16 port)
{
    assert(m_fd > 0);
	
    struct sockaddr_in name;
	
    name.sin_family = AF_INET;
    name.sin_port = htons(port);
    name.sin_addr = *address;
	
    return connect(m_fd, (struct sockaddr *)&name, sizeof(name));
}


INT32 StreamSocket::Connect(const char* address, UINT16 port)
{
    assert(m_fd > 0);
    
    struct sockaddr_in name;
	
    name.sin_family=AF_INET;
    name.sin_port=htons(port);
	
    if ( address[0] >= '1' && address[0] <= '9' )
    {
        name.sin_addr.s_addr = inet_addr(address);
    }
    else
    {
        struct hostent *h = gethostbyname(address);
        if (!h)
            return -1;
		
        name.sin_addr.s_addr = *((INT32*)(h->h_addr)); 
    }
	
    return connect(m_fd, (struct sockaddr *)&name, sizeof(name));
}


INT32 StreamSocket::Bind(in_addr *address, UINT16 port)
{
    assert(m_fd > 0);
	
    struct sockaddr_in name;
	
    name.sin_family = AF_INET;
    name.sin_port = htons(port);
    if (address)
	{
        name.sin_addr = *address;
	}
    else
	{
        name.sin_addr.s_addr = INADDR_ANY;
	}
	
    return bind(m_fd,(struct sockaddr *)&name,sizeof(name));
}

INT32 StreamSocket::Listen(UINT32 backlog)
{
    assert(m_fd > 0);
    return listen(m_fd, backlog);
}


INT32 StreamSocket::Accept(StreamSocket& ns, in_addr& address)
{
    struct sockaddr_in sa;
    int size = sizeof(sa);
	
    while(TRUE)
    {
		ns.m_fd = accept(m_fd, (struct sockaddr *)&sa, &size);
        if ( ns.m_fd != INVALID_SOCKET )
        {
            address = sa.sin_addr;
            return ns.m_fd;
        }
        else
		{
            if (this->Error() != WSAEINTR)
            {
                return ns.m_fd;
            }
		}
    }
}

INT32 StreamSocket::Wait(BOOL read, BOOL write, UINT32 time_ms)
{
    fd_set rfds, wfds;
	
    TIMEVAL tv;
	
    FD_ZERO(&rfds);
    FD_ZERO(&wfds);
	
    if (read)
        FD_SET(m_fd,&rfds);
	
    if (write)
        FD_SET(m_fd,&wfds);
	
    tv.tv_sec = time_ms / 1000;
    tv.tv_usec = time_ms % 1000;
	
    while (TRUE)
    {
        switch(select(m_fd + 1, &rfds, &wfds, NULL, (time_ms == TIME_INFINITE ? NULL : &tv)))
        {   
        case 0:			// time out 
            return 0;
			
        case (-1):		// socket error
            {
                if (this->Error() == WSAEINTR)
					break;
				
                return 0;
            }
			
        default:
            if (FD_ISSET(m_fd,&rfds))
                return 1;
            if (FD_ISSET(m_fd,&wfds))
                return 2;
			
            return 0;
		}
    }
}

BOOL StreamSocket::IsBlocking()
{
    assert(m_fd > 0);
    
	if (!this->IsValid())
        return FALSE;
	
    u_long x = 0;
    if(ioctlsocket(m_fd, FIONBIO, &x) != -1)
		return TRUE;
	
	return FALSE;
}

u_long StreamSocket::AvailableReadBytes()
{
    assert(m_fd > 0);
    if (!this->IsValid())
        return 0;
	
    u_long x = 0;
    ioctlsocket(m_fd, FIONREAD, &x);
	
    return x;
}

INT32 StreamSocket::Error()
{
    return WSAGetLastError();
}


