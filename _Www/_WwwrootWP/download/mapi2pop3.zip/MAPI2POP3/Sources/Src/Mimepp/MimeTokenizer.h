//=============================================================================
// MimeTokenizer.h
//
// Copyright (c) 1996-2004 Hunny Software, Inc
// All rights reserved.
//
// IN NO EVENT SHALL HUNNY SOFTWARE, INC BE LIABLE TO ANY PARTY FOR DIRECT,
// INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES ARISING OUT OF
// THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF HUNNY SOFTWARE,
// INC HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
// HUNNY SOFTWARE, INC SPECIFICALLY DISCLAIMS ANY WARRANTIES, INCLUDING,
// BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
// FITNESS FOR A PARTICULAR PURPOSE.  THE SOFTWARE PROVIDED HEREUNDER IS ON
// AN "AS IS" BASIS, AND HUNNY SOFTWARE, INC HAS NO OBLIGATION TO PROVIDE
// MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS.
//
//=============================================================================

#ifndef DW_MIME_TOKENIZER_H
#define DW_MIME_TOKENIZER_H

class MIMEPP_API MimeTokenizer
{
public:
    enum TokenType {
        NULL_ = 0,
        SPECIAL = 1,
        ATOM = 2,
        COMMENT = 4,
        QUOTED_STRING = 8,
        DOMAIN_LITERAL = 16,
        ERROR_ = 32
    };

    MimeTokenizer(const char* buf, int beginOffset, int endOffset);
    TokenType parseNext(int* tokenBegin, int* tokenEnd);

    static void appendDelimited(String& dst, const char* barray, int begin,
        int end, bool compact);
    static String quoteIfNecessary(const String& str);

private:
    const char* mBuffer;
    int mPos;
    int mEnd;
    TokenType parseQuotedString();
    TokenType parseComment();
    TokenType parseDomainLiteral();
    TokenType parseAtom();
};

#endif
