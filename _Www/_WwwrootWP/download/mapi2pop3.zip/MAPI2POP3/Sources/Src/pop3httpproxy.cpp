// pop3httpproxy.cpp : Implementation of WinMain 


// Note: Proxy/Stub Information
//      To build a separate proxy/stub DLL, 
//      run nmake -f pop3httpproxyps.mk in the project directory.

#include "stdafx.h"
#include "resource.h"
#include <initguid.h>
#include "Socket.h"
#include "common.h"
#include "SmtpPop3/SmtpPop3d.h"
#include "AboutDlg.h"

CSettings sets;
CServiceModule _Module;
CAboutDlg* pLog=0;
void CSettings::Load()
{
	CDataXMLSaver IniFile(getFileFullName(CString(GetApplicationName())+".conf"),"application-config",TRUE);
	IniFile.getValue("language",lLang);
	IniFile.getValue("hide-tray-icon",lHideicon,0);
	IniFile.getValue("log-file-path",sLogFile);
	IniFile.getValue("mapi-profile-pop3",sPop3DefaultProfile,OPT_ASKUSER);
	IniFile.getValue("mapi-profile-smtp",sSmtpDefaultProfile,OPT_ASKUSER);
	IniFile.getValue("mapi-store-for-pop3",sDefaultStore);
	IniFile.getValue("mapi-folder-for-pop3",sDefaultFolder);
	IniFile.getValue("mapi-maxmails-for-pop3",iMaxMessagesPerLoad);
	IniFile.getValue("mapi-fmask-for-pop3",sFolderMask);
	IniFile.getValue("convert-all-to-plain-text",lGetAsTextEverything);
	IniFile.getValue("force-exch-to-le",lForceExchangeLE);
	IniFile.getValue("force-pop-before-smtp",dwPopBeforeSmtpTime,0);
	IniFile.getValue("pop3-proxy-port",lPop3Port,45012);
	IniFile.getValue("pop3-proxy-timeout",lPop3TimeOut,30);
	IniFile.getValue("smtp-proxy-port",lSmtpPort,45013);
	IniFile.getValue("donot-actually-send",lDoNotActSend);
	IniFile.getValue("donot-actually-delete-received",lDoNotActDelReceived);
	IniFile.getValue("use-backward-outlook-compatibility",lUseBackwComp);
	IniFile.getValue("use-backward-outlook-compatSmtp",lUseBackwCompSmtp);
	IniFile.getValue("statmsg",lStat_Msg);
	IniFile.getValue("statses",lStat_Ses);
	
	if(!IniFile.IsFileLoaded()){
		bChanged=1;
		Save();
	}
	AddLog("Starting proxy");
}

void CSettings::Save()
{
	if(!bChanged){
		return;
	}
	bChanged=0;
	CDataXMLSaver IniFile(getFileFullName(CString(GetApplicationName())+".conf"),"application-config",FALSE);
	IniFile.putValue("language",lLang);
	IniFile.putValue("hide-tray-icon",lHideicon);
	IniFile.putValue("log-file-path",sLogFile);
	IniFile.putValue("mapi-profile-pop3",sPop3DefaultProfile);
	IniFile.putValue("mapi-profile-smtp",sSmtpDefaultProfile);
	IniFile.putValue("mapi-store-for-pop3",sDefaultStore);
	IniFile.putValue("mapi-folder-for-pop3",sDefaultFolder);
	IniFile.putValue("mapi-maxmails-for-pop3",iMaxMessagesPerLoad);
	IniFile.putValue("mapi-fmask-for-pop3",sFolderMask);
	IniFile.putValue("convert-all-to-plain-text",lGetAsTextEverything);
	IniFile.putValue("force-exch-to-le",lForceExchangeLE);
	IniFile.putValue("force-pop-before-smtp",dwPopBeforeSmtpTime);
	IniFile.putValue("pop3-proxy-port",lPop3Port);
	IniFile.putValue("pop3-proxy-timeout",lPop3TimeOut);
	IniFile.putValue("smtp-proxy-port",lSmtpPort);
	IniFile.putValue("donot-actually-send",lDoNotActSend);
	IniFile.putValue("donot-actually-delete-received",lDoNotActDelReceived);
	IniFile.putValue("use-backward-outlook-compatibility",lUseBackwComp);
	IniFile.putValue("use-backward-outlook-compatSmtp",lUseBackwCompSmtp);
	IniFile.putValue("statmsg",lStat_Msg);
	IniFile.putValue("statses",lStat_Ses);
}


int AddBitmapToIList(CImageList& list, UINT bmpID)
{
	CBitmap* bmp=new CBitmap;
	bmp->LoadBitmap(bmpID);
	int iRes=list.Add(bmp, RGB(255, 255, 255)); 
	delete bmp;
	return iRes;
}

#include "MSMapi\MapiStuffClient.h"
std::vector<std::string> profilesForOptions;
int iImgList=0;
CImageList MainImageList;
long lOptionsDialogOpened=0;
BOOL CALLBACK AddOptionsToDialog(CDLG_Options* pData);
BOOL CALLBACK ProcessUpMenu(WPARAM wParam, LPARAM lParam, CDLG_Options* pDialog);
#define OC_STARTUP	1
#define OC_LANG		2
#define OC_ICONS	3
#define OC_LICDATA	4
#define PROG_REGKEY "SOFTWARE\\"COMPANY_NAME"\\MAPI2POP3"
CString sProflist;
long isProflist=0;
CString sProflistS;
long isProflistS=0;
CString sLangsNames="English";
int GetBuffersLang(CStringArray& aLangBufferNames, int& iDefLang)
{
	int iLang=0;
	CFileInfoArray dir;
	aLangBufferNames.RemoveAll();
	CString sStartDir=GetApplicationDir();
	dir.AddDir(sStartDir,"*.lng",FALSE,CFileInfoArray::AP_SORTBYNAME | CFileInfoArray::AP_SORTASCENDING,FALSE);
	int iSize=dir.GetSize();
	if(iSize<=1){
		iSize=1;
		iDefLang=0;
		aLangBufferNames.Add("English");
		sLangsNames="English";
	}else if(iSize>1){
		for(int i=0;i<iSize;i++){
			CString sLangName=GetLangName(i);
			aLangBufferNames.Add(sLangName);
		}
		sLangsNames="";
		for(i=0;i<aLangBufferNames.GetSize();i++){
			sLangsNames+=aLangBufferNames[i];
			sLangsNames+="\t";
		}
		sLangsNames.TrimRight();
	}
	return iSize;
}

BOOL __stdcall OpenWPCom(HIROW hData, CDLG_Options* pDialog)
{
	ShellExecute(0,"open","http://www.wiredplane.com/",NULL,NULL,SW_SHOW);
	return TRUE;
}

BOOL __stdcall ShiftEmails(HIROW hData, CDLG_Options* pDialog)
{
	sets.lEmailShift=time(0);
	AfxMessageBox(_l("Shift complited. Re-retrieve emails in your POP3 client"));
	return 0;
}


BOOL bFileDialogOpened=FALSE;
BOOL OpenFileDialog(const char* szExtension, LPVOID lpData, CDLG_Options* pDialog, BOOL bSkipFileCheck=FALSE, BOOL bWithCString=FALSE, BOOL bOpenDialog=TRUE)
{
	if(bFileDialogOpened){
		return FALSE;
	}
	if(lpData==NULL){
		return FALSE;
	}
	CString sFile;
	HIROW hData=NULL;
	CString* sOutFileName=NULL;
	if(bWithCString){
		sOutFileName=(CString*)lpData;
		sFile=*sOutFileName;
	}else{
		hData=(HIROW)lpData;
		sFile=pDialog->m_OptionsList.GetIItemText(hData,1);
	}
	BOOL bRes=FALSE;
	bFileDialogOpened=TRUE;
	CFileDialog dlg(bOpenDialog, NULL, bSkipFileCheck?((const char*)NULL):(sFile), OFN_NODEREFERENCELINKS, szExtension, pDialog);//OFN_EXPLORER|OFN_ENABLESIZING|
	if(dlg.DoModal()==IDOK){
		bRes=TRUE;
		CString sNewFile=dlg.GetPathName();
		if(pDialog && hData){
			pDialog->m_OptionsList.SetIItemText(hData,1,sNewFile);
			FLNM_ROWSTATE flnmRowState;
			flnmRowState.bCollapsed= FALSE;
			flnmRowState.dwData= 0;
			flnmRowState.strText=sNewFile;
			flnmRowState.hIRow= hData;
			flnmRowState.iIItem=1;
			LRESULT result;
			pDialog->OnEndEdit((NMHDR*)(&flnmRowState), &result);
		}else if(sOutFileName){
			*sOutFileName=sNewFile;
		}
	}
	bFileDialogOpened=FALSE;
	if(!bRes && !bSkipFileCheck){
		// ������� ��� ���������� ����� �����...
		DWORD dwErr=CommDlgExtendedError();
		if(dwErr==12290){
			return OpenFileDialog(szExtension, lpData, pDialog, TRUE, bWithCString);
		}
	}
	return bRes;
}

BOOL CALLBACK AddOptionsToDialog(CDLG_Options* pData)
{
	CDLG_Options* pDialog=pData;
	if(!pDialog){
		return FALSE;
	}
	CStringArray aLangBufferNames;
	int iTempLang=GetApplicationLang();
	GetBuffersLang(aLangBufferNames,iTempLang);
	pDialog->m_OptionsList.m_crIItemText=GetSysColor(COLOR_WINDOWTEXT);
	pDialog->m_OptionsList.m_crIRowBackground=GetSysColor(COLOR_WINDOW);
	pDialog->m_OptionsList.SetBkColor(GetSysColor(COLOR_WINDOW));
	pDialog->m_OptionsList.m_crSelectedIRowBackground=GetSysColor(COLOR_HIGHLIGHT);
	pDialog->m_OptionsList.m_crSelectedIItemBackground=GetSysColor(COLOR_HIGHLIGHT);
	pDialog->m_OptionsList.m_crSelectedIItemText=GetSysColor(COLOR_HIGHLIGHTTEXT);
	sets.bStartWithWindows=IsStartupWithWindows();
	//-------------
	HIROW hCommon=pDialog->Option_AddHeader(FL_ROOT,_l("Outloook <-> Pop3/Smtp proxy options")+"\t"+_l("Common proxy options"),80);
	pDialog->Option_AddTitle(hCommon,_l("If you find this proxy helpful, Please donate us or check our shareware tools"),70);
	pDialog->Option_AddBOOL(hCommon,_l("Start with windows"),&sets.bStartWithWindows, 1, 0, OC_STARTUP);
	if(aLangBufferNames.GetSize()>1){
		pDialog->Option_AddCombo(hCommon,_l("Interface language"),&GetApplicationLang(),GetApplicationLang(),sLangsNames,OC_LANG);
	}
	pDialog->Option_AddCombo(hCommon,_l("Tray icon")+" ("+_l("Require application restart")+")",&sets.lHideicon, 1, _l("Show icon")+"\t"+_l("Hide icon"), OC_ICONS);
	pDialog->Option_AddTitle(hCommon,_l("Pop3 proxy parameters"));
	pDialog->Option_AddCombo(hCommon,_l("Outlook profile"),&isProflist, 0, sProflist);
	pDialog->Option_AddNString(hCommon,_l("Pop3 proxy port"),&sets.lPop3Port,45012,128,65534);
	pDialog->Option_AddNString(hCommon,_l("Pop3 timeout in seconds"),&sets.lPop3TimeOut,30,5,65534);
	pDialog->Option_AddBOOL(hCommon,_l("Do not delete messages from Outlook"),&sets.lDoNotActDelReceived, 0, 0);
	pDialog->Option_AddBOOL(hCommon,_l("Get emails in plain text format"),&sets.lGetAsTextEverything, 0, 0);
	pDialog->Option_AddBOOL(hCommon,_l("Force Exchange to load ALL emails"),&sets.lForceExchangeLE, 0, 0);
	pDialog->Option_AddBOOL(hCommon,_l("Use backward-compatible conversions for Outlook 2002 (or older)"),&sets.lUseBackwComp, 0, 0);
	pDialog->Option_AddNString(hCommon,_l("Limit maximum number of messages per Pop3 session")+"\t"+_l("Leave 0 to disable this limitation"),&sets.iMaxMessagesPerLoad,0,0,65534);
	pDialog->Option_AddString(hCommon,_l("Folder filter: download messages from folders that match this mask only")+"\t"+_l("Use '*' for partial matches. Delimit several masks with ';'. Leave blank to disable this limitation"),&sets.sFolderMask,"");
	//pDialog->Option_AddAction(hCommon,_l("Shift identifiers of incoming emails"),ShiftEmails,0,0);
	pDialog->Option_AddTitle(hCommon,_l("Smtp proxy parameters"));
	pDialog->Option_AddCombo(hCommon,_l("Outlook profile"),&isProflistS, 0, sProflistS);
	pDialog->Option_AddNString(hCommon,_l("Smtp proxy port"),&sets.lSmtpPort,45013,128,65534);
	pDialog->Option_AddNString(hCommon,_l("Force Pop before Smtp authorization (seconds)")+"\t"+_l("Time (in seconds) to allow Smtp connection after successful Pop3 connection. Leave '0' to allow unauthorized access (default)"),&sets.dwPopBeforeSmtpTime,0,0,65534);
	pDialog->Option_AddBOOL(hCommon,_l("Do not send messages actually, just leave them in the Outbox"),&sets.lDoNotActSend, 0, 0);
#ifdef _USE_MIME_
	pDialog->Option_AddBOOL(hCommon,_l("Use Exchange for parsing message body")+"\t"+_l("If you disable this option you will need mimepp.dll with proper license placed near Mapi2Pop3.exe. We do not provide this dll because it is not GPL and should be used for messaging through old Exchange servers only"),&sets.lUseBackwCompSmtp, 0, 0);
#endif
	if(GetLicense()==""){
		pDialog->Option_AddTitle(hCommon,_l("This is GPL application, you must obtain license for commersial use"),70);
		pDialog->Option_AddAction(hCommon,_l("Visit http://www.wiredplane.com/ for details"),OpenWPCom,0);
	}else{
		pDialog->Option_AddTitle(hCommon,_l("Licensed to")+": "+GetLicense(),70);
		pDialog->Option_AddAction(hCommon,_l("Visit http://www.wiredplane.com/"),OpenWPCom,0);
	}
	return 1;
}

BOOL CALLBACK ApplyOptionsFromDialog(BOOL bSaveAndClose,DWORD dwRes,CDLG_Options* dlgOpt)
{
	BOOL bRes=FALSE;
	/*if(pMainDialogWindow && (dlgOpt->bAnyHotkeyWasChanged || sets.bStartWithOptions)){
		// ��������� ������� ������� �� �������...
		pMainDialogWindow->UnRegisterMyHotKeys();
	}*/
	if(dwRes==IDOK){
		if(dlgOpt->isOptionClassChanged(OC_STARTUP)){
			StartupApplicationWithWindows(sets.bStartWithWindows);
		}
		if(dlgOpt->isOptionClassChanged(OC_LANG)){
			bRes=TRUE;
		}
		if(dlgOpt->isOptionClassChanged(OC_ICONS)){
			AfxMessageBox(_l("Tray icon options require\napplication restart in order to take effect")+"!");
		}
		// Pop3
		if(isProflist==0 || isProflist>=profilesForOptions.size()){
			sets.sPop3DefaultProfile=OPT_ASKUSER;
		}else{
			sets.sPop3DefaultProfile=profilesForOptions[isProflist].c_str();
		}
		
		// Smtp
		if(isProflistS==0 || isProflistS>=profilesForOptions.size()){
			sets.sSmtpDefaultProfile=OPT_ASKUSER;
		}else{
			sets.sSmtpDefaultProfile=profilesForOptions[isProflistS].c_str();
		}
		sets.bChanged=1;
		sets.Save();
	}
	/*
	if(pMainDialogWindow && (dlgOpt->bAnyHotkeyWasChanged || sets.bStartWithOptions)){
		// �������� �����!
		pMainDialogWindow->RegisterMyHotKeys(FALSE);
	}*/
	return bRes;
}

extern long lNoRecurse;
extern long lNoRecurseS;
void OpenOptionsDialog(const char* szDefTopic, CWnd* pParentWnd, FP_OPTIONACTION fpPostActionType, LPVOID pPostActionParam)
{
	if(lOptionsDialogOpened){
		return;
	}
	SimpleTracker Track(lOptionsDialogOpened);
	{// ��������� �������
		SimpleTracker lc(lNoRecurse);
		SimpleTracker lc2(lNoRecurseS);
		if(lNoRecurse>1 || lNoRecurseS>1){
			AfxMessageBox(_l("Proxy server is busy now. Please try later"));
			return;
		}
		isProflist=0;
		isProflistS=0;
		sProflistS="";
		CMapiStuffClient request;
		request.mapi_LoadExchange();
		int iCount=0;
		if (request.mapi_Libraries.size()>0){// we require at least one mapi-x implementation
			profilesForOptions.clear();
			std::list<std::string> proflist;
			request.mapi_OpenExchange(EXCH_PURPOSE_GETPROFILES,&proflist,0);
			for (std::list<std::string>::const_iterator profile=proflist.begin(); profile!=proflist.end(); profile++){
				profilesForOptions.push_back(profile->c_str());
				sProflistS+=profile->c_str();
				sProflistS+="\t";
				iCount++;
			}
		}
		profilesForOptions.push_back(std::string(OPT_ASKUSER));
		sProflistS+=_l(OPT_ASKUSER);
		sProflistS+="\t";
		profilesForOptions.push_back(std::string(OPT_DEFAULT));
		sProflistS+=_l(OPT_DEFAULT);
		sProflistS+="\t";
		profilesForOptions.push_back(std::string(OPT_FROMPOP3));
		sProflistS+=_l(OPT_FROMPOP3);
		sProflistS+="\t";
		
		int iNum=0;
		for (std::vector<std::string>::const_iterator profileI=profilesForOptions.begin(); profileI!=profilesForOptions.end(); profileI++){
			if(sets.sPop3DefaultProfile==profileI->c_str()){
				isProflist=iNum;
			}
			if(sets.sSmtpDefaultProfile==profileI->c_str()){
				isProflistS=iNum;
			}
			iNum++;
		}
		
		sProflist=sProflistS;
		sProflist.TrimRight();
		sProflistS.TrimRight();
		
		if(profilesForOptions.size()==0){
			AfxMessageBox(_l("There are no valid Outlook profiles found.\nCreate at least one Outlook profile first"));
		}
	}
	// ������� ��������� �������...
	if(iImgList==0){
		iImgList=1;
		HIMAGELIST hIList=ImageList_Create(16, 16, ILC_COLOR16 | ILC_MASK, 0, 2);
		ImageList_AddMasked(hIList,::LoadBitmap(_Module.m_hInst,MAKEINTRESOURCE(IDB_IMAGELIST)),RGB(255,255,255));
		MainImageList.Attach(hIList);
	}
	CDLG_Options_Startup pStartupInfo;
	pStartupInfo.fpInitOptionList=AddOptionsToDialog;
	pStartupInfo.fpApplyOptionList=ApplyOptionsFromDialog;
	pStartupInfo.fpUpMenuAction=0;
	pStartupInfo.iStickPix=10;
	pStartupInfo.szRegSaveKey=PROG_REGKEY"\\OptionsWindowPosition";
	pStartupInfo.pImageList=&MainImageList;
	pStartupInfo.szWindowTitle=CString(GetApplicationName())+": "+_L("Options");
	pStartupInfo.sz1stTopic=_l("Options");
	pStartupInfo.iWindowIcon=IDR_MAINICOX;
	pStartupInfo.szDefaultTopicTitle=_l("Options");
	pStartupInfo.fpPostAction=0;
	pStartupInfo.pPostActionParam=0;
	pStartupInfo.szQHelpByDefault=CString(GetApplicationName())+" - "+_l("Preferences");
	CDLG_Options dlgOpt(pStartupInfo,pParentWnd);
	DWORD dwRes=dlgOpt.DoModal();
}


BEGIN_OBJECT_MAP(ObjectMap)
END_OBJECT_MAP()


LPCTSTR FindOneOf(LPCTSTR p1, LPCTSTR p2)
{
    while (p1 != NULL && *p1 != NULL)
    {
        LPCTSTR p = p2;
        while (p != NULL && *p != NULL)
        {
            if (*p1 == *p)
                return CharNext(p1);
            p = CharNext(p);
        }
        p1 = CharNext(p1);
    }
    return NULL;
}

// Although some of these functions are big they are declared inline since they are only used once

inline HRESULT CServiceModule::RegisterServer(BOOL bRegTypeLib, BOOL bService)
{
    HRESULT hr = CoInitialize(NULL);
    if (FAILED(hr))
        return hr;

    // Remove any previous service since it may point to
    // the incorrect file
    Uninstall();

    // Add service entries
    UpdateRegistryFromResource(IDR_Pop3httpproxy, TRUE);

    // Adjust the AppID for Local Server or Service
    CRegKey keyAppID;
    LONG lRes = keyAppID.Open(HKEY_CLASSES_ROOT, _T("AppID"), KEY_WRITE);
    if (lRes != ERROR_SUCCESS)
        return lRes;

    CRegKey key;
    lRes = key.Open(keyAppID, _T("{20AA96E8-2F55-4423-B51C-E0FEBFBBF6D0}"), KEY_WRITE);
    if (lRes != ERROR_SUCCESS)
        return lRes;
    key.DeleteValue(_T("LocalService"));
    
    if (bService)
    {
        key.SetValue(_T("MApi2Pop3_Proxy"), _T("LocalService"));
        key.SetValue(_T("-Service"), _T("ServiceParameters"));
        // Create service
        Install();
    }

    // Add object entries
    hr = CComModule::RegisterServer(bRegTypeLib);

    CoUninitialize();
    return hr;
}

inline HRESULT CServiceModule::UnregisterServer()
{
    HRESULT hr = CoInitialize(NULL);
    if (FAILED(hr))
        return hr;

    // Remove service entries
    UpdateRegistryFromResource(IDR_Pop3httpproxy, FALSE);
    // Remove service
    Uninstall();
    // Remove object entries
    CComModule::UnregisterServer(TRUE);
    CoUninitialize();
    return S_OK;
}

inline void CServiceModule::Init(_ATL_OBJMAP_ENTRY* p, HINSTANCE h, UINT nServiceNameID, const GUID* plibid)
{
    CComModule::Init(p, h, plibid);

    m_bService = TRUE;

    LoadString(h, nServiceNameID, m_szServiceName, sizeof(m_szServiceName) / sizeof(TCHAR));

    // set up the initial service status 
    m_hServiceStatus = NULL;
    m_status.dwServiceType = SERVICE_WIN32_OWN_PROCESS;
    m_status.dwCurrentState = SERVICE_STOPPED;
    m_status.dwControlsAccepted = SERVICE_ACCEPT_STOP;
    m_status.dwWin32ExitCode = 0;
    m_status.dwServiceSpecificExitCode = 0;
    m_status.dwCheckPoint = 0;
    m_status.dwWaitHint = 0;
}

LONG CServiceModule::Unlock()
{
    LONG l = CComModule::Unlock();
    if (l == 0 && !m_bService)
        PostThreadMessage(dwThreadID, WM_QUIT, 0, 0);
    return l;
}

BOOL CServiceModule::IsInstalled()
{
    BOOL bResult = FALSE;

    SC_HANDLE hSCM = ::OpenSCManager(NULL, NULL, SC_MANAGER_ALL_ACCESS);

    if (hSCM != NULL)
    {
        SC_HANDLE hService = ::OpenService(hSCM, m_szServiceName, SERVICE_QUERY_CONFIG);
        if (hService != NULL)
        {
            bResult = TRUE;
            ::CloseServiceHandle(hService);
        }
        ::CloseServiceHandle(hSCM);
    }
    return bResult;
}

inline BOOL CServiceModule::Install()
{
    if (IsInstalled())
        return TRUE;

    SC_HANDLE hSCM = ::OpenSCManager(NULL, NULL, SC_MANAGER_ALL_ACCESS);
    if (hSCM == NULL)
    {
        MessageBox(NULL, _T("Couldn't open service manager"), m_szServiceName, MB_OK);
        return FALSE;
    }

    // Get the executable file path
    TCHAR szFilePath[_MAX_PATH];
    ::GetModuleFileName(NULL, szFilePath, _MAX_PATH);

    SC_HANDLE hService = ::CreateService(
        hSCM, m_szServiceName, m_szServiceName,
        SERVICE_ALL_ACCESS, SERVICE_WIN32_OWN_PROCESS,
        SERVICE_DEMAND_START, SERVICE_ERROR_NORMAL,
        szFilePath, NULL, NULL, _T("RPCSS\0"), NULL, NULL);

    if (hService == NULL)
    {
        ::CloseServiceHandle(hSCM);
        MessageBox(NULL, _T("Couldn't create service"), m_szServiceName, MB_OK);
        return FALSE;
    }

    ::CloseServiceHandle(hService);
    ::CloseServiceHandle(hSCM);
    return TRUE;
}

inline BOOL CServiceModule::Uninstall()
{
    if (!IsInstalled())
        return TRUE;

    SC_HANDLE hSCM = ::OpenSCManager(NULL, NULL, SC_MANAGER_ALL_ACCESS);

    if (hSCM == NULL)
    {
        MessageBox(NULL, _T("Couldn't open service manager"), m_szServiceName, MB_OK);
        return FALSE;
    }

    SC_HANDLE hService = ::OpenService(hSCM, m_szServiceName, SERVICE_STOP | DELETE);

    if (hService == NULL)
    {
        ::CloseServiceHandle(hSCM);
        MessageBox(NULL, _T("Couldn't open service"), m_szServiceName, MB_OK);
        return FALSE;
    }
    SERVICE_STATUS status;
    ::ControlService(hService, SERVICE_CONTROL_STOP, &status);

    BOOL bDelete = ::DeleteService(hService);
    ::CloseServiceHandle(hService);
    ::CloseServiceHandle(hSCM);

    if (bDelete)
        return TRUE;

    MessageBox(NULL, _T("Service could not be deleted"), m_szServiceName, MB_OK);
    return FALSE;
}

///////////////////////////////////////////////////////////////////////////////////////
void CServiceModule::LogEvent(LPCTSTR pFormat, ...)
{
    TCHAR    chMsg[256];
    HANDLE  hEventSource;
    LPTSTR  lpszStrings[1];
    va_list pArg;

    va_start(pArg, pFormat);
    _vstprintf(chMsg, pFormat, pArg);
    va_end(pArg);

    lpszStrings[0] = chMsg;

    if (m_bService)
    {
        /* Get a handle to use with ReportEvent(). */
        hEventSource = RegisterEventSource(NULL, m_szServiceName);
        if (hEventSource != NULL)
        {
            /* Write to event log. */
            ReportEvent(hEventSource, EVENTLOG_INFORMATION_TYPE, 0, 0, NULL, 1, 0, (LPCTSTR*) &lpszStrings[0], NULL);
            DeregisterEventSource(hEventSource);
        }
    }
    else
    {
        // As we are not running as a service, just write the error to the console.
        _putts(chMsg);
    }
}

//////////////////////////////////////////////////////////////////////////////////////////////
// Service startup and registration
inline void CServiceModule::Start()
{
    SERVICE_TABLE_ENTRY st[] =
    {
        { m_szServiceName, _ServiceMain },
        { NULL, NULL }
    };
    if (m_bService && !::StartServiceCtrlDispatcher(st))
    {
        m_bService = FALSE;
    }
    if (m_bService == FALSE)
        Run();
}

inline void CServiceModule::ServiceMain(DWORD /* dwArgc */, LPTSTR* /* lpszArgv */)
{
    // Register the control request handler
    m_status.dwCurrentState = SERVICE_START_PENDING;
    m_hServiceStatus = RegisterServiceCtrlHandler(m_szServiceName, _Handler);
    if (m_hServiceStatus == NULL)
    {
        LogEvent(_T("Handler not installed"));
        return;
    }
    SetServiceStatus(SERVICE_START_PENDING);

    m_status.dwWin32ExitCode = S_OK;
    m_status.dwCheckPoint = 0;
    m_status.dwWaitHint = 0;

    // When the Run function returns, the service has stopped.
    Run();

    SetServiceStatus(SERVICE_STOPPED);
    LogEvent(_T("Service stopped"));
}

inline void CServiceModule::Handler(DWORD dwOpcode)
{
    switch (dwOpcode)
    {
    case SERVICE_CONTROL_STOP:
        SetServiceStatus(SERVICE_STOP_PENDING);
        PostThreadMessage(dwThreadID, WM_QUIT, 0, 0);
        break;
    case SERVICE_CONTROL_PAUSE:
        break;
    case SERVICE_CONTROL_CONTINUE:
        break;
    case SERVICE_CONTROL_INTERROGATE:
        break;
    case SERVICE_CONTROL_SHUTDOWN:
        break;
    default:
        LogEvent(_T("Bad service request"));
    }
}

void WINAPI CServiceModule::_ServiceMain(DWORD dwArgc, LPTSTR* lpszArgv)
{
    _Module.ServiceMain(dwArgc, lpszArgv);
}
void WINAPI CServiceModule::_Handler(DWORD dwOpcode)
{
    _Module.Handler(dwOpcode); 
}

void CServiceModule::SetServiceStatus(DWORD dwState)
{
    m_status.dwCurrentState = dwState;
    ::SetServiceStatus(m_hServiceStatus, &m_status);
}

void threadFunction(void* args)
{
	if(StreamSocket::Init() == 0)
	{
		StreamSocket listenSocket;
		listenSocket.Create();

		in_addr localAddress;
		localAddress.S_un.S_addr = inet_addr("127.0.0.1");
		UINT16 localPort = (UINT16)sets.lPop3Port;

		listenSocket.Bind(&localAddress, localPort);
		listenSocket.Listen(1);

		StreamSocket incomingSocket; in_addr incomingAddress;
		
		while(TRUE)
		{
			listenSocket.Accept(incomingSocket, incomingAddress);
			main_loopPop3(incomingSocket);
			incomingSocket.Close();
		}

		listenSocket.Close();
	}

	StreamSocket::DeInit();
}

void threadFunctionSmtp(void* args)
{
	if(StreamSocket::Init() == 0)
	{
		StreamSocket listenSocket;
		listenSocket.Create();

		in_addr localAddress;
		localAddress.S_un.S_addr = inet_addr("127.0.0.1");
		UINT16 localPort = (UINT16)sets.lSmtpPort;

		listenSocket.Bind(&localAddress, localPort);
		listenSocket.Listen(1);

		StreamSocket incomingSocket; in_addr incomingAddress;
		
		while(TRUE)
		{
			listenSocket.Accept(incomingSocket, incomingAddress);
			main_loopSmtp(incomingSocket);
			incomingSocket.Close();
		}

		listenSocket.Close();
	}

	StreamSocket::DeInit();
}

CWnd mainWnd;
CMyApp theApp;
void ShowOptions()
{
	OpenOptionsDialog(0,&mainWnd,0,0);
};

WNDPROC lpPrevWndFunc=0;
UINT iWMTHIS=GetProgramWMMessage();
LRESULT CALLBACK MyWndProc(HWND hWnd,UINT Msg,WPARAM wParam,LPARAM lParam)
{
	if(Msg==iWMTHIS){
		ShowOptions();
		return 0;
	}
	if(Msg==WM_USER){
		if(lParam==WM_RBUTTONUP){
			CMenu mn;
			mn.CreatePopupMenu();
			BOOL bBusy=(lNoRecurse>0 || lNoRecurseS>0);
			AddMenuString(&mn,WM_USER+6,_l("Show log"),0);
			AddMenuString(&mn,WM_USER+2,_l("Options"),0,0,0,bBusy);
			AddMenuString(&mn,WM_USER+4,_l("About"),0);
			AddMenuString(&mn,WM_USER+3,_l("Open help"),0);
			/*
			if(sets.lStat_Msg<10000 && sets.lStat_Ses<10000){
				mn.AppendMenu(MF_SEPARATOR, 0, "");
				CString sSes,sMsg;
				if(sets.lStat_Ses>1000){
					sSes.Format("%iK",sets.lStat_Ses/1000);
				}else{
					sSes.Format("%i",sets.lStat_Ses);
				}
				if(sets.lStat_Msg>1000){
					sMsg.Format("%iK",sets.lStat_Msg/1000);
				}else{
					sMsg.Format("%i",sets.lStat_Msg);
				}
				AddMenuString(&mn,0,Format("%s: %s",_l("Sessions"),sSes),0,0,0,1);
				AddMenuString(&mn,0,Format("%s: %s",_l("Messages"),sMsg),0,0,0,1);
			}*/
			mn.AppendMenu(MF_SEPARATOR, 0, "");
			AddMenuString(&mn,WM_USER+1,_l("Exit"),0);
			CPoint pt;
			GetCursorPos(&pt);
			PostMessage(hWnd,0,0,0);
			SetForegroundWindow(hWnd);
			DWORD dwRetCode=TrackPopupMenu(mn.GetSafeHmenu(), TPM_RETURNCMD|TPM_NONOTIFY|TPM_LEFTBUTTON, pt.x, pt.y, 0, hWnd, NULL);
			if(dwRetCode==WM_USER+1){
				PostThreadMessage(_Module.dwThreadID,WM_QUIT,0,0);
			}
			if(dwRetCode==WM_USER+2){
				ShowOptions();
			}
			if(dwRetCode==WM_USER+3){
				ShowHelp("overview");
			}
			if(dwRetCode==WM_USER+6){
				CAboutDlg d;
				pLog=&d;
				d.DoModal();
				pLog=0;
			}
			if(dwRetCode==WM_USER+4){
				CString sAb=_l(
					"Mapi<->Pop3/Smtp proxy. With this program you can transparently\n"
					"send/receive emails via local Outlook/Exchange server\n"
					"in any Pop3/Smtp enabled application");
				sAb+="\nVersion: "VERSION"\n";
				sAb+="\n";
				if(GetLicense()==""){
					sAb+=_l("If you find this proxy helpful, Please donate us or check our trialware personal tools!");
					sAb+="\n";
					sAb+=_l("Warning: This is GPL application, you must obtain license for commersial use");
					sAb+="\n";
					sAb+=_l("Visit http://www.wiredplane.com/ for details");
					sAb+="\n";
				}else{
					sAb+=_l("Licensed to")+": "+GetLicense();
				}
				sAb+="\n";
				AfxMessageBox(sAb+"\n@2006 Razinkov Ilja, WiredPlane.com.\nAll rights reserved.");
			}
		}
		return 0;
	}
	return CallWindowProc(lpPrevWndFunc,hWnd,Msg,wParam,lParam);
}

NOTIFYICONDATA2 m_tnd;
BOOL bUsingShell5=-1;
typedef HRESULT (CALLBACK *FPDllGetVersion) (DLLVERSIONINFO *pdvi);
BOOL SetTooltipText(LPCTSTR pszTip, BOOL bWithLog)
{
	if(bWithLog && pszTip[0]){
		sets.AddLog("%s",pszTip);
	}
	CString sTootext=pszTip;
	if(strlen(sTootext)==0){
		sTootext="MAPI2POP3 Proxy v"VERSION;
	}
	if(strlen(sTootext)>250){
		sTootext=sTootext.Left(250)+"...";
	}
	if(sets.lHideicon==1 || !bUsingShell5){
		return 0;
	}
	strcpy(m_tnd.szInfo, sTootext);
	m_tnd.uFlags = 0x00000004;//N-*IF_INFO;m_tnd.uFlags = NIF_TIP;
	Shell_NotifyIcon(NIM_MODIFY, (PNOTIFYICONDATA)&m_tnd);
	return 1;
}

void CServiceModule::Run()
{
    _Module.dwThreadID = GetCurrentThreadId();
	sets.Load();
	// ������������ ������
	char domainName[128]={0},domainDns[128]={0};
	ExpandEnvironmentStrings(_T("%USERDOMAIN%"),domainName,128);
	ExpandEnvironmentStrings(_T("%USERDNSDOMAIN%"),domainDns,128);
	CString sTotal=domainName;
	sTotal+=domainDns;
	sTotal.MakeLower();
    HRESULT hr = CoInitialize(NULL);
	//  If you are running on NT 4.0 or higher you can use the following call
	//  instead to make the EXE free threaded.
	//  This means that calls come in on a random RPC thread
	//  HRESULT hr = CoInitializeEx(NULL, COINIT_MULTITHREADED);
	
    // This provides a NULL DACL which will allow access to everyone.
    CSecurityDescriptor sd;
    sd.InitializeFromThreadToken();
    hr = CoInitializeSecurity(sd, -1, NULL, NULL,
        RPC_C_AUTHN_LEVEL_PKT, RPC_C_IMP_LEVEL_IMPERSONATE, NULL, EOAC_NONE, NULL);
	
    hr = _Module.RegisterClassObjects(CLSCTX_LOCAL_SERVER | CLSCTX_REMOTE_SERVER, REGCLS_MULTIPLEUSE);
	
    LogEvent(_T("Service started"));
    if (m_bService)
        SetServiceStatus(SERVICE_RUNNING);
	
	sets.inService=m_bService;
	_beginthread(threadFunction, 0, NULL);
	_beginthread(threadFunctionSmtp, 0, NULL);
	HWND hWin = ::CreateWindowEx(WS_EX_TOPMOST|WS_EX_TRANSPARENT, "Static", "MAPI2POP3_WND", WS_POPUP, -200, -200, 50, 50, 0, 0, _Module.m_hInst, 0);
	mainWnd.Attach(hWin);
	lpPrevWndFunc=(WNDPROC)GetWindowLong(hWin,GWL_WNDPROC);
	SetWindowLong(hWin,GWL_WNDPROC,(LONG)MyWndProc);
	theApp.m_pMainWnd=&mainWnd;
	memset(&m_tnd,0,sizeof(m_tnd));
	if(bUsingShell5==-1){
		bUsingShell5=0;
		// ���������� ������ ShellDLL
		HMODULE hShell=LoadLibrary("Shell32.dll");
		if(hShell){
			FPDllGetVersion fp=(FPDllGetVersion)GetProcAddress(hShell,"DllGetVersion");
			if(fp){
				DLLVERSIONINFO dvi;
				memset(&dvi,0,sizeof(dvi));
				dvi.cbSize=sizeof(DLLVERSIONINFO);
				(*fp)(&dvi);
				if(dvi.dwMajorVersion>=5){
					bUsingShell5=1;
				}
			}
			FreeLibrary(hShell);
		}
	}
	long lShowIcon=(sets.lHideicon==0);
	if(lShowIcon){
		m_tnd.cbSize = bUsingShell5?sizeof(NOTIFYICONDATA2):sizeof(NOTIFYICONDATA0);
		m_tnd.hWnd   = hWin;
		m_tnd.hIcon  = ::LoadIcon(_Module.m_hInst,MAKEINTRESOURCE(IDR_MAINICOX));
		m_tnd.uFlags = NIF_MESSAGE | NIF_ICON | NIF_TIP;//| NIF_STATE
		m_tnd.uID    = 0;
		m_tnd.uCallbackMessage = WM_USER;
		_tcscpy(m_tnd.szTip, "MAPI2POP3 Proxy v"VERSION);
		Shell_NotifyIcon(NIM_ADD, (PNOTIFYICONDATA)&m_tnd);
	}
	MSG msg;
	while (GetMessage(&msg, 0, 0, 0)){
		DispatchMessage(&msg);
	}
	if(lShowIcon){
		m_tnd.uFlags = 0;
		Shell_NotifyIcon(NIM_DELETE, (PNOTIFYICONDATA)&m_tnd);
	}
	
	sets.Save();
    _Module.RevokeClassObjects();
	theApp.m_pMainWnd=0;
	SetWindowLong(hWin,GWL_WNDPROC,(LONG)lpPrevWndFunc);
	mainWnd.Detach();
	DestroyWindow(hWin);
    CoUninitialize();
}


/////////////////////////////////////////////////////////////////////////////
int iStarted=0;
int ModuleWinMain(HINSTANCE hInstance, HINSTANCE, LPTSTR lpCmdLine, int)
{
	if(IsThisProgrammAlreadyRunning()){
		DWORD dwTarget=BSM_APPLICATIONS;
		BroadcastSystemMessage(BSF_FORCEIFHUNG | BSF_IGNORECURRENTTASK | BSF_POSTMESSAGE, &dwTarget, iWMTHIS, WPARAM(99), LPARAM(99));
		return FALSE;
	}
	iStarted=1;
    lpCmdLine = GetCommandLine(); //this line necessary for _ATL_MIN_CRT
    _Module.Init(ObjectMap, hInstance, IDS_SERVICENAME, 0);//&LIBID_POP3HTTPPROXYLib
    _Module.m_bService = FALSE;

    CRegKey keyAppID;
    LONG lRes = keyAppID.Open(HKEY_CLASSES_ROOT, _T("AppID"), KEY_READ);
    if (lRes == ERROR_SUCCESS){
		CRegKey key;
		lRes = key.Open(keyAppID, _T("{20AA96E8-2F55-4423-B51C-E0FEBFBBF6D0}"), KEY_READ);
		if (lRes == ERROR_SUCCESS){
			TCHAR szValue[_MAX_PATH];
			DWORD dwLen = _MAX_PATH;
			lRes = key.QueryValue(szValue, _T("LocalService"), &dwLen);
			if (lRes == ERROR_SUCCESS)
				_Module.m_bService = TRUE;
		}
	}
    _Module.Start();
    return _Module.m_status.dwWin32ExitCode;
}

void _log(DWORD dwLevel,const char* szString,...)
{
	va_list vaList;
	va_start(vaList,szString);
	CString sBuffer;
	sBuffer.FormatV(szString,vaList);
	va_end (vaList);
	sets.AddLog("%s",sBuffer);
	return;
}

BOOL CMyApp::InitInstance()
{
	// Initialize OLE libraries.
	if (!AfxOleInit())
	{
		AfxMessageBox(_T("OLE Initialization Failed!"));
		return FALSE;
	}

	ModuleWinMain(theApp.m_hInstance, 0, "", 0);
	return TRUE;
}

int CMyApp::ExitInstance()
{
	if(iStarted){
		_Module.Term();
	}
	return 0;
}

void CSettings::AddLog(const char* szFormat,...)
{
	CString a;
	va_list vaList;
	va_start(vaList,szFormat);
	a.FormatV(szFormat,vaList);
	a=COleDateTime::GetCurrentTime().Format("[%x %X] ")+a;
	va_end (vaList);
	sLogFileBuffer=a+"\r\n"+sLogFileBuffer;
	if(sLogFileBuffer.GetLength()>10000){
		sLogFileBuffer=sLogFileBuffer.Left(10000);
	}
	if(pLog && IsWindow(pLog->GetSafeHwnd())){
		pLog->GetDlgItem(IDC_EDIT)->SetWindowText(sLogFileBuffer);
	}
	if(sLogFile!=""){
		FILE* f=fopen(sLogFile,"a+");
		if(f){
			fprintf(f,a);
			fprintf(f,"\n");
			fclose(f);
		};
	}
}

CString GetLicense()
{
	CString sContent;
	ReadFile(CString(GetApplicationDir())+LICENSE_KEY_FILE,sContent);
	if(sContent!=""){
		CString sLicName=CDataXMLSaver::GetInstringPart("<license>","</license>",sContent);
		sLicName.TrimLeft();
		sLicName.TrimRight();
		if(sLicName!=""){
			CString sLicKey=CDataXMLSaver::GetInstringPart("<hash>","</hash>",sContent);
			CBase64XXX wrd(1);
			CString sHashTst=wrd.Encode(sLicName);
			if(sHashTst==sLicKey)
			{
				return sLicName;
			}
		}
	}
	return "";
}
