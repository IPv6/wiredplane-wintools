#ifndef _SOCKET_H_
#define _SOCKET_H_

#include <winsock.h>

#define TIME_INFINITE	0xffffffff

typedef unsigned __int16 UINT16;

class StreamSocket
{
public:
	
    StreamSocket() : m_fd(0) {};
    ~StreamSocket() {};
	
    static	INT32 Init();
	static	INT32 DeInit();
	
    INT32	Create();
    INT32	Close();
	
    INT32	Write(char *buffer, UINT32 length);
    INT32	Read(char *buffer, UINT32 length);
    INT32	Peek(char *buffer, UINT32 length);
	
    INT32	Connect(in_addr *address, UINT16 port);
    INT32	Connect(const char* address, UINT16 port);
    INT32	Bind(in_addr *address, UINT16 port);
    INT32	Listen(UINT32 backlog);
    INT32	Accept(StreamSocket& ns, in_addr& address);
    INT32	Wait(BOOL read, BOOL write, UINT32 time_ms);
	
    BOOL	IsBlocking();
    u_long	AvailableReadBytes();
	BOOL	IsValid() {return m_fd > 0;}
	
    void	SetFD(SOCKET socket) {m_fd = socket;}
    SOCKET	GetFD() {return m_fd;}
	
	INT32	Error();
	
private:
    //SOCKET m_fd;
	INT32 m_fd;
};


#endif
