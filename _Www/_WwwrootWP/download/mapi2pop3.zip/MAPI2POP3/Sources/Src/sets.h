#ifndef __SETS
#define __SETS

#include <afxtempl.h>

class CSettings
{
public:
	CSettings()
	{
		dwPopBeforeSmtpTime=0;
		lStat_Msg=0;
		lStat_Ses=0;
		lGetAsTextEverything=0;
		lForceExchangeLE=0;
		lLang=0;
		lPop3Port=45012;
		lPop3TimeOut=30;
		lSmtpPort=45013;
		lHideicon=0;
		inService=0;
		bNoUI=0;
		bChanged=1;
		lDoNotActSend=0;
		lDoNotActDelReceived=0;
		bStartWithWindows=0;
		lUseBackwComp=0;
		lUseBackwCompSmtp=0;
		lEmailShift=0;
	}
	CString sPop3DefaultProfile;
	CString sSmtpDefaultProfile;
	CString sDefaultStore;
	CString sDefaultFolder;
	CString sLikUser;
	CString sLikKey;
	CString sLikFile;
	long iMaxMessagesPerLoad;
	CString sFolderMask;
	long lEmailShift;
	long lUseBackwComp;
	long lUseBackwCompSmtp;
	long bStartWithWindows;
	long inService;
	long dwPopBeforeSmtpTime;
	long lStat_Msg;
	long lStat_Ses;
	long lGetAsTextEverything;
	long lForceExchangeLE;
	long lLang;
	long lPop3Port;
	long lPop3TimeOut;
	long lSmtpPort;
	long bNoUI;
	long lHideicon;
	long lDoNotActSend;
	long lDoNotActDelReceived;
	void Load();
	void Save();
	BOOL bChanged;
	CString sLogFile;
	CString sLogFileBuffer;
	void AddLog(const char* szFormat,...);
};
#endif