// DataXMLSaver.cpp: implementation of the CDataXMLSaver class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "SupportClasses.h"
#include "DataXMLSaver.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
void CDataXMLSaver::Init()
{
	m_bAppendMode=FALSE;
	m_bRead=TRUE;
	m_sSource="";
	m_sRoot="DATA";
	m_pFile=NULL;
	m_sFileName="";
	bFileLoaded=FALSE;
	m_bDataSaved=FALSE;
}

CDataXMLSaver::CDataXMLSaver(const char* pString)
{
	Init();
	SetRoot("");
	SetSource(pString);
}

CDataXMLSaver::CDataXMLSaver(const char* szFile, const char* szRoot, BOOL bRead, BOOL bAppendMode)
{
	Init();
	m_bRead=bRead;
	m_bAppendMode=bAppendMode;
	SetRoot(szRoot);
	m_sFileName=szFile;
	if(m_bRead){
		LoadDataToSource(szFile);
	}
}

BOOL CDataXMLSaver::LoadDataToSource(const char* szFile)
{
	if(strlen(m_sFileName)==0 || ReadFile(m_sFileName,m_sSource)==FALSE){
		return FALSE;
	}
	if(m_sRoot.GetLength()>0){
		SetSource(GetInstringPart((CString)"<"+m_sRoot+">",(CString)"</"+m_sRoot+">",m_sSource));
	}
	bFileLoaded=TRUE;
	return TRUE;
}


// The 7-bit alphabet used to encode binary information
int CBase64XXX::m_nMask[] = { 0, 1, 3, 7, 15, 31, 63, 127, 255 };
CBase64XXX::CBase64XXX(BOOL bUseWierd)
{
	if(bUseWierd){
		m_sBase64Alphabet = _T( "ghijkstuDEFGHIvwxyz+ABCJ89KLM0123abcdef45NOPQRSTlmnopqrUVWXYZ/67" );
	}else{
		m_sBase64Alphabet = _T( "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/" );
	}
}

CBase64XXX::~CBase64XXX()
{
}

CString CBase64XXX::Encode(LPCTSTR szEncoding, int nSize)
{
    int nNumBits = 6;
    UINT nDigit = 0;
    int lp = 0;
    if( szEncoding == NULL ){
        return "";
	}
    m_szInput = szEncoding;
	if(nSize==-1){
		nSize=strlen(szEncoding);
	}
	DWORD dwNewLen=1+(nSize+100)*4/3;
	//CString sOutput = _T( "" );
	char* szOutput=new char[dwNewLen];
	if(szOutput==0){
		return "";
	}
	memset(szOutput,0,dwNewLen);
	int iOutputPos=0;
    m_nInputSize = nSize;
    m_nBitsRemaining = 0;
    nDigit = read_bits( nNumBits, &nNumBits, lp );
    while( nNumBits > 0 )
    {
        szOutput[iOutputPos++]=m_sBase64Alphabet[ (int)nDigit ];
        nDigit = read_bits( nNumBits, &nNumBits, lp );
    }
    // Pad with '=' as per RFC 1521
    while( iOutputPos % 4 != 0 )
    {
        szOutput[iOutputPos++]='=';
    }
    CString sRes=szOutput;
    delete[] szOutput;
    return sRes;
}

// The size of the output buffer must not be less than
// 3/4 the size of the input buffer. For simplicity,
// make them the same size.
CString CBase64XXX::Decode(LPCTSTR szDecoding, int nSize, char* szOutputDirect)
{
    CString sInput, ResultStr;
    int c, lp =0;
    int nDigit;
    int nDecode[ 256 ];
    if(nSize==-1){
		nSize=strlen(szDecoding);
	}
	LPTSTR szOutput = szOutputDirect?szOutputDirect:ResultStr.GetBuffer(nSize); // Output is never longer than input
    if( szDecoding == NULL )
        return _T("");
    sInput = szDecoding;
    if( sInput.GetLength() == 0 )
        return _T("");
    m_lBitStorage = 0;
    m_nBitsRemaining = 0;

    // Build Decode Table
    //
    for( int i = 0; i < 256; i++ ) 
        nDecode[i] = -2; // Illegal digit
    for( i=0; i < 64; i++ )
    {
        nDecode[ m_sBase64Alphabet[ i ] ] = i;
        nDecode[ m_sBase64Alphabet[ i ] | 0x80 ] = i; // Ignore 8th bit
        nDecode[ '=' ] = -1; 
        nDecode[ '=' | 0x80 ] = -1; // Ignore MIME padding char
        nDecode[ '\n'] = -1; // Skip the CR/LFs
        nDecode[ '\r'] = -1;
    }

    // Decode the Input
    //
    for( lp = 0, i = 0; lp < sInput.GetLength(); lp++ )
    {
        c = sInput[ lp ];
        nDigit = nDecode[ c & 0x7F ];
        if( nDigit < -1 ) 
        {
            return _T("");
        } 
        else if( nDigit >= 0 ) 
            // i (index into output) is incremented by write_bits()
            write_bits( nDigit & 0x3F, 6, szOutput, i );
    } 
    if(szOutputDirect==NULL){  
		ResultStr.ReleaseBuffer(i);
    }
    return ResultStr;
}

UINT CBase64XXX::read_bits(int nNumBits, int * pBitsRead, int& lp)
{
    ULONG lScratch;
    while( ( m_nBitsRemaining < nNumBits ) && 
           ( lp < m_nInputSize ) ) 
    {
        int c = m_szInput[ lp++ ];
        m_lBitStorage <<= 8;
        m_lBitStorage |= (c & 0xff);
        m_nBitsRemaining += 8;
    }
    if( m_nBitsRemaining < nNumBits ) 
    {
        lScratch = m_lBitStorage << ( nNumBits - m_nBitsRemaining );
        *pBitsRead = m_nBitsRemaining;
        m_nBitsRemaining = 0;
    } 
    else 
    {
        lScratch = m_lBitStorage >> ( m_nBitsRemaining - nNumBits );
        *pBitsRead = nNumBits;
        m_nBitsRemaining -= nNumBits;
    }
    return (UINT)lScratch & m_nMask[nNumBits];
}


void CBase64XXX::write_bits(UINT nBits,
                         int nNumBits,
                         LPTSTR szOutput,
                         int& i)
{
    UINT nScratch;

    m_lBitStorage = (m_lBitStorage << nNumBits) | nBits;
    m_nBitsRemaining += nNumBits;
    while( m_nBitsRemaining > 7 ) 
    {
        nScratch = m_lBitStorage >> (m_nBitsRemaining - 8);
        szOutput[ i++ ] = nScratch & 0xFF;
        m_nBitsRemaining -= 8;
    }
}

BOOL CDataXMLSaver::CryptBody(CString sTag)
{
	CBase64XXX dc(1);
	m_sSource=Format("<%s>%s</%s>",sTag,dc.Encode(m_sSource),sTag);
	return TRUE;
}

BOOL CDataXMLSaver::UncryptBody(CString sTag)
{
	CString sCrypted;
	getValue(sTag,sCrypted);
	if(sCrypted==""){
		return FALSE;
	}
	CBase64XXX dc(1);
	m_sSource=dc.Decode(sCrypted);
	return TRUE;
}

void CDataXMLSaver::SetRoot(const char* szRootName)
{
	m_sRoot=szRootName;
}

CString CDataXMLSaver::GetResult()
{
	CString sOut;
	if(m_sRoot.GetLength()>0){
		sOut+="<";
		sOut+=m_sRoot;
		sOut+=">\n";
	}
	sOut+=m_sSource;
	if(m_sRoot.GetLength()>0){
		sOut+="</";
		sOut+=m_sRoot;
		sOut+=">\n";
	}
	return sOut;
}

void CDataXMLSaver::SetSource(const char* szSource)
{
	m_sSource=szSource;
	return;
}

CString CDataXMLSaver::GetSource()
{
	return m_sSource;
}

BOOL CDataXMLSaver::SetAsSaved(BOOL bRes)
{
	m_bDataSaved=bRes;
	return TRUE;
}

BOOL CDataXMLSaver::SaveDataIntoSource(const char* szFileName)
{
	m_bDataSaved=FALSE;
	if(szFileName==NULL){
		szFileName=m_sFileName;
	}
	if(strlen(szFileName)!=0){
		CString sFileContent;
		if(m_bAppendMode){
			sFileContent+="\n<?wk-xml-warning:XML-incompatible append?>\n";
		}
		if(m_sRoot.GetLength()>0){
			sFileContent+="<?xml version='1.0'?>\n\n<";
			sFileContent+=m_sRoot;
			sFileContent+=">\n";
		}
		sFileContent+=m_sSource;
		sFileContent.TrimRight();
		if(m_sRoot.GetLength()>0){
			sFileContent+="\n</";
			sFileContent+=m_sRoot;
			sFileContent+=">\n";
		}
		CString sPrevContent;
		if(m_bAppendMode){
			ReadFile(szFileName,sPrevContent);
		}
		BOOL bRes=SaveFile(szFileName,sPrevContent+sFileContent);
		SetAsSaved(bRes);
	}
	return m_bDataSaved;
}

CDataXMLSaver::~CDataXMLSaver()
{
	if(!m_bRead && !m_bDataSaved){
		SaveDataIntoSource(m_sFileName);
	}
}

COleDateTime CDataXMLSaver::Str2OleDate(CString sData)
{
	COleDateTime dt;
	if(sData=="invalid"){
		dt.SetStatus(COleDateTime::invalid);
	}else{
		//sData=dt.Format("%d.%m.%Y %H:%M:%S");
		int iDotPos1=sData.Find(".")+1;
		if(iDotPos1==0){
			dt.ParseDateTime(sData);
			return dt;
		}
		int iDotPos2=sData.Find(".",iDotPos1)+1;
		if(iDotPos2==0){
			dt.ParseDateTime(sData);
			return dt;
		}
		int iSpacePos=sData.Find(" ",iDotPos2)+1;
		if(iSpacePos==0){
			dt.ParseDateTime(sData);
			return dt;
		}
		int iDDPos1=sData.Find(":",iSpacePos)+1;
		if(iDDPos1==0){
			dt.ParseDateTime(sData);
			return dt;
		}
		int iDDPos2=sData.Find(":",iDDPos1)+1;
		if(iDDPos2==0){
			dt.ParseDateTime(sData);
			return dt;
		}
		int nYear=atol(sData.Mid(iDotPos2));
		int nMonth=atol(sData.Mid(iDotPos1));
		int nDay=atol(sData);
		int nHour=atol(sData.Mid(iSpacePos));
		int nMin=atol(sData.Mid(iDDPos1));
		int nSec=atol(sData.Mid(iDDPos2));
		dt=COleDateTime(nYear, nMonth, nDay, nHour, nMin, nSec);
	}
	return dt;
}

BOOL CDataXMLSaver::getValue(const char* szKey,COleDateTime& dt, COleDateTime dtDefault)
{
	CString sData;
	if(!getValue(szKey,sData,"",XMLAsAttribute) || sData==""){
		dt=dtDefault;
		return FALSE;
	}
	dt=Str2OleDate(sData);
	return TRUE;
}

BOOL CDataXMLSaver::getValue(const char* szKey, DWORD& iParam, DWORD iDefault)
{
	CString sData;
	if(!getValue(szKey,sData,"",XMLAsAttribute) || sData==""){
		iParam=iDefault;
		return FALSE;
	}
	iParam=atol(sData);
	return TRUE;
}

BOOL CDataXMLSaver::getValue(const char* szKey,int& iParam, int iDefault)
{
	CString sData;
	if(!getValue(szKey,sData,"",XMLAsAttribute) || sData==""){
		iParam=iDefault;
		return FALSE;
	}
	iParam=atol(sData);
	return TRUE;
}

BOOL CDataXMLSaver::getValue(const char* szKey,long& lParam, long lDefault)
{
	CString sData;
	if(!getValue(szKey,sData,"",XMLAsAttribute) || sData==""){
		lParam=lDefault;
		return FALSE;
	}
	lParam=atol(sData);
	return TRUE;
}

BOOL CDataXMLSaver::getValue(const char* szKey,double& dParam, double dDefault)
{
	CString sData;
	if(!getValue(szKey,sData,"",XMLAsAttribute) || sData==""){
		dParam=dDefault;
		return FALSE;
	}
	dParam=atof(sData);
	return TRUE;
}

CString CDataXMLSaver::getValue(const char* szKey)
{
	CString sRes;
	getValue(szKey,sRes,"");
	return sRes;
}

BOOL CDataXMLSaver::getValue(const char* szKey, CString& sParam, const char* sDefault, DWORD dwOptions)
{
	if(dwOptions & XMLAsAttribute){
		char szLBuffer[256];
		sprintf(szLBuffer,"<%s value=\"",szKey);
		char szRBuffer[256]="\"/>";
		sParam=GetInstringPart(szLBuffer,szRBuffer,m_sSource,dwOptions);
		if(sParam.GetLength()==0){
			if(!getValue(szKey,sParam)){
				sParam=sDefault;
				return FALSE;
			}
		}
	}else{
		char szLBuffer[256];
		sprintf(szLBuffer,"<%s>",szKey);
		char szRBuffer[256];
		sprintf(szRBuffer,"</%s>",szKey);
		int iFrom=0;
		sParam=GetInstringPart(szLBuffer,szRBuffer,m_sSource,dwOptions,&iFrom);
		if(iFrom==-1){
			sParam=sDefault;
			return FALSE;
		}
	}
	if(dwOptions & XMLTrimSpaces){
		sParam.TrimLeft();
		sParam.TrimRight();
	}
	return TRUE;
}


CString CDataXMLSaver::OleDate2Str(COleDateTime dt)
{
	CString sData="invalid";
	if(dt.GetStatus()==COleDateTime::valid){
		sData=dt.Format("%d.%m.%Y %H:%M:%S");
	}
	return sData;
}

BOOL CDataXMLSaver::putValue(const char* szKey,COleDateTime dt)
{
	return putValue(szKey,OleDate2Str(dt),XMLAsAttribute);
}

BOOL CDataXMLSaver::putValue(const char* szKey,DWORD iParam)
{
	CString sData;
	sData.Format("%i",iParam);
	return putValue(szKey,sData,XMLAsAttribute);
}

BOOL CDataXMLSaver::putValue(const char* szKey,int iParam)
{
	CString sData;
	sData.Format("%i",iParam);
	return putValue(szKey,sData,XMLAsAttribute);
}

BOOL CDataXMLSaver::putValue(const char* szKey,long lParam)
{
	CString sData;
	sData.Format("%i",lParam);
	return putValue(szKey,sData,XMLAsAttribute);
}

BOOL CDataXMLSaver::putValue(const char* szKey,double dParam)
{
	CString sData;
	sData.Format("%f",dParam);
	return putValue(szKey,sData,XMLAsAttribute);
}

BOOL CDataXMLSaver::putValue(const char* szKey,const char* sParam, DWORD dwOptions)
{
	m_sSource+="<";
	m_sSource+=szKey;
	if(dwOptions & XMLAsAttribute){
		m_sSource+=" value=\"";
	}else{
		m_sSource+=">";
		if(dwOptions & XMLWithStartCR){
			m_sSource+="\n";
		}
	}
	CString sValue=sParam;
	if(!(dwOptions & XMLNoConversion)){
		Str2Xml(sValue,dwOptions);
	}
	if(dwOptions & XMLTrimSpaces){
		sValue.TrimLeft();
		sValue.TrimRight();
	}
	m_sSource+=sValue;
	if(dwOptions & XMLAsAttribute){
		m_sSource+="\"/>";
	}else{
		if(dwOptions & XMLWithEndCR){
			m_sSource+="\n";
		}
		m_sSource+="</";
		m_sSource+=szKey;
		m_sSource+=">";
	}
	if(m_sFileName.GetLength()>0){
		m_sSource+="\n";
	}
	return TRUE;
}

CString CDataXMLSaver::GetInstringPart(const char* szStart, const char* szString, DWORD dwOptions, int* iFrom)
{
	int iPositionToLookFrom=0;
	if(iFrom){
		iPositionToLookFrom=*iFrom;
	}
	CString sRes=GetInstringPart(szStart, NULL, szString,iPositionToLookFrom,dwOptions);
	if(iFrom){
		*iFrom=iPositionToLookFrom;
	}
	return sRes;
}

CString CDataXMLSaver::GetInstringPartGreedly(const char* szStart, const char* szEnd, const char* szString, DWORD dwOptions, int* iFrom)
{
	int iPositionToLookFrom=0;
	if(iFrom){
		iPositionToLookFrom=*iFrom;
	}
	CString sRes=GetInstringPartGreedly(szStart, szEnd, szString,iPositionToLookFrom,dwOptions);
	if(iFrom){
		*iFrom=iPositionToLookFrom;
	}
	return sRes;
}

CString CDataXMLSaver::GetInstringPart(const char* szStart, const char* szEnd, const char* szString, DWORD dwOptions, int* iFrom)
{
	int iPositionToLookFrom=0;
	if(iFrom){
		iPositionToLookFrom=*iFrom;
	}
	CString sRes=GetInstringPart(szStart, szEnd, szString,iPositionToLookFrom,dwOptions);
	if(iFrom){
		*iFrom=iPositionToLookFrom;
	}
	return sRes;
}

BOOL CDataXMLSaver::StripInstringPart(const char* szStart, const char* szEnd, CString& szString, int* iFrom, BOOL bIgnoreCase, int iStartOffset)
{
	if(iFrom && *iFrom>=(int)strlen(szString)){
		*iFrom=-1;
		return 0;
	}
	CString szStringU;
	int iBeginFrom=iFrom?(*iFrom):0;
	int iStartPos=-1;
	if(bIgnoreCase){
		szStringU=szString;
		CString szStartU=szStart;
		szStringU.MakeUpper();
		szStartU.MakeUpper();
		iStartPos=szStringU.Find(szStartU,iBeginFrom);
	}else{
		iStartPos=szString.Find(szStart,iBeginFrom);
	}
	if(iStartPos!=-1){
		int iEndPos=-1;
		if(bIgnoreCase){
			CString szEndU=szEnd;
			szEndU.MakeUpper();
			iEndPos=(szEndU!="")?szStringU.Find(szEndU,iStartPos+iStartOffset):-1;
		}else{
			iEndPos=szEnd?szString.Find(szEnd,iStartPos+iStartOffset):-1;
		}
		if(iEndPos!=-1){
			szString=szString.Left(iStartPos+iStartOffset)+szString.Mid(iEndPos+strlen(szEnd));
		}else{
			szString=szString.Left(iStartPos+iStartOffset);
		}
	}
	return 1;
}

BOOL CDataXMLSaver::ReplaceInstringPart(const char* szStart, const char* szEnd, const char* szWith, CString& szString, int* iFrom)
{
	if(iFrom && *iFrom>=(int)strlen(szString)){
		*iFrom=-1;
		return 0;
	}
	int iBeginFrom=iFrom?(*iFrom):0;
	int iStartPos=szString.Find(szStart,iBeginFrom);
	if(iStartPos!=-1){
		int iEndPos=szEnd?szString.Find(szEnd,iStartPos):-1;
		if(iEndPos!=-1){
			szString=szString.Left(iStartPos)+szStart+szWith+szEnd+szString.Mid(iEndPos+strlen(szEnd));
		}else{
			szString=szString.Left(iStartPos)+szStart+szWith+szEnd;
		}
	}
	return 1;
}

int CountChars(CString& sSource, const char* szWhat,int iFrom,int iTo)
{
	int iRes=0;
	for(int i=iFrom;i<iTo && i<sSource.GetLength();i++){
		if(szWhat && strchr(szWhat,sSource[i])){
			iRes++;
		}
	}
	return iRes;
}

int ReverseFind(CString& sSource, const char* szWhat,int iFrom)
{
	int iPrevRes=sSource.Find(szWhat), iRes=iPrevRes, iLen=sSource.GetLength();
	if(iFrom>=0){
		// ������ ������� � iFrom
		while(iPrevRes!=-1 && iPrevRes>=iFrom && iPrevRes<iLen){
			iPrevRes=sSource.Find(szWhat,iPrevRes+1);
			if(iPrevRes!=-1 && iPrevRes>=iFrom && iPrevRes<iLen){
				iRes=iPrevRes;
			}
		}
	}else{
		// ������ �� iFrom
		iLen=-iFrom;
		iFrom=0;
		while(iPrevRes!=-1 && iPrevRes>=iFrom && iPrevRes<iLen){
			iPrevRes=sSource.Find(szWhat,iPrevRes+1);
			if(iPrevRes!=-1 && iPrevRes>=iFrom && iPrevRes<iLen){
				iRes=iPrevRes;
			}
		}
	}
	return iRes;
}

CString CDataXMLSaver::GetInstringPartGreedly(const char* szStart, const char* szEnd, const char* szString, int& iFrom, DWORD dwOptions)
{
	if(iFrom>=(int)strlen(szString)){
		iFrom=-1;
		return "";
	}
	CString sRes="";
	const char* szSearchFrom=szString+iFrom;
	char* szFrom=strstr(szString+iFrom,szStart);
	if(szFrom){
		sRes=(const char*)(szFrom+strlen(szStart));
		iFrom=(szFrom-szString)+strlen(szStart);
		const char* szSearchFromAfterStart=szString+iFrom;
	}else{
		iFrom=-1;
		return "";
	}
	if(szEnd!=NULL){
		int iEnd=ReverseFind(sRes,szEnd);
		if(iEnd!=-1){
			sRes=sRes.Left(iEnd);
			iFrom+=strlen(sRes)+strlen(szEnd);
			const char* szSearchFromEnd=szString+iFrom;
		}else{
			sRes="";
		}
	}else{
		sRes.TrimRight();
		iFrom+=strlen(sRes);
	}
	Xml2Str(sRes,dwOptions);
	return sRes;
}

CString CDataXMLSaver::GetInstringPart(const char* szStart, const char* szEnd, const char* szString, int& iFrom, DWORD dwOptions)
{
	if(iFrom>=(int)strlen(szString)){
		iFrom=-1;
		return "";
	}
	CString sRes="";
	const char* szSearchFrom=szString+iFrom;
	char* szFrom=strstr(szString+iFrom,szStart);
	if(!szFrom){
		iFrom=-1;
		return "";
	}
	iFrom=(szFrom-szString)+strlen(szStart);
	const char* szSearchFromAfterStart=szString+iFrom;
	const char* szBeginTmp=(szFrom+strlen(szStart));
	//sRes=szBeginTmp;
	if(szEnd!=NULL){
		const char* szEndPos=strstr(szBeginTmp,szEnd);
		if(szEndPos){
			sRes=CString(szBeginTmp,szEndPos-szBeginTmp);
			iFrom+=strlen(sRes)+strlen(szEnd);
			const char* szSearchFromEnd=szString+iFrom;
		}else{
			iFrom=strlen(szString);
			sRes="";
		}
	}else{
		if(dwOptions & QT_FORWARD2){
			sRes=CString(szBeginTmp,2);
		}else{
			sRes=szBeginTmp;
			sRes.TrimRight();
		}
		iFrom+=strlen(sRes);
	}
	Xml2Str(sRes,dwOptions);
	return sRes;
}

void CDataXMLSaver::Str2Xml(CString& sRes, DWORD dwFlags)
{
	if((dwFlags & XMLRNConversion) || (dwFlags & XMLJScriptConv)){
		sRes.Replace("\r\n","\n");
	}
	if(!(dwFlags & XMLNoConversion)){
		sRes.Replace("&","&amp;");
		sRes.Replace("\"","&quot;");
		if(!(dwFlags & XMLNoLTGTConv)){
			sRes.Replace("<","&lt;");
			sRes.Replace(">","&gt;");
		}
	}
	if(dwFlags & XMLJScriptConv){
		sRes.Replace("\\","&#92;");
		sRes.Replace("'","&#39;");
		sRes.Replace("\n","<br>");
	}
	return;
}

void CDataXMLSaver::Xml2Str(CString& sRes, DWORD dwFlags)
{
	if(dwFlags & XMLRNConversion){
		sRes.Replace("\n","\r\n");
	}
	if(!(dwFlags & XMLNoConversion)){
		sRes.Replace("&lt;","<");
		sRes.Replace("&gt;",">");
		sRes.Replace("&quot;","\"");
		sRes.Replace("&amp;","&");
	}
	return;
}

// ���������� � ������. ���������� ������� ������ ���������� ����� ����� �������������
BOOL ReadFileToBuffer(const char* sStartDir, LPVOID hGlobalBuffer, DWORD dwFileSize)
{
	BOOL bRes=FALSE;
	if(!hGlobalBuffer){
		return bRes;
	}
	HANDLE hFile = ::CreateFile(sStartDir, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, 0, NULL);
	if (hFile==INVALID_HANDLE_VALUE ){
		return FALSE;
	}
	DWORD dwBytesRead=0;
	if (dwFileSize > 0){
		::ReadFile(hFile, hGlobalBuffer, dwFileSize, &dwBytesRead, NULL);
	}
	if (dwFileSize != dwBytesRead){
		bRes=FALSE;
	}else{
		bRes=TRUE;
	}
	::CloseHandle(hFile);
	return bRes;
}

DWORD GetFileSize(const char* szFileName)
{
	DWORD dwFileSize=0;
	FILE* f=fopen(szFileName,"rb");
	if (f==NULL){
		return 0;
	}
	fseek(f,0,SEEK_END);
	dwFileSize = ftell(f);
	fclose(f);
	return dwFileSize;
}

BOOL ReadFile(const char* szFileName, CString& sFileContent, BOOL bAloowWPTextExtensions)
{
	if(szFileName==NULL || strlen(szFileName)==0){
		return FALSE;
	}
	DWORD dwSize=GetFileSize(szFileName);
	if(dwSize==0){
		return FALSE;
	}
	FILE* f=fopen(szFileName,"rb");
	if(f==NULL){
		return FALSE;
	}
	BOOL bSimple=1;
	char* szData = new char[dwSize+1];
	memset(szData,0,dwSize+1);
	DWORD dwReadedBytes=fread(szData,1,dwSize,f);
	if(bAloowWPTextExtensions){
		static const BYTE bszWPPrefix[]={0xFF,0xFE,'[',0,'W',0,'P',0,'C',0,'O',0,'D',0,'E',0,':'};
		if(BYTE(szData[0])==0xFF && BYTE(szData[1])==0xFE){
			if(memcmp(szData,bszWPPrefix,sizeof(bszWPPrefix)-1)==0){
				// ������!!!
				wchar_t* szUBuffer=(wchar_t*)szData;
				wchar_t* szUBCode=wcschr(szUBuffer,':');
				DWORD dwCodePage=0;
				if(szUBCode){
					dwCodePage=_wtoi(szUBCode+1);
				}
				wchar_t* wszContinue=wcschr(szUBuffer,'\n');
				if(dwCodePage>0 && wszContinue){
					wszContinue+=1;
					char* szData2 = new char[dwSize/2+1];
					memset(szData2,0,dwSize/2+1);
					DWORD dwRes=::WideCharToMultiByte(dwCodePage,0,wszContinue,-1,szData2,dwSize/2+1,0,0);
#ifdef _DEBUG
					DWORD dwErr=GetLastError();
#endif

					sFileContent=szData2;
					delete[] szData2;
					bSimple=0;
				}
			}else{
				wchar_t* szUBuffer=(wchar_t*)szData;
				USES_CONVERSION;
				sFileContent=W2A(szUBuffer);
				bSimple=0;
			}
		}
	}
	if(bSimple){
		sFileContent=szData;
	}
	delete[] szData;
	fclose(f);
	// ��������� � �������
	if(dwReadedBytes!=dwSize){
		return FALSE;
	}
	return TRUE;
}

BOOL ReadFile(const char* szFileName, wchar_t*& wszFileContent)
{
	wszFileContent=0;
	if(szFileName==NULL || strlen(szFileName)==0){
		return FALSE;
	}
	DWORD dwSize=GetFileSize(szFileName);
	if(dwSize==0){
		return FALSE;
	}
	FILE* f=fopen(szFileName,"rb");
	if(f==NULL){
		return FALSE;
	}
	wszFileContent = (wchar_t*)new char[dwSize+2];
	memset(wszFileContent,0,dwSize+2);
	DWORD dwReadedBytes=fread(wszFileContent,1,dwSize,f);
	fclose(f);
	// ��������� � �������
	if(dwReadedBytes!=dwSize){
		return FALSE;
	}
	return TRUE;
}

BOOL IsFileUnicode(const char* szFileName)
{
	if(szFileName==NULL || strlen(szFileName)==0){
		return FALSE;
	}
	DWORD dwSize=GetFileSize(szFileName);
	if(dwSize<2){
		return FALSE;
	}
	FILE* f=fopen(szFileName,"rb");
	if(f==NULL){
		return FALSE;
	}
	BYTE wszFileContent[3]={0};
	DWORD dwReadedBytes=fread(wszFileContent,1,3,f);
	fclose(f);
	return wszFileContent[0]==0xFF && wszFileContent[1]==0xFE;
}

CMapStringToString aFileToContentMap;
BOOL ClearReadFileCash()
{
	aFileToContentMap.RemoveAll();
	return TRUE;
}

BOOL ReadFileCashed(const char* szFileName, CString& sFileContent)
{
	if(aFileToContentMap.Lookup(szFileName, sFileContent)){
		return TRUE;
	}
	BOOL bRes=ReadFile(szFileName, sFileContent);
	if(bRes){
		aFileToContentMap.SetAt(szFileName, sFileContent);
	}
	return bRes;
}

/*BOOL ReadFile(const char* szFileName, CString& sFileContent)
{
	DWORD dwSize=GetFileSize(szFileName);
	if(dwSize==0){
		return FALSE;
	}
	HGLOBAL hGlob=::GlobalAlloc(GMEM_FIXED|GMEM_ZEROINIT, dwSize+1);
	if(!ReadFileToBuffer(szFileName, hGlob, dwSize)){
		return FALSE;
	}
	char* szData = (char*)hGlob;
	if(szData){
		szData[dwSize]=0;
		sFileContent=szData;
	}
	VERIFY(::GlobalFree(hGlob)==NULL);
	return TRUE;
}*/

BOOL isFileExist(const char* szFile)
{
	if(szFile==NULL || szFile[0]==0){
		return FALSE;
	}
	char szTmp[MAX_PATH]={0};
	strcpy(szTmp,szFile);
	strlwr(szTmp);
	char* szZipPos=0;
	if((szZipPos=strstr(szTmp,".zip\\"))!=0 || (szZipPos=strstr(szTmp,".wsc\\"))!=0){
		if(szZipPos){
			int iLen=(szZipPos-szTmp);
			CString sZipPath(szFile,iLen+4);
			return isFileExist(sZipPath);
		}
		return FALSE;
	}
	if(szFile[strlen(szFile)-1]=='\\'){
		CString sFile2=szFile;
		sFile2=sFile2.Left(strlen(szFile)-1);
		return isFileExist(sFile2);
	}
	if(int(GetFileAttributes(szFile))==-1){
		return FALSE;
	}
	return TRUE;
}

BOOL isFolder(const char* szFile)
{
	if(szFile==NULL || szFile[0]==0 || !isFileExist(szFile)){
		return FALSE;
	}
	if((GetFileAttributes(szFile) & FILE_ATTRIBUTE_DIRECTORY)!=0){
		return TRUE;
	}
	return FALSE;
}

CString GetPathFolder(const char* szFile)
{
	char szDisk[MAX_PATH]="",szPath[MAX_PATH]="";
	_splitpath(szFile,szDisk,szPath,NULL,NULL);
	CString sKatalog=szDisk;
	sKatalog+=szPath;
	return sKatalog;
}

BOOL PreparePathForWrite(const char* szPath)
{
	//SHPathPrepareForWrite
	CString sKatalog=GetPathFolder(szPath);
	if(!isFileExist(sKatalog)){
		return ::CreateDirectory(sKatalog,NULL);
	}
	//SHPathPrepareForWrite();
	return TRUE;
}

BOOL SaveFile(const char* sStartDir, const char* sFileContent)
{
	PreparePathForWrite(sStartDir);
	FILE* m_pFile=fopen(sStartDir,"w+b");
	if(!m_pFile){
		return FALSE;
	}
	DWORD nRead=fwrite(sFileContent,sizeof(char),strlen(sFileContent),m_pFile);
	fclose(m_pFile);
	m_pFile=NULL;
	CString sFileContentOld;
	if(aFileToContentMap.Lookup(sStartDir, sFileContentOld)){
		aFileToContentMap.RemoveKey(sStartDir);
	}
	return (nRead==strlen(sFileContent));
}

BOOL CCritSectionLock::Init(CSyncObject* pObject, BOOL bInitialLock)
{
	m_pObject=NULL;
	bLocked=bInitialLock;
	if(pObject){
		m_pObject=pObject;
		if(bInitialLock){
			bLocked=m_pObject->Lock();
		}
	}
	return TRUE;
}

CCritSectionLock::CCritSectionLock(CSyncObject& pObject, BOOL bInitialLock):CSingleLock(&pObject, bInitialLock)
{
	Init(&pObject, bInitialLock);
}

CCritSectionLock::CCritSectionLock(CSyncObject* pObject, BOOL bInitialLock):CSingleLock(pObject, bInitialLock)
{
	Init(pObject, bInitialLock);
};

CCritSectionLock::~CCritSectionLock()
{
	if(bLocked){
		m_pObject->Unlock();
	}
}

CCriticalSection cPackSection;
const int szForbiddenChars[]={'%',  '\n', '\r', '[', ']', '<', '>', '\'',  0};// ��� *
const int szFCharsTranslic[]={'%',   'N',  'R', 'A', 'B', 'C', 'D', 'E' , '0'};
const int dwFCharCount=(sizeof(szFCharsTranslic)/sizeof(int));
CString PackToString(const char* szData, DWORD dwDataSize)
{
	int iC=dwFCharCount;
	CCritSectionLock SL(&cPackSection,TRUE);
	CString sOut="";
	DWORD dwPackBufSize=DWORD(dwDataSize*1.3+15);
	HGLOBAL hGlobal=NULL;
	hGlobal = ::GlobalAlloc(GMEM_FIXED|GMEM_ZEROINIT, dwPackBufSize);
	char* szBuffer=(char*)hGlobal;
	int iBufferPosition=0,iFCPos=-1,iFC=0;
	for(DWORD i=0;i<dwDataSize;i++){
		iFCPos=-1;
		char cElem=szData[i];
		// ����������� ������ �� �������, ������� ������ ����������� ������� ������
		for(iFC=0;iFC<dwFCharCount;iFC++){
			if(szForbiddenChars[iFC]==cElem){
				iFCPos=iFC;
				break;
			}
		}
		if(iFCPos==-1){
			szBuffer[iBufferPosition++]=cElem;
		}else{
			szBuffer[iBufferPosition++]='%';
			szBuffer[iBufferPosition++]=szFCharsTranslic[iFCPos];
			// ������� ����������...
			int iZCount=1;
			if(i<dwDataSize-1 && szForbiddenChars[iFCPos]==0){
				//������ ������
				for(DWORD iCount=i+1;iCount<dwDataSize;iCount++){
					if(szData[iCount]!=szForbiddenChars[iFCPos]){
						break;
					}
					iZCount++;
				}
				if(iZCount>3){
					i+=iZCount-1;
					szBuffer[iBufferPosition-1]='*';
					szBuffer[iBufferPosition++]='0';
					szBuffer[iBufferPosition++]='0';
					CString sLen=Format("%lu*",iZCount);
					strcpy(szBuffer+iBufferPosition,sLen);
					iBufferPosition+=sLen.GetLength();
				}
			}
		}
		if(iBufferPosition>int(dwPackBufSize-5)){
			// ��������� ����� � �������� ������
			szBuffer[iBufferPosition]=0;
			sOut+=szBuffer;
			iBufferPosition=0;
		}
	}
	if(iBufferPosition!=0){// 0 �������� ��� ���������� ��� ������
		// ��������� ������� ������ � �������� ������
		szBuffer[iBufferPosition]=0;
		sOut+=szBuffer;
		iBufferPosition=0;
	}
	if(::GlobalFree(hGlobal)!=NULL){
		AfxMessageBox("Memory error!");
	}
	return sOut;
}

BOOL PackFromString(const char* szData, DWORD dwDataSize, HGLOBAL& hGlobal, long lAllocParams)
{
	CCritSectionLock SL(&cPackSection,TRUE);
	hGlobal=NULL;
	hGlobal = ::GlobalAlloc((lAllocParams==-1)?(GMEM_FIXED|GMEM_ZEROINIT):lAllocParams, dwDataSize+3);
	if (hGlobal == NULL){
		return FALSE;
	};
	int iFC=0,iFCPos=-1;
	BOOL bRes=FALSE;
	char* sFileContent = 0;
	if(lAllocParams!=-1 && (lAllocParams&GMEM_MOVEABLE)!=0){
		sFileContent = (char*)::GlobalLock(hGlobal);
	}else{
		sFileContent = (char*)hGlobal;
	}
	//
	DWORD iBufferPosition=0;
	DWORD dwRawDataLen=strlen(szData);
	for(DWORD i=0;i<dwRawDataLen;i++){
		iFCPos=-1;
		char cElem=szData[i],cElem1=szData[i+1];
		if(cElem=='%'){
			if(cElem1=='*'){
				BYTE bFiller=(char(szData[i+2]-'0')<<8)+(char(szData[i+3]-'0'));
				DWORD dwLen=atol(szData+i+4);
				i=i+2;
				while(szData[i]!='*'){
					i++;
				}
				for(DWORD k=0;k<dwLen;k++){
					sFileContent[iBufferPosition++]=bFiller;
					if(iBufferPosition>dwDataSize){
						bRes=FALSE;
						break;
					}
				}
			}else{
				for(iFC=0;iFC<dwFCharCount;iFC++){
					if(szFCharsTranslic[iFC]==cElem1){
						iFCPos=iFC;
						break;
					}
				}
				if(iFCPos!=-1){
					sFileContent[iBufferPosition++]=szForbiddenChars[iFCPos];
				}else{
					sFileContent[iBufferPosition++]=cElem1;
				}
				i++;// ����������...
			}
		}else{
			sFileContent[iBufferPosition++]=cElem;
		}
		if(iBufferPosition>dwDataSize){
			bRes=FALSE;
			break;
		}
	}
	if(iBufferPosition!=dwDataSize){
		bRes=FALSE;
	}else{
		bRes=TRUE;
	}
	//
	if(lAllocParams!=-1 && (lAllocParams&GMEM_MOVEABLE)!=0){
		::GlobalUnlock(hGlobal);
	}
	if(!bRes){
		if(::GlobalFree(hGlobal)!=NULL){
			AfxMessageBox("Memory error!");
		}
		hGlobal=NULL;
	}
	return bRes;
}

CString EscapeString(WCHAR* szString)
{
	if(!szString || *szString==0){
		return "";
	}
	CString sRes;
	WCHAR* szPos=szString;
	while(*szPos){
		sRes+=Format("%%u%04X",*szPos);
		szPos++;
	}
	return sRes;
}

CString EscapeStringUTF8(WCHAR* szString)
{
	if(!szString || *szString==0){
		return "";
	}
	CString sRes;
	USES_CONVERSION;
	WCHAR* szPos=szString;
	while(*szPos){
		WCHAR szwUTF8[2]={0};
		szwUTF8[0]=*szPos;
		szwUTF8[1]=0;
		const char* szUTF8C=W2A(szwUTF8);
		if(szUTF8C){
			if(szUTF8C[0]>'z' || szUTF8C[0]<'0' || (szUTF8C[0]>'9' && szUTF8C[0]<'A')  || (szUTF8C[0]>'Z' && szUTF8C[0]<'a')){
				sRes+=Format("%%%02X",(unsigned char)szUTF8C[0]);
			}else{
				sRes+=(unsigned char)szUTF8C[0];
			}
		}else{
			sRes+='.';
		}
		szPos++;
	}
	return sRes;
}

char UniCode(const char* szValue)
{
	char szStr[5];
	memcpy(szStr,szValue,4);
	szStr[4]=0;
	WCHAR wChar[2];
	wChar[0]=(unsigned short)strtol(szStr,NULL,16);
	wChar[1]=0;
	char cRes;
	WideCharToMultiByte(1251,0,(LPCWSTR)wChar,1,&cRes,1,NULL,NULL);
	return cRes;
}

char HexCode(const char* szRawValue)
{
	unsigned int cRes;
	char szValue[3]="12";
	szValue[0]=szRawValue[0]>='a'?(szRawValue[0]-'a'+'A'):szRawValue[0];
	szValue[1]=szRawValue[1]>='a'?(szRawValue[1]-'a'+'A'):szRawValue[1];
	if (szValue[0]<='9')
		cRes=szValue[0]-'0';
	else
		cRes=10+szValue[0]-'A';
	cRes=cRes*16;
	if (szValue[1]<='9')
		cRes+=szValue[1]-'0';
	else
		cRes+=10+szValue[1]-'A';
	return cRes;
}

CString UnescapeString(const char* szString)
{
	CString sValue="";
	int nLen=lstrlen(szString);
	const char* szNow=szString;
	while(nLen>0){
		switch (*szNow)
		{
			case '%':
				szNow++;
				nLen--;
				if (szNow[0]=='u'){
					szNow++;
					nLen--;
					char cRes=UniCode(szNow);
					if (cRes!=0){
						sValue+=cRes;
						szNow+=4;
						nLen-=4;
					};
				}else{
					// ��p������� ��� %FF
					char cCode=HexCode(szNow);
					sValue+=cCode;
					szNow+=2;
					nLen-=2;
				};
				break;
			case '+':
				sValue+=" ";
				szNow++;
				nLen--;
				break;
			default:
				sValue+=*szNow;
				szNow++;
				nLen--;
		};
	};
	// ��� ����� �������������� �� ������� � ����� ����������� ������ ������! ��� ���� ��������
	if(nLen<0)
		sValue=sValue.Left(sValue.GetLength()-1);
	return sValue;
}

CString EscapeString2(const char* szString)
{
	if(!szString || *szString==0){
		return "";
	}
	char szTmp[2]="";
	memset(szTmp,0,sizeof(szTmp));
	CString sRes;
	char const* szPos=szString;
	USES_CONVERSION;
	while(*szPos){
		unsigned char c=*szPos;
		if(c<40 || c=='\\' || c=='/' || c>126){
			sRes+=Format("%%%02X",c);
		}else{
			sRes+=(*szPos);
		}
		szPos++;
	}
	return sRes;
}

CString EscapeString(const char* szString)
{
	if(!szString || *szString==0){
		return "";
	}
	char szTmp[2]="";
	memset(szTmp,0,sizeof(szTmp));
	CString sRes;
	char const* szPos=szString;
	USES_CONVERSION;
	while(*szPos){
		unsigned char c=*szPos;
		if(c<40 || c=='\\' || c=='/' ){
			sRes+=Format("%%%02X",c);
		}else if(c>126){
			szTmp[0]=c;
			wchar_t* wc=A2W(szTmp);
			sRes+=Format("%%u%04X",*wc);
		}else{
			sRes+=(*szPos);
		}
		szPos++;
	}
	return sRes;
}

#ifdef _INCLUDE_IPV6_HOTKEYS_IN_XMLSAVER
BOOL CDataXMLSaver::getValue(const char* szKey,CIHotkey& lParam, CIHotkey lDefault)
{
	CString sData;
	if(!getValue(szKey,sData,"",XMLAsAttribute) || sData==""){
		lParam=lDefault;
		return FALSE;
	}
	lParam.InitFromSave(sData,FALSE);
	return TRUE;
}

BOOL CDataXMLSaver::putValue(const char* szKey,CIHotkey lParam)
{
	return putValue(szKey,lParam.GetForSave(FALSE),XMLAsAttribute);
}
#endif

CString GetStringHash(const char* szName)
{
	char szOut[10+1]="";
	ZeroMemory(szOut,sizeof(szOut));
	int iPos=0;
	int iHash=0;
	char const* szPos=szName;
	//-----------------------
	int i=0;
	while(*szPos){
		BYTE c=szOut[i];
		c=c<<1 | c>>7;
		c+=*szPos;
		if(c==0 && i==0){
			szOut[i]=6;
		}else{
			szOut[i]=c;
		}
		szPos++;
		i++;
		if(i>(sizeof(szOut)-2)){
			i=0;
		}
	}
	i=0;
	while(szOut[i]!=0){
		BYTE c=szOut[i];
		c='A'+c%('Z'-'A');
		szOut[i]=c;
		i++;
	}
	return szOut;
}

void ArithReplace(CString& sWho, const char* szWhat, const char* szWith)
{
	int iFrom=0;
	while(iFrom!=-1){
		iFrom=sWho.Find(szWhat);
		if(iFrom>=0){
			int iTo=iFrom+strlen(szWhat);
			BOOL bOperType=0;
			int bOperPos=0;
			while(strchr("+-0123456789",sWho[iTo])!=0){
				if(sWho[iTo]=='+'){
					bOperType=1;
					bOperPos=iTo;
				}
				if(sWho[iTo]=='-'){
					bOperType=2;
					bOperPos=iTo;
				}
				iTo++;
			}
			if(bOperType==0){
				sWho=sWho.Left(iFrom)+szWith+sWho.Mid(iTo);
			}
			if(bOperType==1){
				CString szArg=sWho.Mid(bOperPos+1,iTo-(bOperPos+1));
				sWho=sWho.Left(iFrom)+Format("%i",(atol(szWith)+atol(szArg)))+sWho.Mid(iTo);
			}
			if(bOperType==2){
				CString szArg=sWho.Mid(bOperPos+1,iTo-(bOperPos+1));
				sWho=sWho.Left(iFrom)+Format("%i",(atol(szWith)-atol(szArg)))+sWho.Mid(iTo);
			}
		}
	}
}

BOOL DeEntitize(CString& sBodyText)
{
	USES_CONVERSION;
	wchar_t szChar[10]={0};
	BOOL bAnyTagsStripped=FALSE;
	int iFrom=0;
	while(iFrom>=0 && iFrom<sBodyText.GetLength()){
		CString sTextLine=CDataXMLSaver::GetInstringPart("&#",";",sBodyText,iFrom,XMLNoConversion);
		if(iFrom<0){
			break;
		}
		sTextLine.MakeUpper();
		CString sTextToReplace=Format("&#%s;",sTextLine);
		memset(&szChar,0,sizeof(szChar));
		DWORD dwHexChar=atolx(sTextToReplace);
		((WORD*)(&szChar))[0]=LOWORD(dwHexChar);
		((WORD*)(&szChar))[1]=0;
		sTextLine=W2A(szChar);
		int iReplacedItemsCount=sBodyText.Replace(sTextToReplace,sTextLine);
		if(iReplacedItemsCount>0){
			iFrom+=strlen(sTextLine)-strlen(sTextToReplace);
			bAnyTagsStripped=TRUE;
		}else{
			iFrom+=strlen(sTextToReplace);
		}
	}
	sBodyText.Replace("&nbsp;"," ");
	sBodyText.Replace("&nbsp"," ");
	sBodyText.Replace("&lt;","<");
	sBodyText.Replace("&lt","<");
	sBodyText.Replace("&gt;",">");
	sBodyText.Replace("&gt",">");
	sBodyText.Replace("&lt;","<");
	sBodyText.Replace("&quot;","\"");
	sBodyText.Replace("&quot","\"");
	sBodyText.Replace("&amp;","&");
	sBodyText.Replace("&amp","&");
	sBodyText.Replace("&copy;","(C)");
	sBodyText.Replace("&copy","(C)");
	return bAnyTagsStripped;
}

BOOL BlockTag(const char* szTag)
{
	if(stricmp(szTag,"title")==0 || stricmp(szTag,"script")==0 || stricmp(szTag,"object")==0 || stricmp(szTag,"embed")==0 || stricmp(szTag,"style")==0){
		return TRUE;
	}
	return FALSE;
}

BOOL StripTags(CString& sBodyText)
{
	BOOL bAnyTagsStripped=FALSE;
	int iFrom=0;
	sBodyText.Replace("/>",">");
	while(sBodyText.Replace(" >",">")){};
	CDataXMLSaver::StripInstringPart("<!--","-->",sBodyText);
	while(iFrom>=0 && iFrom<sBodyText.GetLength()){
		CString sTextLine=CDataXMLSaver::GetInstringPart("<",">",sBodyText,iFrom,XMLNoConversion);
		if(iFrom<0){
			break;
		}
		CString sTextToReplace=Format("<%s>",sTextLine);
		CString sFirstTag=sTextLine.SpanExcluding(" ");
		sFirstTag.MakeLower();
		if(BlockTag(sFirstTag)){
			CString sClosingTag=Format("/%s>",sFirstTag);
			int iClosePos=sBodyText.Find(sClosingTag,iFrom);
			if(iClosePos!=-1){
				sBodyText=sBodyText.Left(iFrom-sTextLine.GetLength()-2)+sBodyText.Mid(iClosePos+sClosingTag.GetLength());
				sTextToReplace="";
				iFrom=0;
			}
		}
		if(sTextToReplace!=""){
			sTextLine="";// ������� ���!
			if(sFirstTag=="br"){
				sTextLine="\n";// ������� ������
			}else if(sFirstTag=="hr"){
				sTextLine="\n---------------\n";
			}
			int iReplacedItemsCount=sBodyText.Replace(sTextToReplace,sTextLine);
			if(iReplacedItemsCount>0){
				iFrom+=strlen(sTextLine)-strlen(sTextToReplace);
				bAnyTagsStripped=TRUE;
			}else{
				iFrom+=strlen(sTextToReplace);
			}
		}
	}
	return bAnyTagsStripped;
}

DWORD atolx(const char* szStr)
{
	if(szStr==0 || szStr[0]==0){
		return 0;
	}
	BOOL bX16=0;
	char const* szPos=szStr;
	if(strlen(szStr)>2 && szStr[0]=='0' && szStr[1]=='x'){
		bX16=1;
		szPos=szStr+2;
	}else if(strlen(szStr)>2 && szStr[0]=='&' && szStr[1]=='#'){
		if(szStr[2]=='x' || szStr[2]=='X'){
			bX16=1;
			szPos=szStr+3;
		}else{
			szPos=szStr+2;
		}
	}else if(strlen(szStr)>1 && szStr[0]=='#'){
		bX16=1;
		szPos=szStr+1;
	}
	if(bX16){
		DWORD dwRes=0;
		while(*szPos){
			DWORD dwC=0;
			char c=szPos[0];
			if(c>='0' && c<='9'){
				dwC=c-'0';
			}else if(c>='a' && c<='f'){
				dwC=10+c-'a';
			}else if(c>='A' && c<='F'){
				dwC=10+c-'A';
			}else{
				break;
			}
			dwRes*=16;
			dwRes+=dwC;
			szPos++;
		}
		return dwRes;
	}
	return atol(szPos);
}
