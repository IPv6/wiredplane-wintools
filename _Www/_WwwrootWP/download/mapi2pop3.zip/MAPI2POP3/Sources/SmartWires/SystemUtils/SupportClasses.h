// SupportClasses.h: interface for the SupportClasses class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SUPPORTCLASSES_H__FEA8409A_05E1_47E0_A213_EFD97DD01639__INCLUDED_)
#define AFX_SUPPORTCLASSES_H__FEA8409A_05E1_47E0_A213_EFD97DD01639__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "Macros.h"
#include "DataXMLSaver.h"
#include <afxmt.h>

#ifdef __AFXCMN_H__
#include "../GUIClasses/IListCtrl.h"
// �������, ���������� � ����������...
int AddComboBoxExItem(CComboBoxEx* pCombo, int iCount, const char* szText, int iIcon);
#endif
// PathMatchSpec - �������� ����� �� ���
//
#define UNIQUE_TO_SYSTEM  0
#define UNIQUE_TO_DESKTOP 1
#define UNIQUE_TO_SESSION 2
#define UNIQUE_TO_TRUSTEE 3
#define UNIQUE_TO_COMPUTER 4
//
#define W95 "Windows 95" 
#define W98 "Windows 98" 
#define WME "Windows ME" 
#define WNT4 "Windows NT 4.0" 
#define W2K "Windows 2000" 
#define WXP "Windows XP" 
#define WNE "Windows .Net" 
#define HED " Home Edition" 
#define PED " Professional Edtion" 
#define DCS " DataCenter Server" 
#define ADS " Advanced Server" 
#define ENS " Enterprise Server" 
#define WES " Web Server" 
#define SER " Server"

#define BMP_SPECPREFIX	"?\?F0LLOW1NG*IS*PACK3D*DATA!"
class CSmartLock:public CSingleLock
{
	DWORD dwStartTime;
	DWORD dwMinWaitTime;
	BOOL bLocked;
	CSyncObject* m_pObject;
	HCURSOR hCur;
public:
	void SetMinWait(DWORD dwOff){dwMinWaitTime=dwOff;};
	BOOL  Init(CSyncObject* pObject, BOOL bInitialLock = FALSE, int iCursor=0);
	CSmartLock(CSyncObject* pObject, BOOL bInitialLock = FALSE, int iCursor=0);
	CSmartLock(CSyncObject& pObject, BOOL bInitialLock = FALSE, int iCursor=0);
	~CSmartLock();
};

void AddToDebugLog(const char* szText);
#ifdef _DEBUG
#define LOG(X)	AddToDebugLog(X)
#else
#define LOG(X)
#endif

typedef CArray<const char*,const char*> CStringSet;
class CIniFileParser
{
public:
	CMapStringToOb aFiles;
	CIniFileParser(){};
	~CIniFileParser();
	void ClearCashes();
	CStringArray* loadFileString(const char* szRawFileName);
	const char* getValueRandom(const char* szFile,const char* szKey, BOOL bStripKey=TRUE);
	BOOL getAllValues(const char* szRawFileName,const char* szKey, CStringSet& aStrings, BOOL bStripKey=TRUE);
};

class CThreadKillerHolder
{
public:
	CThreadKillerHolder();
	~CThreadKillerHolder();
};

class CThreadKiller
{
	int iTCount;
	CArray<HANDLE,HANDLE> threads;
	CCriticalSection cs;
public:
	CThreadKiller();
	~CThreadKiller();
	void AddThis();
	void RemoveThis();
};

class CPairItem
{
public:
	CString sDsc;
	CString sItem;
	CString sApp;
	CPairItem(const char* szItem, const char* szDsc=NULL, const char* szApp=NULL)
	{
		sDsc=szDsc;
		sItem=szItem;
		sApp=szApp;
	};
	CPairItem()
	{
		sDsc="";
		sItem="";
		sApp="";
	}
	CPairItem& operator=(CPairItem& CopyObj)
	{
		sDsc=CopyObj.sDsc;
		sItem=CopyObj.sItem;
		sApp=CopyObj.sApp;
		return *this;
	}
};

class CSysCurBlinker
{
public:
	HCURSOR hBackup;
	HCURSOR hBackup2;
	DWORD m_dwMinTime;
	DWORD m_dwCurTime;
	CSysCurBlinker(UINT hCursorFromRes, DWORD dwMinTime);
	~CSysCurBlinker();
};

typedef struct tag_MENUBARINFO
{
    DWORD cbSize;
    RECT  rcBar;          // rect of bar, popup, item
    HMENU hMenu;          // real menu handle of bar, popup
    HWND  hwndMenu;       // hwnd of item submenu if one
    BOOL  fBarFocused:1;  // bar, popup has the focus
    BOOL  fFocused:1;     // item has the focus
} _MENUBARINFO;
typedef BOOL (WINAPI *_GetMenuBarInfo)(HWND hwnd,LONG idObject,LONG idItem,_MENUBARINFO* pmbi);

#define LANG_WRONGDLMS " \t\r\n\\.%:+-=*/!?,;()[]{}^`'"""
CString _getLngString(const char* szText,const char* szDef, const char* szDir, const char* szFile);
CString _l(const char* sText,const char* szDef=NULL);
CString _L(const char* sText,const char* szDef=NULL);
CString GetLangName(int iLangNum);
void ShowHelp(const char* szTopicName);
CString createExclusionName(LPCTSTR GUID, UINT kind = UNIQUE_TO_SYSTEM);
BOOL CheckProgrammRunState(const char* szProgName, UINT kind, bool bLeaveHandled, const char* szDesktop=NULL);
BOOL IsThisProgrammAlreadyRunning(UINT kind = UNIQUE_TO_TRUSTEE);
BOOL IsOtherProgrammAlreadyRunning(const char* szProgName, UINT kind = UNIQUE_TO_TRUSTEE);
UINT GetProgramWMMessage(const char* szProgName = NULL);
CWnd* GetAppWnd();
CString GetLastErrDsc();
CString GetCOMError(int iErr);
CIniFileParser& objFileParser();
long& GetApplicationLang();
const char* GetApplicationDir();
const char* GetApplicationName();
CString _IL(int i, const char* szPref=NULL);
//
int sgn(long l);
int rnd(int _min, int _max);
double rndDbl(double _min, double _max);
CString Format(long l);
CString Format(const char* szFormat,...);
bool PatternMatch(const char* s, const char* mask);
bool PatternMatchList(const char* s, const char* mask);
long getCharCount(const char* szString, char ch);
int ScanAndReplace(CString& sBuffer, const char* szWrongChars, char szOkChar);
int ScanAndReplace(char* szBuffer, const char* szWrongChars, char szOkChar);
void CapitalizeAndShrink(CString& sStr,const char* szDelim);
CString TrimMessage(CString sMessage, int iSize=100, int bPrepareType=0);//0-������, 1-�������� �����, 2-�������� ��������
int Validate(int iVal, int iMin, int iMax, int iDef);
BOOL MakeSafeFileName(CString& sName);
BOOL MakeSafeForURL(CString& sText);
CString GetLargestLine(CString sText, int& iLines);
CSize GetLargestLineSize(CDC* pDC, CString sText, int& iLines);
BOOL CheckMyMaskSubstr(CString sTitle, CString sTitleMask, BOOL bDef=FALSE);
void SubstMyVariables(CString& sText,BOOL bJScriptSafe=FALSE);
BOOL ParseLineForCookies(CString& sText);
CString getCookie(const char* szKey);
CMapStringToString& getMCookies();
//
void ShutDownComputer(BOOL bRestart=FALSE, int iType=2);
BOOL StartupApplicationWithWindows (BOOL bStartup);
BOOL IsStartupWithWindows();
long CtrlWidth(CWnd* wnd, UINT CtrlID);
long CtrlHeight(CWnd* wnd, UINT CtrlID);
BOOL SetClipboardText(WCHAR* szText, BOOL& bThroughGlobal, CWnd* pWndForOpen=0);
CString GetClipboardLinksAsText(BOOL bOpenCloseClip=1);
BOOL IsBMP(WCHAR* wStr);
BOOL IsBMP(const char* szStr);
WCHAR* GetClipboardText(BOOL bAndClear=FALSE, BOOL bWithBitmaps=FALSE);// ���������� ������� ������ ������� ������!
BOOL isScreenSaverActive();
BOOL isWindowStationLocked();
BOOL isScreenSaverActiveOrCLocked();
BOOL GetOSVersion(CString &WinVer, DWORD* dwMajor=NULL, long* bNT=NULL);
void AppDisplayProperties();
void AppAddRemPrograms();
void GetWindowTopParent(HWND& hWnd);
//
FILE* getFile(const char* szFName, const char* szOpenType="w", CString* sFileNameOut=NULL);
CString getFileFullName(const char* szFName, BOOL bDir=FALSE);
BOOL GetFolder(LPCTSTR szTitle,LPTSTR szPath,LPCTSTR szRoot=NULL,HWND hWndOwner=NULL);
BOOL GetFolderComputer(LPCTSTR szTitle, LPTSTR szPath, HWND hWndOwner=NULL);
CString GetUserFolder();
CString GetUserFolderRaw();
//
typedef CArray<DWORD,DWORD> aNum2IDMap;
int FindIDNumInNum2IDMap(aNum2IDMap& aM2I, DWORD dwCode);
int AppendClonedMenu(CMenu* pMenu,HMENU hMenu,long lIDOffset=0, BOOL* bOwnerDraws=NULL, aNum2IDMap* aM2I=NULL);
int AddMenuSubmenu(CMenu* pMenuTo, CMenu* pMenuFrom, const char* szString, CBitmap* pBmp=NULL, DWORD dwID=0, int iIndexTo=-1);
void AddMenuStringEx(CDWordArray* aIDsLog, CMenu* pMenu, int iID, const char* szString, CBitmap* pBmp=NULL, BOOL bCheck=FALSE, CBitmap* pBmpC=NULL, BOOL bGray=FALSE, BOOL bDisabled=FALSE, BOOL bBreakMenu=FALSE);
void AddMenuString(CMenu* pMenu, int iID, const char* szString, CBitmap* pBmp=NULL, BOOL bCheck=FALSE, CBitmap* pBmpC=NULL, BOOL bGray=FALSE, BOOL bDisabled=FALSE, BOOL bBreakMenu=FALSE);
void AddMenuString(CMenu* pMenu, int iID, const char* szString, DWORD dwFlags, CBitmap* pBmp, CBitmap* pBmpC);
void WndShake(CWnd* pWnd, DWORD dwTime);
void WndBubbleHide(CWnd* pWnd, DWORD dwSpeed);
void SendSuggestion(const char* szProg, const char* szVer, const char* szSubj="Suggestion");
BOOL PrintWindow(CWnd* pWnd, CString sText, CString sTitle="");
CString GetSizeStrFrom(DWORD dwSize, DWORD dwFrom);
#define CUT_LF_AT_THE_END(x) if(x[strlen(x)-1]==10)x[strlen(x)-1]='\0'
BOOL GetSpecialFolderPath(char* szOutPath, int nFolder);
CRect GetDesktopRect();
void SetWindowSize(CWnd* pThis, CSize sx, UINT dwControlID=0);
void SetButtonSize(CWnd* pThis, UINT dwControlID, CSize sx=CSize(60,20));
void SetTaskbarButton(HWND hWnd);
void SetButtonWidth(CWnd* pThis, UINT dwControlID, long sx);
void SetButtonHeight(CWnd* pThis, UINT dwControlID, long sy);
void SetButtonHeight(CWnd* pThis, UINT dwControlID, UINT iFrom);
void SetButtonWidth(CWnd* pThis, UINT dwControlID, UINT iFrom);
CFont* CreateFontFromStr(CString sSchValue, CString* pName=NULL, DWORD* dwBgColor=NULL, DWORD* dwTxColor=NULL, DWORD* dwAlpha=NULL, DWORD* dwAutoTrans=NULL);
CString CreateStrFromFont(CFont* pFont, CString sName, DWORD dwBgColorOut, DWORD dwTxColorOut, DWORD dwAlphaOut, DWORD dwAutoDisp=0, BOOL bInCuttedFormat=FALSE);
CString GetFontTextDsc(CString sFont);
CString GetFontTextDsc(CFont* pFont);
CDC& GetScreenDC();
BOOL CreateDirIfNotExist(const char* szFile);
CString GetDirectoryFromPath(const char* szFile);
CString GetFileFromPath(const char* szFile);
BOOL AdoptSizeToScreen(CSize& size);
long SimpleCalc(const char* szExpr);
CString trimTextForMenu(CString sText);
CString getBrowserExePath();
CString getEmailExePath();
CString getMyDocPath();
CString getMyPicPath();
CString getDesktopPath();
BOOL RunDefaultEmailClient();
DWORD WINAPI RunDefaultEmailClient_InThread(LPVOID pData);
CString MakeStandartLen(const char* szStr, int iLen, char c=' ');
void ConvertComboDataToArray(const char* szData, CStringArray& aStrings, char c='\t');
int GetIndexInArray(const char* szItem, CStringArray* pArray,BOOL bInstring=0);
CString ConvertArrayToString(CStringArray& aStrings, char c='\t');
DWORD GetRGBFromHTMLString(CString sRGB);
DWORD hexCode(const char* szRawValue);
CString GetRandomString(int iLen);
CString GetExtensionAssociatedAction(const char* szExt="html", const char* szAction="open");
BOOL ParseForShellExecute(CString sFrom, CString& sCommand, CString& sParameter, BOOL bPartialFindIsOK=FALSE);
BOOL FindFullPathToExecutable(CString& sCommand);
BOOL FindFullPathToFile(CString& sCommand);
BOOL IsBatFile(const char* szCommand);
BOOL IsConsoleApplication(const char* szFile);
CString SetTextForUpdateTipText(CString sText, int iMaxLines=30, BOOL bTrimEnters=FALSE);
CString GetReadableStringFromMinutes(DWORD dwMinutes);
BOOL IsClsidInstalled(const char* szClsid);
BOOL IsDefaultDesktop(CString* sDeskName=NULL);
void AsyncPlaySoundSys(const char* szSoundName);
CString GenerateNewId(const char* szPrefix="",const char* szPostfix="");
CString GetRegString(HKEY& hOpenedKey, const char* szKeyName, DWORD dwMaxSize=MAX_PATH);
void AttachToWindowQueue(HWND hWin, BOOL bType);
BOOL BlockInputMy(BOOL bBlock);
void ShowContextMenu(HWND hWnd, LPCTSTR pszPath, int x, int y);
void ShowFileProps(const char* szFile);
CMapStringToString& GetIniFileCash();
CString _getIni(const char* szText,const char* szDef="");
DWORD GetFileChecksum(CString m_strFilePath);
void _clearIni();
BOOL isWin98();
BOOL isWinXP();
BOOL SaveFileFromHGlob(CString& sSavingPath,CString& szLastPathToSaveTo,HGLOBAL& hGlob,DWORD dwSize, BOOL bNeedDialog=TRUE, DWORD dwOffset=0, CWnd* pParent=NULL);
size_t mymemcpy(char* pTo, const char* pFrom, size_t howMuch);
HRESULT CreateLink(LPCSTR lpszPathObj, LPCSTR lpszPathLink, LPCSTR lpszDesc, LPCSTR lpszAppParams=NULL);
int GetWindowMenuHeight(CWnd* m_pMain);
CString GetRandomName();
int GetNearestStr(const char* szFrom, int iStartFrom, const char* szParts[], int* iIndex=0);
CString& AppCommandLine();
CString AddPathExtension(const char* szPath, const char* szExt);
BOOL GetCommandLineParameter(CString sName, CString& sValue, BOOL bAllowExpandFromFile=TRUE);
CString MakeRelativePath(const char* szFullPath,const char* szBasePath);
COleDateTime StringToTime(CString sTime);
int FindSubstrWithVolatilePP(CString& sCML,const char* sPML,const char* szPrefixes,const char* szPostFixes);
CString AppendPaths(CString sPath1, CString sPath2);
BOOL DeleteFileUsingRBin(const char* sPath);
BOOL IsFileInZip(const char* szFile);
BOOL IsFileURL(const char* szFile);
BOOL IsFileHTML(const char* szFile);
CMapStringToString& GetLangTermCash();
CString GetPathPart(const char* szFile, BOOL bD,BOOL bP,BOOL bN,BOOL bE);
BOOL& IsAppStopping();
DWORD& MaxBmpSize();
#include <math.h>
class CSinusoid
{
public:
	double m_dAmp;
	double p1;
	double o2;
	double o3;
	double p4;
	double o5;
	double o6;
	double p7;
	double o8;
	double o9;
	double o10;
	double o11;
	double p12;
	double o13;
	double o14;
	double o15;
	double o16;
	double p17;
	double o18;
	double o19;
	double o20;
	double o21;
	CSinusoid(double dAmp,double dAmpRnd=1)
	{
		m_dAmp=dAmp/2.0;
		p1=rndDbl(0,dAmpRnd);
		o2=rndDbl(-dAmpRnd,dAmpRnd);
		o3=rndDbl(-dAmpRnd,dAmpRnd);
		p4=rndDbl(0,dAmpRnd);
		o5=rndDbl(-dAmpRnd,dAmpRnd);
		o6=rndDbl(-dAmpRnd,dAmpRnd);
		p7=rndDbl(0,dAmpRnd);
		o8=rndDbl(-dAmpRnd,dAmpRnd);
		o9=rndDbl(-dAmpRnd,dAmpRnd);
		o10=rndDbl(-dAmpRnd,dAmpRnd);
		o11=rndDbl(-dAmpRnd,dAmpRnd);
		p12=rndDbl(0,dAmpRnd);
		o13=rndDbl(-dAmpRnd,dAmpRnd);
		o14=rndDbl(-dAmpRnd,dAmpRnd);
		o15=rndDbl(-dAmpRnd,dAmpRnd);
		o16=rndDbl(-dAmpRnd,dAmpRnd);
		p17=rndDbl(0,dAmpRnd);
		o18=rndDbl(-dAmpRnd,dAmpRnd);
		o19=rndDbl(-dAmpRnd,dAmpRnd);
		o20=rndDbl(-dAmpRnd,dAmpRnd);
		o21=rndDbl(-dAmpRnd,dAmpRnd);
	};
	double Get1D(double t)
	{
		double dUnNormed=p1*sin(o2*t+o3)
			+p4*cos(o5*t+o6)
			+p7*sin(o8*t+o9)*sin(o10*t+o11)
			+p12*cos(o13*t+o14)*cos(o15*t+o16)
			+p17*sin(o18*t+o19)*cos(o20*t+o21);
		return (dUnNormed/(p1+p4+p7+p12+p17))*m_dAmp+m_dAmp;
	}
};

class IUITranslation
{
public:
	virtual char* uit(const char* szUIText,const char* szUITextDefault)=0;
	virtual void freestr(char* sz)=0;
};


class CI18N
{
public:
	static IUITranslation*& GetTranslationIFace()
	{
		static IUITranslation* res=0;
		return res;
	}
	
	static CString _l(const char* szWhat)
	{
		if(!GetTranslationIFace()){
			return szWhat;
		}
		char* sz=GetTranslationIFace()->uit(szWhat,szWhat);
		CString sRes=sz;
		GetTranslationIFace()->freestr(sz);
		return sRes;
	}
};

class CUITranslationImpl:public IUITranslation
{
public:
	char* uit(const char* szUIText,const char* szUITextDefault);
	void freestr(char* sz);
	static CUITranslationImpl* getInstance();
};

class CCriticalSectionGuard
{
	CCriticalSection* m_lock;
public:
	CCriticalSectionGuard(CCriticalSection* lock)
	{
		m_lock=lock;
		if(m_lock){
			m_lock->Lock();
		}
	}
	~CCriticalSectionGuard()
	{
		if(m_lock){
			m_lock->Unlock();
		}
	}
};

CString GetNextPrefixedId(CString sKey,int iIndex=-1);

BOOL IsWindowsSystemWnd(HWND hWin);
BOOL isPressed(UINT);
CString UnifyKey(CString sKey);
CString regGetBuyURL(CString publisher, CString appName, CString appVer );

class CFakeWindow
{
public:
	CWnd wnd;
	HWND hWin;
	HWND GetHwnd(){return hWin;};
	CWnd* GetWnd(){return &wnd;};
	CFakeWindow(const char* szTitle);
	~CFakeWindow();
};
void MakeJScriptSafe(CString& sFile);
CBitmap* BitmapFromIcon(HICON icon, CSize sizeIn=CSize(0,0), CBrush* br=0);
CSize GetIconSize(HICON hIcon);
CSize GetBitmapSize(CBitmap* pBmp);
CSize GetBitmapSize(HBITMAP pBmp);
void ClearBitmap(HBITMAP& hBmp);
void ClearIcon(HICON& hIcon);
HWND PlayMusicX(CString szSoundPath,BOOL bLoopSound, CString sAlias);
BOOL RegisterExtension(CString sExt, CString sDescription, CString sExeParam);
#endif // !defined(AFX_SUPPORTCLASSES_H__FEA8409A_05E1_47E0_A213_EFD97DD01639__INCLUDED_)
