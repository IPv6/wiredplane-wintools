// SupportClasses.cpp: implementation of the SupportClasses class.
//
//////////////////////////////////////////////////////////////////////
#include "stdafx.h"
#include <math.h>
#include "SupportClasses.h"


#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

CDC& GetScreenDC()
{
	static BOOL dcCreated=FALSE;
	static CDC dcScreen;
	if(!dcCreated){
		dcScreen.CreateDC("DISPLAY", NULL, NULL, NULL); 
		dcCreated=TRUE;
	}
	return dcScreen;
}

//<shlwapi.h>
typedef BOOL (STDAPICALLTYPE * _PathFindOnPath)(LPSTR pszPath, LPCSTR * ppszOtherDirs);
typedef BOOL (STDAPICALLTYPE * _PathCompactPathEx)(LPSTR pszOut, LPCSTR pszSrc, UINT cchMax, DWORD dwFlags);
typedef BOOL (STDAPICALLTYPE * _PathRelativePathTo)(LPTSTR pszPath,LPCTSTR pszFrom,DWORD dwAttrFrom,LPCTSTR pszTo,DWORD dwAttrTo);
class CShlwapi
{
public:
	HINSTANCE hDll;
	_PathFindOnPath fpFind;
	_PathCompactPathEx fpCompact;
	_PathRelativePathTo fpMakeRelPath;
	CShlwapi()
	{
		fpFind=0;
		fpCompact=0;
		hDll=LoadLibrary("shlwapi.dll");
		if(hDll){
			fpFind=(_PathFindOnPath)GetProcAddress(hDll,"PathFindOnPathA");
			fpCompact=(_PathCompactPathEx)GetProcAddress(hDll,"PathCompactPathExA");
			fpMakeRelPath=(_PathRelativePathTo)GetProcAddress(hDll,"PathRelativePathToA");
		}
	}
	~CShlwapi()
	{
		if(hDll){
			FreeLibrary(hDll);
		}
	}
};

CShlwapi& _Shlwapi()
{
	static CShlwapi obj;
	return obj;
}

BOOL CSmartLock::Init(CSyncObject* pObject, BOOL bInitialLock, int iCursor)
{
	dwMinWaitTime=0;
	dwStartTime=GetTickCount();
	hCur=NULL;
	m_pObject=NULL;
	if(iCursor>=0){
		if(iCursor){
			hCur=SetCursor(AfxGetApp()->LoadCursor(iCursor));
		}else{
			hCur=SetCursor(LoadCursor(NULL,MAKEINTRESOURCE(IDC_WAIT)));
		}
	}
	bLocked=bInitialLock;
	if(pObject){
		m_pObject=pObject;
		if(bInitialLock){
			bLocked=m_pObject->Lock();
		}
	}
	return TRUE;
}

CSmartLock::CSmartLock(CSyncObject& pObject, BOOL bInitialLock, int iCursor):CSingleLock(&pObject, bInitialLock)
{
	Init(&pObject, bInitialLock, iCursor);
}

CSmartLock::CSmartLock(CSyncObject* pObject, BOOL bInitialLock, int iCursor):CSingleLock(pObject, bInitialLock)
{
	Init(pObject, bInitialLock, iCursor);
};

CSmartLock::~CSmartLock()
{
	if(dwMinWaitTime){
		DWORD dwStopTime=GetTickCount();
		long lW=dwStopTime-dwStartTime;
		if(lW>0 && lW<long(dwMinWaitTime)){
			Sleep(dwMinWaitTime-lW);
		}
	}
	if(hCur){
		SetCursor(hCur);
	}
	if(bLocked){
		m_pObject->Unlock();
	}
}

CIniFileParser::~CIniFileParser()
{
	ClearCashes();
}

void CIniFileParser::ClearCashes()
{
	POSITION pos = aFiles.GetStartPosition();
	while( pos != NULL )
	{
		CObject* pFile;
		CString string;
		// Gets key (string) and value (pPerson)
		aFiles.GetNextAssoc( pos, string, pFile );
		CStringArray* pFileObj =(CStringArray*)pFile;
		delete pFileObj;
	}
	// RemoveAll deletes the keys
	aFiles.RemoveAll();
}

#ifdef FNF_SUPPORT
#include "FileInfo.h"
#endif
CStringArray* CIniFileParser::loadFileString(const char* szRawFileName)
{
	if(!szRawFileName){
		return NULL;
	}
	char szFile[MAX_PATH]="";
	strcpy(szFile,szRawFileName);
	CObject* pFileStrings=NULL;
	CStringArray* pFileStringsMap=NULL;
	if(!aFiles.Lookup(szFile,pFileStrings)){
		CString sContent;
		if(strchr(szFile,'*')==NULL){
			if(ReadFile(szFile,sContent,TRUE)==FALSE){
				return NULL;
			}
		}
#ifdef FNF_SUPPORT
		else{
			CString sContentTmp;
			CFileInfoArray dir;
			char szD[MAX_PATH]="",szP[MAX_PATH]="";
			char szF[MAX_PATH]="",szE[MAX_PATH]="";
			_splitpath(szFile,szD,szP,szF,szE);
			CString sFirstImagePath=szD;
			sFirstImagePath+=szP;
			strcat(szF,szE);
			dir.AddDir(sFirstImagePath,szF,TRUE,CFileInfoArray::AP_SORTBYNAME | CFileInfoArray::AP_SORTASCENDING,FALSE);
			for (int i=0;i<dir.GetSize();i++){
				CString sFile=dir[i].GetFilePath();
				ReadFile(sFile,sContentTmp,TRUE);
				sContent+=sContentTmp;
				sContent+="\r\n";
			}
		}
#endif
		CString sDelims=CDataXMLSaver::GetInstringPart(";#Delimiters:(",")",sContent);
		sDelims.MakeLower();
		CString sLinesDelims="\n";
		if(sDelims.Find("new line")!=-1){
			sLinesDelims="\n\n";
			if(sContent.Find("\r\n")!=-1){
				sLinesDelims="\r\n\r\n";
			}
		}
		sContent=sLinesDelims+sContent+sLinesDelims;
		pFileStringsMap=new CStringArray;
		int iFrom=0;
		int iFileLen=strlen(sContent);
		while(iFrom>=0){
			CString sLine=CDataXMLSaver::GetInstringPart(sLinesDelims,sLinesDelims,sContent,iFrom);
			if(sLine!=""){
				if(sLine[0]!=';'){
					sLine.TrimLeft();
					sLine.TrimRight();
					pFileStringsMap->Add(sLine);
				}
			}
			if(iFrom<=0 || iFrom>=iFileLen){
				break;
			}
			if(iFrom>0){
				iFrom-=sLinesDelims.GetLength();// ����� ������������� ��������� �������� ������ ����� ��������
			}
		}
		aFiles.SetAt(szFile,(CObject*)pFileStringsMap);
	}else{
		pFileStringsMap=(CStringArray*)pFileStrings;
	}
	if(pFileStringsMap==NULL || pFileStringsMap->GetSize()==0){
		return NULL;
	}
	return pFileStringsMap;

}

BOOL CIniFileParser::getAllValues(const char* szRawFileName,const char* szKey, CStringSet& aStrings, BOOL bStripKey)
{
	CStringArray* pFileStringsMap=loadFileString(szRawFileName);
	if(!pFileStringsMap){
		return FALSE;
	}
	int iFileStringsSize=pFileStringsMap->GetSize();
	CString* pStringsFromFile=pFileStringsMap->GetData();
	if(!pStringsFromFile){
		return FALSE;
	}
	aStrings.RemoveAll();
	int iLen=0;
	if(szKey){
		iLen=strlen(szKey);
	}
	for(int i=0;i<iFileStringsSize;i++){
		const char* sLine=pStringsFromFile[i];
		const char* szNewString=(bStripKey && iLen>0)?(sLine+iLen):sLine;
		if(iLen==0){
			aStrings.Add(szNewString);
			continue;
		}
		if(strchr(szKey,'*')==NULL){
			if(memicmp(sLine,szKey,iLen)==0){
				aStrings.Add(szNewString);
			}
		}else{
			if(PatternMatch(sLine,CString(szKey)+"*")){
				aStrings.Add(szNewString);
			}
		}
	}
	return TRUE;
}

const char* CIniFileParser::getValueRandom(const char* szRawFileName,const char* szKey, BOOL bStripKey)
{
	if(!szRawFileName || !szKey){
		return "";
	}
	// ����������� �� ��������
	CStringSet aStrings;
	if(!getAllValues(szRawFileName, szKey, aStrings, bStripKey)){
		return "";
	}
	int iLen=aStrings.GetSize();
	if(iLen==0){
		return "";
	}
	if(iLen==1){
		return aStrings[0];
	}
	int iLineIndex=rnd(0,iLen-1);
	return aStrings[iLineIndex];
}

CIniFileParser& objFileParser()
{
	static CIniFileParser oFileParser;
	return oFileParser;
}

long& GetApplicationLang()
{
	static long dwInterfaceLang=0;// ����, 0- ����������, 1-�������
	return dwInterfaceLang;
}

const char* GetApplicationDir()
{
	static char appDir[MAX_PATH]="";
	if(appDir[0]!=0){
		return appDir;
	}
	char szCurrentExeFile[MAX_PATH]="";
	GetModuleFileName(NULL, szCurrentExeFile, sizeof(szCurrentExeFile));
	char szDrive[MAX_PATH],szDir[MAX_PATH];
	_splitpath(szCurrentExeFile, szDrive, szDir, NULL, NULL);
	strcpy(appDir,szDrive);
	strcat(appDir,szDir);
	return appDir;
}

const char* GetApplicationName()
{
	static char appName[MAX_PATH]="";
	if(appName[0]!=0){
		return appName;
	}
	char szCurrentExeFile[MAX_PATH]="";
	/*int iParsedParams=0;
	USES_CONVERSION;
	LPCWSTR szEmp=A2W("");
	LPWSTR* szwExeFile=CommandLineToArgvW(szEmp,&iParsedParams);
	if(szwExeFile && *szwExeFile!=NULL){
		strcpy(szCurrentExeFile,W2A(*szwExeFile));
	}else*/
	CString sCommandLine=GetCommandLine(),sExeFile,sParams;
	if(ParseForShellExecute(sCommandLine,sExeFile,sParams)){
		strcpy(szCurrentExeFile,sExeFile);
	}else{
		GetModuleFileName(NULL, szCurrentExeFile, sizeof(szCurrentExeFile));
	}
	char szDrive[MAX_PATH],szDir[MAX_PATH], szExt[MAX_PATH];
	_splitpath(szCurrentExeFile, szDrive, szDir, appName, szExt);
	return appName;
}

CMapStringToString& GetIniFileCash()
{
	static CMapStringToString objIniFile;
	static BOOL bHashSizeSet=0;
	if(bHashSizeSet==0){
		objIniFile.InitHashTable(211);
		bHashSizeSet=1;
	}
	return objIniFile;
}

void _clearIni()
{
	GetIniFileCash().RemoveAll();
	objFileParser().ClearCashes();
	char szLastFile[MAX_PATH]="";
	sprintf(szLastFile,"%sconfig.ini",GetApplicationDir());
	DeleteFile(szLastFile);
	return;
}

CString _getIni(const char* szText,const char* szDef)
{
	if(szText==NULL || *szText==0){
		return "";
	}
	CString sKey=szText;
	sKey+="=";
	CString sCashKey,sValue;
	// ������� � ���
	sCashKey=sKey;
	if(GetIniFileCash().Lookup(sCashKey,sValue)){
		return sValue;
	}
	char szLastFile[MAX_PATH]="";
	sprintf(szLastFile,"%sconfig.ini",GetApplicationDir());
	sValue=objFileParser().getValueRandom(szLastFile,sKey,TRUE);
	if(((const char*)sValue)[0]==0){
		CString sSetValue=szDef;
		if(!szDef){
			sSetValue=szText;
		}
		sValue=sSetValue;
		FILE* m_logFile=getFile(szLastFile,"a+");
		if(m_logFile!=NULL){
			fprintf(m_logFile,"%s%s\n",sKey,sSetValue);
			fclose(m_logFile);
		}
	}
	GetIniFileCash().SetAt(sCashKey,sValue);
	return sValue;
}

/* ������� ����� �� 700
211 223 227 229 233 239 241 251 257 263 269 271 277 281 283 293 
307 311 313 317 331 337 347 349 353 359 367 373 379 383 389 397 
401 409 419 421 431 433 439 443 449 457 461 463 467 479 487 491 499 
503 509 521 523 541 547 557 563 569 571 577 587 593 599 
601 607 613 617 619 631 641 643 647 653 659 661 673 677 683 691
*/
CMapStringToString& GetLangTermCash()
{
	static CMapStringToString objLanguageTermins;
	static BOOL bHashSizeSet=0;
	if(bHashSizeSet==0){
		objLanguageTermins.InitHashTable(401);
		bHashSizeSet=1;
	}
	return objLanguageTermins;
}

#define MAXKLEN		30
#define NEWLINE		"<br>"
#define NEWLINE2	"<brr>"
CString _getLngString(const char* szText,const char* szDef, const char* szDir, const char* szFile)
{
#ifdef NO_AUTOSAVESTRINGS
#pragma message("Auto save missed strings: disabled")
	return szText;
#endif
	
	if(szText==NULL || *szText==0){
		return "";
	}
	CString sKey=szText;
	CapitalizeAndShrink(sKey,LANG_WRONGDLMS);
	if(sKey.GetLength()>MAXKLEN){
		sKey=sKey.Left(MAXKLEN-11)+"_"+GetStringHash(sKey);
	}
	sKey+="=";
	CString sCashKey,sValue;
	// ������� � ���
	sCashKey=Format("%s%i%s",szFile,GetApplicationLang(),sKey);
	if(GetLangTermCash().Lookup(sCashKey,sValue)){
		return sValue;
	}
	char szLastFile[MAX_PATH]="";
	sprintf(szLastFile,"%s%s_l%i.lng",szDir,szFile,GetApplicationLang());
#ifdef FNF_SUPPORT_LNG_AST
	char szLastFile2[MAX_PATH]="";
	sprintf(szLastFile2,"%s%s*_l%i.lng",szDir,szFile,GetApplicationLang());
	sValue=objFileParser().getValueRandom(szLastFile2,sKey,TRUE);
#else
	sValue=objFileParser().getValueRandom(szLastFile,sKey,TRUE);
#endif
	if(((const char*)sValue)[0]==0){
		// ��������� ��� � ���� ����������� ��������
		BOOL bGetted=0;
		static CCriticalSection cs;
		CSmartLock lngl(cs,TRUE);
		/*if(strlen(szText)>MAXKLEN){
			// ���� ������ ������� ���
			CString sOldKey=szText;
			CapitalizeAndShrink(sOldKey,LANG_WRONGDLMS);
			sOldKey+="=";
			sValue=objFileParser().getValueRandom(szLastFile,sOldKey,TRUE);
			if(((const char*)sValue)[0]!=0){//Found ok!
				// ��������� ������������ ����
				CString sLangContent;
				ReadFile(getFileFullName(szLastFile),sLangContent);
				int iReplaced=sLangContent.Replace(sOldKey,sKey);
				if(iReplaced>0){
					SaveFile(getFileFullName(szLastFile),sLangContent);
				}
				bGetted=1;
			}
		}
		*/
		if(!IsFileUnicode(szLastFile)){// ����������� ����������� ������
			CString sSetValue=szDef;
			if(!szDef){
				sSetValue=szText;
			}
			sValue=sSetValue;
			sSetValue.Replace("\r\n",NEWLINE2);
			sSetValue.Replace("\n",NEWLINE);
			sSetValue.Replace("\r","");
			FILE* m_logFile=getFile(szLastFile,"a+");
			if(m_logFile!=NULL){
				fprintf(m_logFile,"\n%s%s",sKey,sSetValue);
				fclose(m_logFile);
			}
		}
	}
	sValue.Replace(NEWLINE,"\n");
	sValue.Replace(NEWLINE2,"\r\n");
	GetLangTermCash().SetAt(sCashKey,sValue);
	return sValue;
}

CString _l(const char* szText,const char* szDef)
{
	return _getLngString(szText,szDef,GetApplicationDir(),GetApplicationName());
}

CString _L(const char* szText,const char* szDef)
{
	return _getLngString(szText,szDef,GetApplicationDir(),GetApplicationName());
}

CString GetLangName(int iLangNum)
{
	CString sLangTermKey=Format("LangName%i",iLangNum);
	CString sLangName=_l(sLangTermKey);
	if(strcmp(sLangName,sLangTermKey)==0){
		// �� ���������
		if(iLangNum==0){
			sLangName="English";
		}
	}
	return sLangName;
}

int sgn(long l)
{
	if(l==0)
		return 0;
	if(l>0)
		return 1;
	return -1;
}

DWORD dwMyRndSeed=0;
#define MYRAND_MAX 0x7fff
DWORD myrand()
{
	return( ((dwMyRndSeed = dwMyRndSeed * 214013L + 2531011L) >> 16) & MYRAND_MAX );
}

int randEx()
{
	static DWORD iFirstValue=0;
	if(iFirstValue==0){
		iFirstValue=1;
		dwMyRndSeed=(unsigned)(time(NULL)-GetCurrentThreadId()*7);
	}
	return myrand();
}

int randEx_old()
{
	static int iFirstValue=0;
	if(iFirstValue==0){
		srand(time(NULL));
		iFirstValue=rand();
	}
	int iResult=rand();
	if(iFirstValue==iResult){
		srand(time(NULL)+::GetCurrentThreadId()+iFirstValue);
		iResult=rand();
	}
	return iResult;
}

// ��������� ����� ������� �������
int rnd(int _min, int _max)
{
	int iRndVal=randEx();
	double d1=double(iRndVal)/double(MYRAND_MAX+1);
	int iRes = _min + (int)floor(double(_max - _min + 1)*d1);// RAND_MAX+1 - ����� ������ �������, � floor �������� � ������� �������
	return iRes;
}

double rndDbl(double _min, double _max)
{
	double d=double(randEx());
	return _min + d / MYRAND_MAX * (_max - _min);
}

CString Format(const char* szFormat,...)
{
	va_list vaList;
	va_start(vaList,szFormat);
	CString sBuffer;
	sBuffer.FormatV(szFormat,vaList);
	va_end (vaList);
	return sBuffer;
}

CString Format(long l)
{
	return Format("%i",l);
}

bool PatternMatch(const char* s, const char* mask)
{
	const   char* cp=0;
	const   char* mp=0;
	for (; *s&&*mask!='*'; mask++,s++){
		if (*mask!=*s && *mask!='?'){
			return 0;
		}
	}
	for (;;) {
		if (!*s){
			while (*mask=='*'){
				mask++;
			}
			return !*mask;
		}
		if (*mask=='*'){ 
			if (!*++mask){
				return 1;
			}
			mp=mask;
			cp=s+1;
			continue;
		}
		if (*mask==*s||*mask=='?'){
			mask++;
			s++;
			continue;
		}
		mask=mp;
		s=cp++;
	}
	return true;
}

bool PatternMatchList(const char* s, const char* mask)
{
	CString sList=mask;
	if(sList==""){
		return true;
	}
	int iC=sList.Replace(";","\t");
	if(iC==0 && sList.Find("*")==-1){
		sList=sList+"*";
	}
	CStringArray sAppList;
	ConvertComboDataToArray(sList,sAppList);
	for(int i=0;i<sAppList.GetSize();i++){
		if(PatternMatch(s,sAppList[i])){
			return true;
		}
	}
	return false;
}

long getCharCount(const char* szString, char ch)
{
	char const* szPos=szString;
	long lOut=0;
	while(*szPos!=0){
		if(*szPos==ch){
			lOut++;
		}
		szPos++;
	}
	return lOut;
}

int ScanAndReplace(CString& sBuffer, const char* szWrongChars, char szOkChar)
{
	char* szBuffer=sBuffer.GetBuffer(1);
	int iRes=ScanAndReplace(szBuffer, szWrongChars, szOkChar);
	sBuffer.ReleaseBuffer();
	return iRes;
}

int ScanAndReplace(char* szBuffer, const char* szWrongChars, char szOkChar)
{
	int iRes=0;
	char* szPos=szBuffer;
	while(*szPos){
		if(strchr(szWrongChars,*szPos)!=NULL){
			*szPos=szOkChar;
			iRes++;
		}
		szPos++;
	}
	return iRes;
}

void CapitalizeAndShrink(CString& sStr,const char* szDelim)
{
	CString sRes="",sTerm;
	while(sStr!=""){
		sTerm=sStr.SpanExcluding(szDelim);
		sStr=sStr.Mid(strlen(sTerm));
		sStr.TrimLeft(szDelim);
		if(sTerm!=""){
			sTerm.MakeLower();
			char szSmalBuf[2]=" ";
			szSmalBuf[0]=sTerm[0];
			strupr(szSmalBuf);
			sTerm.SetAt(0,szSmalBuf[0]);
			sRes+=sTerm;
		}
	}
	sStr=sRes;
}

CString GetCOMError(int iErr)
{
	CString sOut;
	char szBuffer[1024]="";
	::FormatMessage(FORMAT_MESSAGE_FROM_SYSTEM,NULL,iErr,0,szBuffer,sizeof(szBuffer),NULL);
	ScanAndReplace(szBuffer,"\t\r\n",' ');
	sOut.Format("%s (0x%X)",szBuffer,iErr);
	return sOut;
}

CString GetLastErrDsc()
{
	return GetCOMError(GetLastError());
}

void ConcateDir(CString& sDir,const char* szAdded)
{
	if (sDir.GetLength()>0 && sDir[sDir.GetLength()-1]!='\\')
		sDir+="\\";
	sDir+=szAdded;
	return;
};

CString GetUserFolderRaw()
{
	static char szUserFolder[MAX_PATH]="";
	if(szUserFolder[0]!=0){
		return szUserFolder;
	}
	CString sFolder;
	char szFolderBuffer[MAX_PATH]="";
	GetSpecialFolderPath(szFolderBuffer,CSIDL_APPDATA);
	if(szFolderBuffer[0]==0){
		strcpy(szFolderBuffer,GetApplicationDir());
	}
	sFolder=szFolderBuffer;
	ConcateDir(sFolder,GetApplicationName());
	if(int(GetFileAttributes(sFolder))==-1){
		CreateDirectory(sFolder,NULL);
	}
	sFolder+="\\";
	strcpy(szUserFolder,sFolder);
	return sFolder;
}

CString GetUserFolder()
{
	static char szUserFolder[MAX_PATH]="";
	if(szUserFolder[0]!=0){
		return szUserFolder;
	}
	CString sFolder;
	if(GetCommandLineParameter("ul",sFolder)){
		if(sFolder==""){
			sFolder=GetApplicationDir();
			ConcateDir(sFolder,"UserData");
		}
	}else{
		sFolder=CString(GetApplicationDir())+"Profile";
		if(!isFileExist(sFolder)){
			char szFolderBuffer[MAX_PATH]="";
			GetSpecialFolderPath(szFolderBuffer,CSIDL_APPDATA);
			if(szFolderBuffer[0]==0){
				strcpy(szFolderBuffer,GetApplicationDir());
			}
			sFolder=szFolderBuffer;
			ConcateDir(sFolder,GetApplicationName());
		}
	}
	if(int(GetFileAttributes(sFolder))==-1){
		CreateDirectory(sFolder,NULL);
	}
	sFolder+="\\";
	strcpy(szUserFolder,sFolder);
	return sFolder;
}

CString getFileFullName(const char* szFName, BOOL bDir)
{
	CString sFileToOpen=szFName;
	char szFolderBuffer[MAX_PATH+1]="";
	if(strlen(szFName)>3 && (szFName[0]!='\\' && !(szFName[1]==':' && szFName[2]=='\\'))){
		// ������������� ����
		sFileToOpen=GetUserFolder()+szFName;
	}else{
		// ���������� ����
		if(szFName[0]=='\\'){
			sFileToOpen=GetApplicationDir();
			sFileToOpen+="UserData\\";
			sFileToOpen+=szFName;
		}else{
			sFileToOpen=szFName;
		}
	}
	if(bDir==TRUE){
		if(sFileToOpen.Right(1)!="\\"){
			// �������, ��������� �� �� ��� �����
			int iDotPos=sFileToOpen.ReverseFind('.');
			int iSplashPos=sFileToOpen.ReverseFind('\\');
			if(iDotPos!=-1 && iDotPos>iSplashPos){
				char szDisk[MAX_PATH]="C://", szPath[MAX_PATH]="TEMP//";
				_splitpath(sFileToOpen, szDisk, szPath, NULL, NULL);
				sFileToOpen=szDisk;
				sFileToOpen+=szPath;
			}else{
				sFileToOpen+="\\";
			}
		}
	}
	return sFileToOpen;
}

FILE* getFile(const char* szFName, const char* szOpenType, CString* sFileNameOut)
{
	CString sFileToOpen=getFileFullName(szFName);
	if(sFileNameOut){
		*sFileNameOut=sFileToOpen;
	}
	FILE* pFile=fopen(sFileToOpen,szOpenType);
	return pFile;
}

// CreateLink - uses the Shell's IShellLink and IPersistFile interfaces 
//   to create and store a shortcut to the specified object. 
// Returns the result of calling the member functions of the interfaces. 
// lpszPathObj - address of a buffer containing the path of the object. 
// lpszPathLink - address of a buffer containing the path where the 
//   Shell link is to be stored. 
// lpszDesc - address of a buffer containing the description of the 
//   Shell link. 

HRESULT CreateLink(LPCSTR lpszPathObj, LPCSTR lpszPathLink, LPCSTR lpszDesc, LPCSTR lpszAppParams)
{
    HRESULT hres; 
    IShellLink* psl; 
	
	// Get a pointer to the IShellLink interface. 
	hres = CoCreateInstance(CLSID_ShellLink, NULL, CLSCTX_INPROC_SERVER, IID_IShellLink, (LPVOID *) &psl);
	if (SUCCEEDED(hres)) { 
		IPersistFile* ppf; 
		
        // Set the path to the shortcut target and add the 
        // description. 
        psl->SetPath(lpszPathObj); 
        psl->SetDescription(lpszDesc); 
		if(lpszAppParams && strlen(lpszAppParams)>0){
			psl->SetArguments(lpszAppParams);
		}
		// Query IShellLink for the IPersistFile interface for saving the 
		// shortcut in persistent storage. 
		hres = psl->QueryInterface(IID_IPersistFile, (LPVOID*)&ppf); 
		
		if (SUCCEEDED(hres)) {
            WCHAR wsz[MAX_PATH]; 
			
			// Ensure that the string is Unicode. 
			MultiByteToWideChar(CP_ACP, 0, lpszPathLink, -1, 
				wsz, MAX_PATH); 
			
			// Save the link by calling IPersistFile::Save. 
			hres = ppf->Save(wsz, TRUE); 
			ppf->Release(); 
		} 
		psl->Release(); 
	}
	return hres; 
}

// 0/1 - ���������� ����� ������ ��� ����� �����������
#define STARTUP_THROW_REGISTRY	0
BOOL IsStartupWithWindows()
{
#if STARTUP_THROW_REGISTRY != 1
	// ����� �����
	char szFolderBuffer[MAX_PATH]="";
	strcpy(szFolderBuffer,GetApplicationName());
	GetSpecialFolderPath(szFolderBuffer,CSIDL_STARTUP);
	CString sFilePath=szFolderBuffer;
	sFilePath+="\\";
	sFilePath+=CString(GetApplicationName())+".lnk";
	FILE* m_pFile=fopen(sFilePath,"r");
	if(!m_pFile){
		return FALSE;
	}
	fclose(m_pFile);
	return TRUE;
#else
	// ����� ������
	char szPath[MAX_PATH];
	GetModuleFileName(NULL, szPath, sizeof(szPath));
	char szName[MAX_PATH];
	_splitpath (szPath, NULL, NULL, szName, NULL);
	char szTemp[MAX_PATH];
	DWORD lSize = MAX_PATH,dwType=0;
	CRegKey key;
	key.Open (HKEY_CURRENT_USER, "Software\\Microsoft\\Windows\\CurrentVersion\\Run");//if (key.QueryValue (szTemp, NULL, szName, &lSize ) != ERROR_SUCCESS) return FALSE;
	if(RegQueryValueEx(key.m_hKey,szName,NULL, &dwType,(LPBYTE)szTemp, &lSize)!= ERROR_SUCCESS)
		return FALSE;
	return TRUE;
#endif
}

BOOL StartupApplicationWithWindows(BOOL bStartup)
{
	char szPath[MAX_PATH]="";
	GetModuleFileName(NULL, szPath, sizeof(szPath));
#if STARTUP_THROW_REGISTRY != 1
	char szFolderBuffer[MAX_PATH]="";
	strcpy(szFolderBuffer,GetApplicationName());
	GetSpecialFolderPath(szFolderBuffer,CSIDL_STARTUP);
	CString sFilePath=szFolderBuffer;
	sFilePath+="\\";
	sFilePath+=CString(GetApplicationName())+".lnk";
	if(!bStartup){
		return DeleteFile(sFilePath);
	}else{
		return (CreateLink(szPath, sFilePath, GetApplicationName())==S_OK);
	}
#else
	char szName[MAX_PATH];
	_splitpath (szPath, NULL, NULL, szName, NULL);

	CRegKey key;
	key.Open (HKEY_CURRENT_USER, "Software\\Microsoft\\Windows\\CurrentVersion\\Run");
	if(key!=NULL){
		if (bStartup){
			DWORD dwType=REG_SZ,dwSize=0;
			if(RegSetValueEx(key.m_hKey,szName,0,REG_SZ,(BYTE*)szPath,lstrlen(szPath)+1)!= ERROR_SUCCESS)
				return 0;
			/*if(key.SetValue(szPath,REG_SZ, szName, strlen(szName)) != ERROR_SUCCESS)
				return FALSE;*/
		}else{
			if(key.DeleteValue(szName) != ERROR_SUCCESS)
				return FALSE;
		}
	}
	return TRUE;
#endif
}

int Validate(int iVal, int iMin, int iMax, int iDef)
{
	if(iVal>iMax || iVal<iMin)
		return iDef;
	else
		return iVal;
}

BOOL GetOSVersion(CString &WinVer, DWORD* dwMajor, long* bNT) 
{ 
	// �������� ����������
	static CString _sWinVer="";
	static long _dwMajor=-1;
	static long _bNT=-1;
	static long _bVersionGathered=-1;
	if(_bVersionGathered!=-1){
		WinVer=_sWinVer;
		if(dwMajor){
			*dwMajor=_dwMajor;
		}
		if(bNT){
			*bNT=_bNT;
		}
		return TRUE;
	}
	//----------------------
	OSVERSIONINFOEX winfo; 
	
	ZeroMemory(&winfo, sizeof(OSVERSIONINFOEX)); 
	winfo.dwOSVersionInfoSize = sizeof(OSVERSIONINFOEX); 
	
	if (GetVersionEx((OSVERSIONINFO *)&winfo) == 0) 
	{ 
		//Get Windows version failed 
		return FALSE; 
	} 
	if (winfo.dwPlatformId == VER_PLATFORM_WIN32_NT) 
	{
		/*if (winfo.wProductType == VER_NT_WORKSTATION)//Workingstation version 
		{ 
			if (winfo.dwMajorVersion >= 5) 
			{ 
				if (winfo.dwMinorVersion == 1) 
				{ 
					WinVer = WXP; //Windows XP 
					
					if (winfo.wSuiteMask & VER_SUITE_PERSONAL) 
						WinVer += HED; //Windows XP Home Edtion 
					else 
						WinVer += PED; //Windows XP Professional Edtion 
					
				} 
				else 
					WinVer = W2K; //Windows 2000 Professtiona 
			} 
			else 
				WinVer = WNT4; //Windows NT 4.0 Workstation 
		} 
		else if (winfo.wProductType == VER_NT_SERVER)*/
		{ 
			if (winfo.dwMajorVersion >= 5) 
			{ 
				if (winfo.dwMinorVersion == 1) 
					WinVer = WXP; //Windows XP 
				else 
					if (winfo.dwMinorVersion == 2) 
						WinVer = WNE; //Windows .Net 
					else 
						WinVer = W2K; //Windows 2000 
					
					/*if(winfo.wSuiteMask & VER_SUITE_DATACENTER ) 
						WinVer += DCS; //DataCenter Server 
					else if (winfo.wSuiteMask & VER_SUITE_ENTERPRISE ) 
					{ 
						if (winfo.dwMajorVersion == 4 ) 
							WinVer += ADS; //Advanced Server 
						else 
							WinVer += ENS; //Enterprise Server 
					} 
					else if (winfo.wSuiteMask == VER_SUITE_BLADE ) 
						WinVer += WES; //Web Server 
					else 
						WinVer += SER; //Server */
			} 
			else 
			{ 
				WinVer = WNT4; //Window NT 4.0 
				WinVer += SER; //Server 
			} 
		} 
	}
	else 
	{
		if (winfo.dwPlatformId == VER_PLATFORM_WIN32_WINDOWS) 
		{ 
			if(winfo.dwMinorVersion < 10) 
				WinVer = W95; //Windows 95 
			else if (winfo.dwMinorVersion < 90) 
				WinVer = W98; //Windows 98 
			else 
				WinVer = WME; //Windows ME 
		} 
	} 
	if(dwMajor){
		*dwMajor=winfo.dwMajorVersion;
	}
	//---------
	_bVersionGathered=1;
	_sWinVer=WinVer;
	_dwMajor=winfo.dwMajorVersion;
	_bNT=(winfo.dwPlatformId==VER_PLATFORM_WIN32_NT);
	return GetOSVersion(WinVer, dwMajor, bNT);
}

BOOL MakeSafeFileName(CString& sName)
{
	ScanAndReplace(sName, "\\\"\'\t\r\n%:+!?/\\()<>*~`", '_');
	sName.TrimLeft();
	sName.TrimRight();
	sName.TrimLeft("_");
	sName.TrimRight("_");
	return TRUE;
}

long CtrlWidth(CWnd* wnd, UINT CtrlID)
{
	if(!wnd){
		return 0;
	}
	if(CtrlID==0){
		// ������� ������������ �������
		CRect rect1;
		wnd->GetWindowRect(rect1);
		CRect rect2;
		wnd->GetClientRect(rect2);
		return rect1.Width()-rect2.Width();
	}
	CRect rect;
	CWnd* ctrlWnd=wnd->GetDlgItem(CtrlID);
	if(!ctrlWnd){
		return 0;
	}
	ctrlWnd->GetWindowRect(rect);
	return rect.Width();
}

long CtrlHeight(CWnd* wnd, UINT CtrlID)
{
	if(!wnd){
		return 0;
	}
	if(CtrlID==0){
		// ������� ������������ �������
		CRect rect1;
		wnd->GetWindowRect(rect1);
		CRect rect2;
		wnd->GetClientRect(rect2);
		return rect1.Height()-rect2.Height();
	}
	CRect rect;
	CWnd* ctrlWnd=wnd->GetDlgItem(CtrlID);
	if(!ctrlWnd){
		return 0;
	}
	ctrlWnd->GetWindowRect(rect);
	return rect.Height();
}

CString TrimMessage(CString sMessage, int iSize, int bPrepare)
{
	BOOL bNeedPostProcessing=(bPrepare==0)?FALSE:TRUE;
	CString sOut;
	int iStopPrefix=sMessage.Find(BMP_SPECPREFIX);
	if(iStopPrefix!=-1){
		sOut=sMessage.Left(iStopPrefix);
	}else{
		sOut=sMessage;
	}
	int iLen=sOut.GetLength();
	if(iLen>iSize){
		if(bPrepare==2){
			sOut=sMessage.Left(iSize/2-3)+"..."+sMessage.Right(iSize/2);
		}else if(bPrepare==3){
			char szPath[MAX_PATH]="";
			if(_Shlwapi().fpCompact){
				_Shlwapi().fpCompact(szPath,sMessage,iSize,0);
				sOut=szPath;
			}else{
				bPrepare=1;
			}
		}else if(bPrepare==4){
			static CString sDelimiters=" ,./\r\n\\-=+";
			int iPos=iSize*int(iLen/iSize);
			bNeedPostProcessing=FALSE;
			while(iPos>=iSize){
				int iInsertPos=iPos;
				while(iPos-iInsertPos<iSize/2 && sDelimiters.Find(sOut[iInsertPos-1])==-1){
					iInsertPos--;
				}
				sOut.Insert(iInsertPos,'\n');
				iPos-=iSize;
			}
		}else if(bPrepare==5){
			sOut=CString((iLen>iSize?"...":""))+sMessage.Right(iSize);
		}
		if(bPrepare<2){
			sOut=sMessage.Left(iSize)+(iLen>iSize?"...":"");
		}
	}
	if(bNeedPostProcessing){
		sOut.Replace("\t"," ");
		sOut.Replace("\n"," ");
		sOut.Replace("\r"," ");
		sOut.TrimLeft();
		sOut.TrimRight();
	}
	return sOut;
}

// �������, ������� ����� �������� �� ������ �������
CWnd* GetAppWnd()
{
	static CWnd* pMainWnd=NULL;
	if(pMainWnd==NULL){
		CWinApp* pApp=AfxGetApp();
		if(pApp){
			pMainWnd=pApp->m_pMainWnd;
		}else{
			pMainWnd=AfxGetMainWnd();
		}
	}
	return pMainWnd;
}

#ifdef _DEBUG
CString& GetGlobalClipTextD()
{
	static CString sTest;
	return sTest;
}
#endif

HGLOBAL& GetGlobalClipText(BOOL bWide)
{
	static HGLOBAL hGlobalClipTextA=NULL;
	static HGLOBAL hGlobalClipTextW=NULL;
	if(bWide){
		return hGlobalClipTextW;
	}
	return hGlobalClipTextA;
}

BOOL SetClipboardText(WCHAR* wszText, BOOL& bThroughGlobal, CWnd* pWndForOpen)
{
	DWORD dwSleepOnExit=0;
	CWnd* pWnd=pWndForOpen;
	if(pWnd==0){
		pWnd=AfxGetMainWnd();
	}
	if(!pWnd || !pWnd->OpenClipboard()){
		if(pWnd->GetSafeHwnd()!=GetOpenClipboardWindow()){
			return FALSE;
		}
	}
	::EmptyClipboard();
	if(wszText!=NULL){
		long bWorkOnNT=-1;
		{// �� 98�� �������� ������ ���� ������ - FIXED
			CString sVer;
			GetOSVersion(sVer, NULL, &bWorkOnNT);
		}
#ifdef _DEBUG
		GetGlobalClipTextD()=wszText;
#endif
		BOOL bSkipRest=0;
		{// ��� Win2000/NT/XP - CF_DIB
			const char* szClipBMP=(const char*)wszText;
			const char* szBMPStart=strstr(szClipBMP,BMP_SPECPREFIX);
			if(szBMPStart!=0){
				bSkipRest=1;
				int iFrom=0;
				HGLOBAL hClipDib=0;
				DWORD dwSize=atol(CDataXMLSaver::GetInstringPart(BMP_SPECPREFIX"[","]",szBMPStart,iFrom));
				PackFromString(szBMPStart+iFrom,dwSize,hClipDib,((bWorkOnNT)?GMEM_MOVEABLE:GMEM_FIXED)|GMEM_ZEROINIT);
				//TRACE2("\n\nPasting image!!! Size=%lu(%lu)\n\n",GlobalSize(hClipDib),dwSize);
				if(hClipDib!=NULL){
					bThroughGlobal=0;
					/*LPBITMAPINFO lpBI = (LPBITMAPINFO)GlobalLock(hClipDib);
					if(lpBI){
						void* pDIBBits=(void*)(lpBI + 1); 
						CDC cTemp;
						CBitmap bmp;
						cTemp.CreateCompatibleDC(&GetScreenDC());
						bmp.CreateCompatibleBitmap(&GetScreenDC(),lpBI->bmiHeader.biWidth,lpBI->bmiHeader.biHeight);
						CBitmap* pBmpOld=cTemp.SelectObject(&bmp);
						SetDIBitsToDevice(cTemp.m_hDC,0,0,lpBI->bmiHeader.biWidth,lpBI->bmiHeader.biHeight,
							0,0,lpBI->bmiHeader.biWidth,lpBI->bmiHeader.biHeight,pDIBBits,lpBI,DIB_RGB_COLORS);
						//StretchDIBits(cTemp.m_hDC,0,0,lpBI->bmiHeader.biWidth,lpBI->bmiHeader.biHeight,0,0,lpBI->bmiHeader.biWidth,lpBI->bmiHeader.biHeight,pDIBBits,lpBI,DIB_RGB_COLORS,SRCCOPY);
						::SetClipboardData(CF_BITMAP,bmp.GetSafeHandle());
						bmp.Detach();
						cTemp.SelectObject(pBmpOld);
						GlobalUnlock(hClipDib);
						GlobalFree(hClipDib);
					}*/
					::SetClipboardData(CF_DIB,hClipDib);
					dwSleepOnExit=int(1000*double(dwSize/3000000));
				}
			}
		}
		if(!bSkipRest){// ��� Win2000/NT/XP - CF_UNICODETEXT
			WCHAR* szCliptextW=NULL;
			HGLOBAL hCliptextW=::GlobalAlloc((bWorkOnNT?GMEM_MOVEABLE:GMEM_FIXED)|GMEM_ZEROINIT,(wcslen(wszText)+1)*2);
			if(hCliptextW!=NULL){
				szCliptextW=(WCHAR*)::GlobalLock(hCliptextW);
				wcscpy(szCliptextW,wszText);
				::GlobalUnlock(hCliptextW);
				::SetClipboardData(CF_UNICODETEXT,bThroughGlobal?NULL:szCliptextW);
				if(bThroughGlobal){
					GetGlobalClipText(1)=hCliptextW;
				}
			}
		}
		if(!bSkipRest){// ��� Win98/ME/�� ������������ �������� - CF_TEXT
			char* szCliptextA=NULL;
			HGLOBAL hCliptextA=::GlobalAlloc((bWorkOnNT?GMEM_MOVEABLE:GMEM_FIXED)|GMEM_ZEROINIT,wcslen(wszText)+1);
			if(hCliptextA!=NULL){
				//USES_CONVERSION;
				szCliptextA=(char*)::GlobalLock(hCliptextA);
				WideCharToMultiByte(CP_ACP, 0, wszText, -1, szCliptextA, wcslen(wszText), NULL, NULL);
				//strcpy(szCliptextA,W2A(wszText));
				::GlobalUnlock(hCliptextA);
				::SetClipboardData(CF_TEXT,bThroughGlobal?NULL:szCliptextA);
				if(bThroughGlobal){
					GetGlobalClipText(0)=hCliptextA;
				}
			}
		}
	}
	::CloseClipboard();
	if(dwSleepOnExit){
		Sleep(dwSleepOnExit);
	}
	return TRUE;
}

CString GetClipboardLinksAsText(BOOL bOpenCloseClip)
{
	if(bOpenCloseClip){
		CWnd* pWnd=AfxGetMainWnd();
		if(!pWnd || !pWnd->OpenClipboard()){
			return "";
		}
	}
	CString str="";
	HDROP hCliptext=(HDROP)::GetClipboardData(CF_HDROP);
	if(hCliptext){
		char szFilePath[256];
		UINT cFiles = DragQueryFile(hCliptext, (UINT)-1, NULL, 0);
		for (UINT u = 0; u < cFiles; u++){
			DragQueryFile(hCliptext, u, szFilePath, sizeof(szFilePath));
			str+=szFilePath;
			if(u!=cFiles-1){
				str+="\n";
			}
		}
	}
	if(bOpenCloseClip){
		::CloseClipboard();
	}
	return str;
}

BOOL IsBMP(const char* szStr)
{
	if(szStr){
		if(strstr(szStr,BMP_SPECPREFIX)!=0){
			return TRUE;
		}
	}
	return FALSE;
}

BOOL IsBMP(WCHAR* wStr)
{
	if(wStr){
		const char* sz=(const char*)wStr;
		if(strstr(sz,BMP_SPECPREFIX)!=0){
			return TRUE;
		}
	}
	return FALSE;
}

DWORD& MaxBmpSize()
{
	static DWORD dw=0;
	return dw;
}

WCHAR* GetClipboardText(BOOL bAndClear, BOOL bWithBitmaps)
{
	CWnd* pWnd=AfxGetMainWnd();
	if(!pWnd || !pWnd->OpenClipboard()){
		return NULL;
	}
	LOGSTAMP
	//bWithBitmaps=0;
	//MaxBmpSize()=100;
	// �������� � UniCode
	WCHAR* strW=NULL;
	BOOL bSkipRest=0;
	BOOL bWasLink=0;
	LOGSTAMP
	if(!bSkipRest && IsClipboardFormatAvailable(CF_HDROP)){
		LOGSTAMP
		if(strW==NULL || wcslen(strW)==0){// ����� ���� ����� �� �����?
			LOGSTAMP
			CString str=GetClipboardLinksAsText(0);
			LOGSTAMP
			size_t len=strlen(str);
			if(len>0){
				LOGSTAMP
				if(strW){
					LOGSTAMP
					delete[] strW;
					strW=0;
				}
				USES_CONVERSION;
				strW = new WCHAR[len+1];
				memset(strW,0,(len+1)*sizeof(WCHAR));
				wcscpy(strW,A2W(str));
				bSkipRest=1;
				bWasLink=1;
				LOGSTAMP
			}
		}
	}
#ifdef _DEBUG
	if(bWasLink){
		FLOG("Getting links");
	}else{
		FLOG("Skipping links");
	}
#endif
	if(!bSkipRest && IsClipboardFormatAvailable(CF_UNICODETEXT)){
		LOGSTAMP
		HANDLE hCliptextW=::GetClipboardData(CF_UNICODETEXT);
		if(hCliptextW){
			DWORD dwDataSize=GlobalSize(hCliptextW);
			LOGSTAMP
			if(MaxBmpSize()==0 || dwDataSize<MaxBmpSize()){
				WCHAR* cliptxt=(WCHAR*)::GlobalLock(hCliptextW);
				size_t len=wcslen(cliptxt);
				if(len>0){
					if(strW){
						delete[] strW;
						strW=0;
					}
					LOGSTAMP
					strW = new WCHAR[len+1];
					memset(strW,0,(len+1)*sizeof(WCHAR));
					wcscpy(strW,cliptxt);
					bSkipRest=1;
				}
				GlobalUnlock(hCliptextW);
				LOGSTAMP
			}
		}
	}
	LOGSTAMP
	if(!bSkipRest && IsClipboardFormatAvailable(CF_TEXT)){
		// �������� � ������
		HANDLE hCliptext=::GetClipboardData(CF_TEXT);
		if(hCliptext){
			DWORD dwDataSize=GlobalSize(hCliptext);
			if(MaxBmpSize()==0 || dwDataSize<MaxBmpSize()){
				char* cliptxt = (char*)GlobalLock(hCliptext); 
				size_t len=strlen(cliptxt);
				if(len>0){
					if(strW){
						delete[] strW;
						strW=0;
					}
					strW = new WCHAR[len+1];
					memset(strW,0,(len+1)*sizeof(WCHAR));
					MultiByteToWideChar(CP_ACP, 0, cliptxt, -1, strW, len);
					bSkipRest=1;
				}
				GlobalUnlock(hCliptext);
			}
		}
	}
	LOGSTAMP
	if(!bSkipRest && bWithBitmaps && IsClipboardFormatAvailable(CF_DIB)){
		// �������� � BMP
		HANDLE hClipbmp=::GetClipboardData(CF_DIB);
		if(hClipbmp){
			DWORD dwDataSize=GlobalSize(hClipbmp);
			if(MaxBmpSize()==0 || dwDataSize<MaxBmpSize()){
				char* cliptxt=0;
				char* cliptxtbmp = (char*)GlobalLock(hClipbmp);
				if(cliptxtbmp){
					cliptxt=new char[dwDataSize];
					memcpy(cliptxt,cliptxtbmp,dwDataSize);
				}
				GlobalUnlock(hClipbmp);
				if(cliptxt && dwDataSize>sizeof(BITMAPINFO)){
					BITMAPINFO* pBMPDsc=(BITMAPINFO*)cliptxt;
					DWORD dwImageDataSize=0;
					CString sBMPDsc=Format("%lux%lu ",abs(pBMPDsc->bmiHeader.biWidth),abs(pBMPDsc->bmiHeader.biHeight));
					if(pBMPDsc->bmiHeader.biBitCount==0){
						sBMPDsc+="JPG/PNG";
					}else if(pBMPDsc->bmiHeader.biBitCount==1){
						dwImageDataSize=(pBMPDsc->bmiHeader.biHeight*pBMPDsc->bmiHeader.biWidth)/8;
						sBMPDsc+="Mono";
					}else if(pBMPDsc->bmiHeader.biBitCount==4){
						dwImageDataSize=(pBMPDsc->bmiHeader.biHeight*pBMPDsc->bmiHeader.biWidth)/2;
						sBMPDsc+=Format("16 %s",_l("Colors"));
					}else if(pBMPDsc->bmiHeader.biBitCount==8){
						dwImageDataSize=(pBMPDsc->bmiHeader.biHeight*pBMPDsc->bmiHeader.biWidth);
						sBMPDsc+=Format("256 %s",_l("Colors"));
					}else if(pBMPDsc->bmiHeader.biBitCount==16){
						dwImageDataSize=(pBMPDsc->bmiHeader.biHeight*pBMPDsc->bmiHeader.biWidth)*2;
						sBMPDsc+=Format("16 %s",_l("Bits"));
					}else if(pBMPDsc->bmiHeader.biBitCount==24){
						dwImageDataSize=(pBMPDsc->bmiHeader.biHeight*pBMPDsc->bmiHeader.biWidth)*3;
						sBMPDsc+=Format("24 %s",_l("Bits"));
					}else if(pBMPDsc->bmiHeader.biBitCount==32){
						dwImageDataSize=(pBMPDsc->bmiHeader.biHeight*pBMPDsc->bmiHeader.biWidth)*4;
						sBMPDsc+=Format("32 %s",_l("Bits"));
					}
					if(sBMPDsc!=""){
						sBMPDsc=CString(", ")+sBMPDsc;
					}
					DWORD dwHeaderLen=sizeof(BITMAPINFO);
					dwImageDataSize+=dwHeaderLen;
					TRACE2("\n\nCoping Bitmap!!! Size=%lu(%lu)\n\n", dwDataSize, dwImageDataSize);
					DWORD dwHashSize=dwDataSize;
					if(dwImageDataSize<=dwHashSize){
						dwHashSize=dwImageDataSize;
					}
					if(dwDataSize>0){
						CString sPacked=PackToString(cliptxt, dwDataSize);
						CString sHash=GetStringHash(PackToString(cliptxt+dwHeaderLen, dwHashSize-dwHeaderLen));
						CString sPreview=_l("Bitmap")+sBMPDsc+BMP_SPECPREFIX+Format("[%lu,%s]",dwDataSize,sHash);
						sPreview+=sPacked;
						int len=sPreview.GetLength()/sizeof(WCHAR);
						if(strW){
							delete[] strW;
							strW=0;
						}
						strW = new WCHAR[len+1];
						memset(strW,0,(len+1)*sizeof(WCHAR));
						memcpy((char*)strW,(const char*)sPreview,sPreview.GetLength());
						bSkipRest=1;
					}
				}
				if(cliptxt){
					delete[] cliptxt;
				}
			}
		}
	}
	LOGSTAMP
	::CloseClipboard();
	LOGSTAMP
	/*// ��� ���� ���������� ��� ������ - �������� ���� � �������!
	if(strW!=NULL){
		if(bAndClear){
			::OpenClipboard(NULL);
			::EmptyClipboard();
			::CloseClipboard();
		}
	}*/
	return strW;
}

int FindIDNumInNum2IDMap(aNum2IDMap& aM2I, DWORD dwCode)
{
	for(int i=0;i<aM2I.GetSize();i++){
		if(aM2I[i]==dwCode){
			return i;
		}
	}
	return -1;
}

// ���� *acceptOwnerDrawMenus==-1, �� OwnerDrawMenus ����� ������������ � �� �����������
// ���� aM2I �� NULL, �� ���� ������� ����� 1+offset, 2+offset � �.�., � �������� id ����� � �������
int AppendClonedMenuEx(CMenu* pMenu, HMENU hMenu, long lIDOffset, BOOL* acceptOwnerDrawMenus, aNum2IDMap* aM2I)
{
	int iRes=0;
	if(!pMenu || !hMenu || !IsMenu(hMenu)){
		return iRes;
	}
	int iCount=GetMenuItemCount(hMenu);
	int iBreakPosition=iCount/2;
	if(iBreakPosition>40){
		iBreakPosition=30;
	}
	if(iBreakPosition<15){
		iBreakPosition=-1;
	}
	for(int i=0;i<iCount;i++){
		char szTitle[256]="";
		MENUITEMINFO inf;
		memset(&inf,0,sizeof(inf));
		inf.fMask=MIIM_DATA|MIIM_TYPE|MIIM_ID|MIIM_STATE|MIIM_SUBMENU|MIIM_CHECKMARKS;
		inf.dwTypeData=(char*)&szTitle;
		inf.cch=sizeof(szTitle);
		inf.cbSize=sizeof(inf);
		if(GetMenuItemInfo(hMenu,i,TRUE,&inf)){
			char* szTab=strchr(szTitle,'\t');
			if(szTab){// �� ���������� �� ��� ����� ��������� (������ '\t\t', ������� ������� ��� ����� ����������)
				//ScanAndReplace(szTitle,"\t",' ');
				*szTab=0;
			}
			CString sItemTitle=szTitle;
			sItemTitle.TrimLeft();
			sItemTitle.TrimRight();
			BOOL bSeparator=0;
			if(inf.fType & MFT_SEPARATOR){
				bSeparator=1;
			}
			BOOL bOwnerDraw=0;
			if(inf.fType & MFT_OWNERDRAW){
				if(acceptOwnerDrawMenus && *acceptOwnerDrawMenus==-1){
					continue;
				}
				bOwnerDraw=1;
			}else{// ���� �� OwnerDraw, �� ������ ����������
				inf.fType&=~DWORD(MFT_BITMAP);
			}
			if(strlen(sItemTitle)==0 && !bOwnerDraw && !bSeparator){
				//sItemTitle=Format("Menu item #%i",i);
				continue;
			}
			BOOL bBreak=0;
			if(iBreakPosition>0 && i>1 && ((i-1)%iBreakPosition)==0){
				bBreak=MF_MENUBARBREAK;
			}
			if(inf.hSubMenu!=0){
				CMenu SubMenu;
				SubMenu.CreatePopupMenu();
				int iSubRes=AppendClonedMenuEx(&SubMenu,inf.hSubMenu,lIDOffset,acceptOwnerDrawMenus,aM2I);
				if(iSubRes>0){
					iRes+=iSubRes;
					int iItemID=(UINT)SubMenu.GetSafeHmenu();
					if(bOwnerDraw){
						if(aM2I){
							int iIndex=(*aM2I).Add((UINT)inf.wID);
							iItemID=iIndex+lIDOffset;
						}
						if(acceptOwnerDrawMenus){
							*acceptOwnerDrawMenus=1;
						}
						inf.wID=iItemID;
						inf.hSubMenu=SubMenu.GetSafeHmenu();
						inf.fState=MF_OWNERDRAW | MF_POPUP | bBreak;//inf.fState | 
						//// bug here!!!
						BOOL bRes=pMenu->AppendMenu(inf.fState, iItemID, (const char*)inf.dwItemData);
						// ��������������� ������ ���
						inf.cbSize=sizeof(inf);
						inf.fMask=MIIM_DATA|0x00000100|MIIM_SUBMENU|MIIM_ID;
						SetMenuItemInfo(pMenu->GetSafeHmenu(),iItemID,FALSE,&inf);
					}else{
						BOOL bRes=pMenu->AppendMenu(inf.fState | inf.fType | MF_POPUP | bBreak, iItemID, sItemTitle);
					}
					SubMenu.Detach();
					iRes++;
				}
			}else{
				int iItemID=inf.wID;
				if(aM2I){
					int iIndex=(*aM2I).Add(iItemID);
					iItemID=iIndex+lIDOffset;
				}else{
					iItemID=inf.wID+lIDOffset;
				}
				if(bOwnerDraw){
					BOOL bRes=pMenu->AppendMenu(inf.fState | MF_OWNERDRAW | bBreak, iItemID, (const char*)inf.dwItemData);
					if(acceptOwnerDrawMenus){
						*acceptOwnerDrawMenus=1;
					}
				}else{
					BOOL bRes=pMenu->AppendMenu(inf.fState | inf.fType | bBreak, iItemID, sItemTitle);
				}
				iRes++;
			}
		}else{
			DWORD dwRes=GetLastError();
		}
	}
	return iRes;
}

int AppendClonedMenuHalfEx(CMenu* pMenu, HMENU hMenu, long lIDOffset, BOOL* acceptOwnerDrawMenus, aNum2IDMap* aM2I)
{
	static long lLock=0;
	if(lLock>0){
		return 0;
	}
	SimpleTracker tr(lLock);
	return AppendClonedMenuEx(pMenu, hMenu, lIDOffset, acceptOwnerDrawMenus, aM2I);
}

int AppendClonedMenu(CMenu* pMenu, HMENU hMenu, long lIDOffset, BOOL* acceptOwnerDrawMenus, aNum2IDMap* aM2I)
{
	int iRes=0;
	__try{
		iRes=AppendClonedMenuHalfEx(pMenu, hMenu, lIDOffset, acceptOwnerDrawMenus, aM2I);
	}
	__except(EXCEPTION_EXECUTE_HANDLER){
		iRes=0;
	}
	return iRes;

}

BOOL isWindowStationLocked()
{
	static BOOL bWin98=isWin9x();
	if(bWin98 || ::GetForegroundWindow()!=NULL){
		return FALSE;
	}
	SetLastError(0);
	HDESK desktop = OpenInputDesktop(0,FALSE,DESKTOP_READOBJECTS);
	if(desktop){
		/*char szData[256]="";
		DWORD dwLen=0;
		GetUserObjectInformation(desktop, UOI_NAME, szData, sizeof(szData), &dwLen);
		sDesk=szData;
		TRACE(sDesk);*/
		CloseDesktop(desktop);
	}else if(GetLastError()==0){
		// ���� ������������ ������� - ������� �� �������!
		return TRUE;
	}
	return FALSE;
}

BOOL isScreenSaverActive()
{
	BOOL srunning=FALSE;
	BOOL res=SystemParametersInfo(114/*SPI_GETSCREENSAVERRUNNING*/,0,&srunning,0);
	if (res) {
		if (srunning==0){
			return FALSE;
		}else{
			return TRUE;
		}
	}
	// That works fine under '95, '98 and NT5. But not older versions of NT.
	// Hence we need some magic.
	HDESK hDesk=OpenDesktop(TEXT("screen-saver"), 0, FALSE, MAXIMUM_ALLOWED);
	if (hDesk!=NULL){
		CloseDesktop(hDesk);
		return TRUE;
	}
	if (GetLastError()==ERROR_ACCESS_DENIED){
		return TRUE;
	}
	return FALSE;
}

BOOL isScreenSaverActiveOrCLocked()
{
	if(isScreenSaverActive()){
		return TRUE;
	}
	return isWindowStationLocked();
}

CString createExclusionName(LPCTSTR GUID, UINT kind)
{
    switch(kind)
    { // ���  
		
	case UNIQUE_TO_SYSTEM:
		return CString(GUID);
		
	case UNIQUE_TO_DESKTOP:
        { // ������� ����  
            CString s = GUID;
            DWORD len;
            HDESK desktop = GetThreadDesktop(GetCurrentThreadId());
            BOOL result = GetUserObjectInformation(desktop, UOI_NAME, NULL, 0, &len);
            DWORD err = ::GetLastError();
            if(!result && err == ERROR_INSUFFICIENT_BUFFER)
            { // NT/2000  
                LPBYTE data = new BYTE[len];
                result = GetUserObjectInformation(desktop, UOI_NAME, data, len, &len);
                s += _T("-");
                s += (LPCTSTR)data;
                delete [ ] data;
            } // NT/2000  
            else
            { // Win9x  
                s += _T("_Win9x");
            } // Win9x   
			
            return s;
        } // ������� ����  
		
	case UNIQUE_TO_SESSION:
        { // ������  
            CString s = GUID;
            HANDLE token;
            DWORD len;
            BOOL result = OpenProcessToken(GetCurrentProcess(), TOKEN_QUERY, &token);
            if(result)
            { // NT  
                GetTokenInformation(token, TokenStatistics, NULL, 0, &len);
                LPBYTE data = new BYTE[len];
                GetTokenInformation(token, TokenStatistics, data, len, &len);
                LUID uid = ((PTOKEN_STATISTICS)data)->AuthenticationId;
                delete [ ] data;
                CString t;
                t.Format(_T("_%08x%08x"), uid.HighPart, uid.LowPart);
                return s + t;
            } // NT  
			
            else
            { // 16-������ OS  
				
                return s;
            } // 16-������ OS 
        } // ������ 
		
	case UNIQUE_TO_TRUSTEE:
        { // ������������ 
            CString s = GUID;
			#define NAMELENGTH 64
            TCHAR userName[NAMELENGTH];
            DWORD userNameLength = NAMELENGTH;
            TCHAR domainName[NAMELENGTH];
            DWORD domainNameLength = NAMELENGTH;
			
            if(GetUserName(userName, &userNameLength))
            { // �������� ������� ��� 
				
                // ������ NetApi ����� ���������� �� �������
                // ���� ����� �������� �������� ��� ��
                // ���������� ���������
                domainNameLength = ExpandEnvironmentStrings(_T("%USERDOMAIN%"),
					domainName,
					NAMELENGTH);
                CString t;
                t.Format(_T("_%s_%s"), domainName, userName);
                s += t;
            } // �������� ������� ��� 
            return s;
        } // ������������ 
	case UNIQUE_TO_COMPUTER:
		{ // ������������ 
            CString s = GUID;
#define NAMELENGTH 64
            TCHAR domainName[NAMELENGTH];
            DWORD domainNameLength = NAMELENGTH;
			TCHAR szCompName[MAX_COMPUTERNAME_LENGTH + 1]="";
			DWORD szCompNameLength=sizeof(szCompName);
            if(GetComputerName(szCompName,&szCompNameLength))
            { // �������� ��� �����
				
                // ������ NetApi ����� ���������� �� �������
                // ���� ����� �������� �������� ��� ��
                // ���������� ���������
                domainName[0] = 0;//ExpandEnvironmentStrings(_T("%USERDOMAIN%"),domainName,NAMELENGTH);
                CString t;
                t.Format(_T("_%s_%s"), domainName, szCompName);
                s += t;
            } // �������� ��� �����
            return s;
        } // ������������ 
	default:
		ASSERT(FALSE);
		break;
    } // ��� 
	
    return CString(GUID);
}// createExclusionName

BOOL CheckProgrammRunState(const char* szProgName, UINT kind, bool bLeaveHandled, const char* szDesktop)
{
    bool AlreadyRunning=false;
    SetLastError(0);
	CString sDesk=szDesktop;
	if(sDesk==""){
		IsDefaultDesktop(&sDesk);
	}
	CString sMutexName=createExclusionName(CString("WIREDPLANE_")+(szProgName?szProgName:GetApplicationName())+sDesk, kind);
    HANDLE hMutexOneInstance = ::CreateMutex( NULL, TRUE, sMutexName);
    AlreadyRunning = (GetLastError() == ERROR_ALREADY_EXISTS);
    if (hMutexOneInstance != NULL){
        ::ReleaseMutex(hMutexOneInstance);
    }
    if(!bLeaveHandled){
		CloseHandle(hMutexOneInstance);
    }
	return AlreadyRunning;
}

BOOL IsThisProgrammAlreadyRunning(UINT kind)
{
	return CheckProgrammRunState(NULL, kind, true);
}

BOOL IsOtherProgrammAlreadyRunning(const char* szProgName, UINT kind)
{
	return CheckProgrammRunState(szProgName, kind, false);
}

UINT GetProgramWMMessage(const char* szProgName)
{
	CString sMsg=CString("WM_WIREDPLANE_")+(szProgName?szProgName:GetApplicationName());
	return RegisterWindowMessage(sMsg);
}

static int CALLBACK BrowseCallbackProc (HWND hWnd, UINT uMsg, LPARAM lParam, LPARAM lpData)
{
    TCHAR szPath[_MAX_PATH];
    switch (uMsg) {
    case BFFM_INITIALIZED:
        if (lpData)
            SendMessage(hWnd,BFFM_SETSELECTION,TRUE,lpData);
        break;
    case BFFM_SELCHANGED:
        SHGetPathFromIDList(LPITEMIDLIST(lParam),szPath);
        SendMessage(hWnd, BFFM_SETSTATUSTEXT, NULL, LPARAM(szPath));
        break;
    }
    return 0;
}

//SHGetSpecialFolderPathA
typedef BOOL (WINAPI *_SHGetSpecialFolderLocation)(HWND hwndOwner, int nFolder, LPITEMIDLIST * ppidl);
BOOL MyGetSpecialFLoc(HWND hwndOwner, int nFolder, LPITEMIDLIST * ppidl)
{
	BOOL bRes=FALSE;
	HINSTANCE hShell32=LoadLibrary("Shell32.dll");
	if(hShell32){
		_SHGetSpecialFolderLocation fp=(_SHGetSpecialFolderLocation)GetProcAddress(hShell32,"SHGetSpecialFolderLocationA");
		if(!fp){
			fp=(_SHGetSpecialFolderLocation)GetProcAddress(hShell32,"SHGetSpecialFolderLocation");
		}
		LPITEMIDLIST pIdl = NULL;
		bRes=(*fp)(hwndOwner,nFolder,ppidl);
		FreeLibrary(hShell32);
	}
	return bRes;
}

#define BIF_EDITBOX            0x0010   // Add an editbox to the dialog
#define BIF_NEWDIALOGSTYLE     0x0040   // Use the new dialog layout with the ability to resize
                                        // Caller needs to call OleInitialize() before using this API
#define BIF_USENEWUI           (BIF_NEWDIALOGSTYLE | BIF_EDITBOX)
BOOL GetFolderRaw (LPCTSTR szTitle, LPTSTR szPath, LPCTSTR szRoot, HWND hWndOwner, DWORD dwFlags)
{
    if (szPath == NULL)
        return false;

	CoInitialize(0);
    bool result = false;

    LPMALLOC pMalloc;
    if (::SHGetMalloc(&pMalloc) == NOERROR) {
        BROWSEINFO bi;
        ::ZeroMemory(&bi,sizeof bi);
        bi.ulFlags   = BIF_RETURNONLYFSDIRS|BIF_USENEWUI;

        // ���������� ����-��������� �������
        bi.hwndOwner = hWndOwner;

        // ���������� ��������� � �������
        bi.lpszTitle = szTitle;
		// 
		CString strDisplayName;
		bi.pszDisplayName=strDisplayName.GetBuffer(MAX_PATH + 1);

        // ����������� �������� ��������
        bi.lpfn      = BrowseCallbackProc;
        bi.ulFlags  |= BIF_STATUSTEXT;
		bi.ulFlags  |= dwFlags;

        // ��������� �������� �� ���������
        bi.lParam    = LPARAM(szPath);

        // ��������� ��������� ��������
		BOOL bSearchForComp=FALSE;
		if(dwFlags & BIF_BROWSEFORCOMPUTER){
			bSearchForComp=TRUE;
		}
        if (szRoot != NULL) {
            IShellFolder *pDF;
            if (SHGetDesktopFolder(&pDF) == NOERROR) {
                LPITEMIDLIST pIdl = NULL;
                ULONG        chEaten;
                ULONG        dwAttributes;

                USES_CONVERSION;
                LPOLESTR oleStr = T2OLE(szRoot);

                pDF->ParseDisplayName(NULL,NULL,oleStr,&chEaten,&pIdl,&dwAttributes);
                pDF->Release();
                bi.pidlRoot = pIdl;
            }
        }else{
			if(bSearchForComp){
				LPITEMIDLIST pIdl = NULL;
				if(MyGetSpecialFLoc(NULL,CSIDL_NETWORK,&pIdl)){
					bi.pidlRoot=pIdl;
				}
			}
		}
        LPITEMIDLIST pidl = ::SHBrowseForFolder(&bi);
		strDisplayName.ReleaseBuffer();
        if (pidl != NULL) {
			if (::SHGetPathFromIDList(pidl,szPath)){
				result = true;
			}else{
				strcpy(szPath,strDisplayName);
				if(strlen(szPath)>0){
					result = true;
				}
			}
            pMalloc->Free(pidl);
			//
			if(bSearchForComp){
				// ����������� ��� �����
				CString sCompOnly=CDataXMLSaver::GetInstringPart("\\\\","\\",szPath);
				if(strlen(sCompOnly)>0){
					strcpy(szPath,sCompOnly);
				}
			}
        }
        if (bi.pidlRoot != NULL)
            pMalloc->Free((void*)bi.pidlRoot);
        pMalloc->Release();
    }
	CoUninitialize();
    return result;
}

BOOL GetFolder(LPCTSTR szTitle, LPTSTR szPath, LPCTSTR szRoot, HWND hWndOwner)
{
	return GetFolderRaw (szTitle, szPath, szRoot, hWndOwner, 0);
}

BOOL GetFolderComputer(LPCTSTR szTitle, LPTSTR szPath, HWND hWndOwner)
{
	return GetFolderRaw (szTitle, szPath, NULL, hWndOwner, BIF_BROWSEFORCOMPUTER);
}

void ShowHelp(const char* szTopicNameRaw)
{
	CString szTopicName=szTopicNameRaw;
	szTopicName.MakeLower();
	CString sFile=Format("%s%s_l%i.chm", GetApplicationDir(), GetApplicationName(), GetApplicationLang());
	if(!isFileExist(sFile)){
		sFile=Format("%s%s_l0.chm", GetApplicationDir(), GetApplicationName());
		if(!isFileExist(sFile)){
			sFile=Format("%s%s.chm", GetApplicationDir(), GetApplicationName());
		}
		if(!isFileExist(sFile)){
			::ShellExecute(GetAppWnd()?GetAppWnd()->GetSafeHwnd():NULL,"open","help.html",0,GetApplicationDir(),SW_SHOWNORMAL);
			return;
		}
	}
	::ShellExecute(GetAppWnd()?GetAppWnd()->GetSafeHwnd():NULL,NULL,"hh.exe",Format("%s::/%s.shtml",sFile,szTopicName),GetApplicationDir(),SW_SHOWNORMAL);
}

int AddMenuSubmenu(CMenu* pMenuTo, CMenu* pMenuFrom, const char* szString, CBitmap* pBmp, DWORD dwID, int iIndexTo)
{
	int iRes=-1;
	if(!pMenuFrom || !pMenuFrom->GetSafeHmenu() || pMenuFrom->GetMenuItemCount()==0){
		return iRes;
	}
	if(iIndexTo==-1){
		pMenuTo->AppendMenu(MF_STRING|MF_POPUP, (UINT)pMenuFrom->GetSafeHmenu(), szString);
		iRes=pMenuTo->GetMenuItemCount()-1;
	}else{
		pMenuTo->DeleteMenu(iIndexTo,MF_BYPOSITION);
		pMenuTo->InsertMenu(iIndexTo, MF_BYPOSITION|MF_STRING|MF_POPUP, (UINT)pMenuFrom->GetSafeHmenu(), szString);
		iRes=iIndexTo;
	}
	if(pBmp!=NULL){
		pMenuTo->SetMenuItemBitmaps(iRes,MF_BYPOSITION,pBmp,NULL);
	}
	if(dwID!=NULL){
		MENUITEMINFO cmi;
		memset(&cmi,0,sizeof(cmi));
		cmi.cbSize=sizeof(cmi);
		cmi.wID=dwID;
		cmi.fMask=MIIM_ID;
		SetMenuItemInfo(pMenuTo->GetSafeHmenu(), iRes,TRUE,&cmi);
	}
	pMenuFrom->Detach();
	return iRes;
}

void AddMenuStringEx(CDWordArray* aIDsLog, CMenu* pMenu, int iID, const char* szString, CBitmap* pBmp, BOOL bCheck, CBitmap* pBmpC, BOOL bGray, BOOL bDisabled, BOOL bBreakMenu)
{
	if(aIDsLog){
		aIDsLog->Add(iID);
	}
	AddMenuString(pMenu, iID, szString, pBmp, bCheck, pBmpC, bGray, bDisabled, bBreakMenu);
}

void AddMenuString(CMenu* pMenu, int iID, const char* szString, CBitmap* pBmp, BOOL bCheck, CBitmap* pBmpC, BOOL bGray, BOOL bDisabled, BOOL bBreakMenu)
{
	DWORD dwFlags=MF_STRING|(bCheck?MF_CHECKED:MF_UNCHECKED)|(bGray?MF_GRAYED:0)|(bDisabled?MF_DISABLED:0)|(bBreakMenu?MF_MENUBARBREAK:0);
	pMenu->AppendMenu(dwFlags, iID, szString);
	if(pBmp!=NULL || pBmpC!=NULL){
		pMenu->SetMenuItemBitmaps(iID,MF_BYCOMMAND,pBmp,pBmpC);
	}
}

void AddMenuString(CMenu* pMenu, int iID, const char* szString, DWORD dwFlags, CBitmap* pBmp, CBitmap* pBmpC)
{
	pMenu->AppendMenu(dwFlags, iID, szString);
	if(pBmp!=NULL || pBmpC!=NULL){
		pMenu->SetMenuItemBitmaps(iID,MF_BYCOMMAND,pBmp,pBmpC);
	}
}

char szHexes[]="0123456789ABCDEF";
BOOL MakeSafeForURL(CString& sText)
{
	CString sOut="";
	sText.Replace("\t","    ");
	char const* szPos=sText;
	char buf[128]="";
	while(*szPos){
		char c=(*szPos);
		if(c<=32 || c>127 || c=='%' || c=='?' || c=='&' || c=='+'){
			sOut+="%";//Format("%%%2X",(*szPos));//sOut+=itoa((*szPos),buf,16);
			sOut+=szHexes[(c>>4)&0x0F];
			sOut+=szHexes[c&0x0F];
		}else{
			sOut+=c;
		}
		szPos++;
	}
	sText=sOut;
	return TRUE;
}

CSize GetLargestLineSize(CDC* pDC, CString sText, int& iLines)
{
	iLines=0;
	CSize sRes(0,0);
	while(TRUE){
		CString sLine=sText.SpanExcluding("\n");
		CSize sProbe=pDC->GetTextExtent(sLine);
		if(sProbe.cx>sRes.cx){
			sRes=sProbe;
		}
		iLines++;
		if(sLine==sText){
			break;
		}
		if(strlen(sLine)<strlen(sText)){
			sText=sText.Mid(strlen(sLine)+1);
		}
	}
	return sRes;
}

CString GetLargestLine(CString sText, int& iLines)
{
	iLines=0;
	CString sRes="";
	//sText.Replace("\r\n","\n");
	while(TRUE){
		CString sLine=sText.SpanExcluding("\n");
		if(sRes.GetLength()<sLine.GetLength()){
			sRes=sLine;
		}
		iLines++;
		if(sLine==sText){
			break;
		}
		if(strlen(sLine)<strlen(sText)){
			sText=sText.Mid(strlen(sLine)+1);
		}
	}
	return sRes;
}

void WndShake(CWnd* pWnd, DWORD dwTime)
{
	if(pWnd!=NULL && ::IsWindow(pWnd->GetSafeHwnd())){
		HWND hForegWnd=pWnd->GetSafeHwnd();
		CRect ActiveWndRect;
		pWnd->GetWindowRect(&ActiveWndRect);
		DWORD dwStart=GetTickCount();
		while(GetTickCount()-dwStart<dwTime){
			int xr=(rand()&0x000000FF)/10-128/10;
			int yr=(rand()&0x000000FF)/10-128/10;
			::MoveWindow(hForegWnd,ActiveWndRect.left+xr,ActiveWndRect.top+yr,ActiveWndRect.Width(),ActiveWndRect.Height(),TRUE);
			Sleep(10);
		}
		::MoveWindow(hForegWnd,ActiveWndRect.left,ActiveWndRect.top,ActiveWndRect.Width(),ActiveWndRect.Height(),TRUE);
	}
}

void WndBubbleHide(CWnd* pWnd, DWORD dwSpeed)
{
	if(pWnd!=NULL && ::IsWindow(pWnd->GetSafeHwnd())){
		CRect WndRect;
		pWnd->GetWindowRect(&WndRect);
		WndRect.OffsetRect(-WndRect.left,-WndRect.top);
		CRgn NoteRgn;
		NoteRgn.CreateRectRgnIndirect(&WndRect);
		pWnd->SetWindowRgn(NoteRgn,FALSE);
		// ������� �� ��������...
		int iXC=(WndRect.left+WndRect.right)/2;
		int iYC=(WndRect.top+WndRect.bottom)/2;
		int iMaxRad=int(sqrt(double(WndRect.Width()*WndRect.Width()+WndRect.Height()*WndRect.Height())));
		int iSteps=10;
		int iDev=iMaxRad/iSteps;
		for(int i=4;i<iSteps;i++){
			HRGN hRgn=CreateRectRgn(0,0,0,0);
			::GetWindowRgn(pWnd->GetSafeHwnd(), hRgn);
			int iRadius=rnd(i*iMaxRad/iSteps,i*iMaxRad/iSteps+iDev);
			int iX=iXC+rnd(-iDev,iDev);
			int iY=iYC+rnd(-iDev,iDev);
			CRgn hRgn2;
			hRgn2.CreateEllipticRgn(iX-iRadius/2,iY-iRadius/2,iX+iRadius/2,iY+iRadius/2);
			::CombineRgn(hRgn,hRgn,hRgn2,RGN_DIFF);
			pWnd->SetWindowRgn(hRgn,TRUE);
			DeleteObject(hRgn);
			Sleep(dwSpeed);
		}
	}
}

// iType==0 - �������
// iType==1 - ��������������
// iType==2 - ����������
// iType==3 - Suspend
// iType==4 - Hinernate
void ShutDownComputer(BOOL bRestart, int iType)
{
	FLOG2("ShutDownComputer %i ... %i", bRestart, iType);
	/*
	::SendMessage(HWND_BROADCAST,WM_SYSCOMMAND, SC_MONITORPOWER, 1);// ��������� �������
	"rundll32 shell32,SHExitWindowsEx 1" - ���������� ���������.
	"rundll32 shell32,SHExitWindowsEx 0" - ��������� ������ �������� ������������
	"rundll32 shell32,SHExitWindowsEx 2" Windows-98-PC boot
	*/
	if(bRestart && iType>2){
		iType=0;
	}
	CString sVer;
	long lUnderNT=0;
	DWORD dwMajor=0;
	GetOSVersion(sVer, &dwMajor, &lUnderNT);
	if(!lUnderNT){
		if(bRestart){
			if(iType==2){
				WinExec("rundll32 shell32,SHExitWindowsEx 6",SW_HIDE);
			}else{
				WinExec("rundll32 shell32,SHExitWindowsEx 2",SW_HIDE);
			}
		}
		if(iType==2){
			//WinExec("rundll32 krnl386.exe,exitkernel",SW_HIDE); // ������������ ����������
			WinExec("rundll32 shell32,SHExitWindowsEx 13",SW_HIDE);
		}else{
			WinExec("rundll32 shell32,SHExitWindowsEx 9",SW_HIDE);
		}
		if(iType==3){
			SetSystemPowerState(1,1);
			return;
		}
		if(iType==4){
			SetSystemPowerState(0,1);
			return;
		}
		return;
	}
	// ����� ����������...
	HANDLE hToken;              // handle to process token
	TOKEN_PRIVILEGES tkp;       // pointer to token structure 
	// Get the current process token handle so we can get shutdown privilege. 
	if (!OpenProcessToken(GetCurrentProcess(), TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, &hToken)) 
		return; 
	LookupPrivilegeValue(NULL, SE_SHUTDOWN_NAME, &tkp.Privileges[0].Luid);
	tkp.PrivilegeCount = 1;
	tkp.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED; 
	AdjustTokenPrivileges(hToken, FALSE, &tkp, 0, (PTOKEN_PRIVILEGES) NULL, 0);
	if (GetLastError() != ERROR_SUCCESS){
		AfxMessageBox(_L("Can`t shutdown computer")+"!");
		return;
	}
	DWORD dwType=0;// No force at all
	if(iType==1 && !bRestart){
		dwType=0x00000010;//EWX_FORCEIFHUNG
	}else if(iType==2){
		dwType=EWX_FORCE;
	}else if(iType==3){
		SetSystemPowerState(1,1);
		return;
	}else if(iType==4){
		SetSystemPowerState(0,1);
		return;
	}
	ExitWindowsEx((bRestart?EWX_REBOOT:EWX_POWEROFF)|dwType, 0xffffffff);
}

void AppDisplayProperties() 
{
	// Start the display properties dialog
	STARTUPINFO si;
	PROCESS_INFORMATION pi;

	ZeroMemory( &si, sizeof(si) );
	si.cb = sizeof(si);

	CreateProcess( NULL, // No module name (use command line). 
		"control.exe desk.cpl", // Command line. 
		NULL,             // Process handle not inheritable. 
		NULL,             // Thread handle not inheritable. 
		FALSE,            // Set handle inheritance to FALSE. 
		0,                // No creation flags. 
		NULL,             // Use parent�s environment block. 
		NULL,             // Use parent�s starting directory. 
		&si,              // Pointer to STARTUPINFO structure.
		&pi);             // Pointer to PROCESS_INFORMATION structure.
}

void AppAddRemPrograms() 
{
	// Start the display properties dialog
	STARTUPINFO si;
	PROCESS_INFORMATION pi;

	ZeroMemory( &si, sizeof(si) );
	si.cb = sizeof(si);

	CreateProcess( NULL, // No module name (use command line). 
		"control.exe appwiz.cpl", // Command line. 
		NULL,             // Process handle not inheritable. 
		NULL,             // Thread handle not inheritable. 
		FALSE,            // Set handle inheritance to FALSE. 
		0,                // No creation flags. 
		NULL,             // Use parent�s environment block. 
		NULL,             // Use parent�s starting directory. 
		&si,              // Pointer to STARTUPINFO structure.
		&pi);             // Pointer to PROCESS_INFORMATION structure.
}

BOOL CheckMyMaskSubstr(CString sTitle, CString sTitleMask, BOOL bDef)
{
	CString sIn=CDataXMLSaver::GetInstringPart("[=","=]",sTitleMask);
	if(sIn!=""){
		if(stricmp(sTitle,sIn)==0){
			return TRUE;
		}
	}
	CString sNotMaybe=CDataXMLSaver::GetInstringPart("[!","!]",sTitleMask);
	if(sNotMaybe!="" && sTitle.Find(sNotMaybe)!=-1){
		return FALSE;
	}
	CString sMaybe=CDataXMLSaver::GetInstringPart("[?","?]",sTitleMask);
	if(sMaybe!="" && sTitle.Find(sMaybe)!=-1){
		return TRUE;
	}
	if(sTitleMask.Find("*")==-1){
		if(sTitle.Find(sTitleMask)!=-1){
			return TRUE;
		}
	}else if(PatternMatch(sTitle,sTitleMask)){
		return TRUE;
	}
	return bDef;
}

void MakeJScriptSafe(CString& sFile)
{
	sFile.Replace("\\","\\\\");
	sFile.Replace("'","\\\'");
	sFile.Replace("\"","\\\"");
}

CMapStringToString& getMCookies()
{
	static CMapStringToString aCookies;
	return aCookies;
}

CString getCookie(const char* szKey)
{
	CString sVal;
	getMCookies().Lookup(szKey,sVal);
	return sVal;
}

BOOL ParseLineForCookies(CString& sText)
{
	int iFrom=0;
	while(iFrom>=0){
		CString sLine=CDataXMLSaver::GetInstringPartGreedly("%SET:","%",sText,iFrom);
		sText.Replace(Format("%%SET:%s%%",sLine),"");
		if(sLine!=""){
			CString sKey=sLine;
			CString sVal="";
			int iPos=sLine.Find("=");
			if(iPos!=-1){
				sKey=sLine.Left(iPos);
				sVal=sLine.Mid(iPos+1);
			}
			getMCookies().SetAt(sKey,sVal);
		}
	}
	iFrom=0;
	while(iFrom>=0){
		CString sLine=CDataXMLSaver::GetInstringPartGreedly("%RESET:","%",sText,iFrom);
		sText.Replace(Format("%%RESET:%s%%",sLine),"");
		if(sLine!=""){
			getMCookies().RemoveKey(sLine);
		}
	}
	return TRUE;
}

CFakeWindow::CFakeWindow(const char* szTitle)
{
	CRect rDesktopRECT(0,0,0,0);
	hWin = ::CreateWindowEx(WS_EX_TOOLWINDOW|WS_EX_TOPMOST|WS_EX_TRANSPARENT|WS_EX_APPWINDOW, "Static", szTitle?szTitle:"MENU_WND", WS_VISIBLE|WS_POPUP, rDesktopRECT.left, rDesktopRECT.top, rDesktopRECT.right-rDesktopRECT.left, rDesktopRECT.bottom-rDesktopRECT.top, 0, 0, AfxGetApp()->m_hInstance, 0);//WS_DISABLED|WS_VISIBLE
	//SetTaskbarButton(hWin);
	wnd.Attach(hWin);
}

CFakeWindow::~CFakeWindow()
{
	wnd.Detach();
	DestroyWindow(hWin);
}

#define MAX_LEN_ENVSUBST	10000
void SubstMyVariables(CString& sText,BOOL bJScriptSafe)
{
	// ������� ������� ����...
	int iFrom=0;
	while(iFrom>=0){
		CString sLine=CDataXMLSaver::GetInstringPart("%COOKIE:","%",sText,iFrom);
		sText.Replace(Format("%%COOKIE:%s%%",sLine),getCookie(sLine));
	}
	if(sText.Find("%CLIP")!=-1 || sText.Find("%E_CLIP")!=-1 || sText.Find("%URL_CLIP")!=-1){
		WCHAR* wszClip=GetClipboardText();
		CString sClip;
		if(wszClip){
			sClip=wszClip;
		}
		if(sClip.GetLength()<50000){
			sText.Replace("%CLIP",sClip);
			sText.Replace("%E_CLIP",EscapeString(sClip));
			sText.Replace("%URL_CLIP",EscapeStringUTF8(wszClip));
		}
		if(wszClip){
			delete[] wszClip;
		}
	}
	// Environment variables
	int iLen=strlen(sText);
	if(iLen>0 && iLen<MAX_LEN_ENVSUBST && sText.Find("%")!=-1){
		char szPathOut[MAX_LEN_ENVSUBST]="";
		strcpy(szPathOut,sText);
		DWORD dwDoEnv=DoEnvironmentSubst(szPathOut,sizeof(szPathOut));
		if(HIWORD(dwDoEnv)>0){
			sText=szPathOut;
		}
	}
	BOOL bNeedAsk=(sText.Find("%ASK")!=-1) || (sText.Find("%E_ASK")!=-1);
	if(bNeedAsk){
		if(sText.Find("%ASKFILE")!=-1 || sText.Find("%E_ASKFILE")!=-1){
			static CString sLastFile="c:\\";
			CString sFile="";
			CFakeWindow fakeWnd(_l("Browse for file"));
			CFileDialog dlg(TRUE, NULL, sLastFile, OFN_NODEREFERENCELINKS, "All files (*.*)|*.*||", fakeWnd.GetWnd());
			if(dlg.DoModal()==IDOK){
				sLastFile=dlg.GetPathName();
				sFile=sLastFile;
				if(bJScriptSafe){
					MakeJScriptSafe(sFile);
				}
			}
			sText.Replace("%ASKFILE",sFile);
			sText.Replace("%E_ASKFILE",EscapeString(sFile));
		}
		if(sText.Find("%ASKFOLDER")!=-1 || sText.Find("%E_ASKFOLDER")!=-1){
			static CString sLastFolder="";
			CString sFolder="";
			char szDir[MAX_PATH]="c:\\";
			CFakeWindow fakeWnd(_l("Browse for folder"));
			if(GetFolder(_l("Choose directory"), szDir, NULL, fakeWnd.GetHwnd())){//GetAppWnd()->GetSafeHwnd()
				sLastFolder=szDir;
				sFolder=szDir;
				if(bJScriptSafe){
					MakeJScriptSafe(sFolder);
				}
			}
			sText.Replace("%ASKFOLDER",sFolder);
			sText.Replace("%E_ASKFOLDER",EscapeString(sFolder));
		}
	}
	COleDateTime dt=COleDateTime::GetCurrentTime();
	sText.Replace("%DATE",Format("%02lu.%02lu.%04lu",dt.GetDay(),dt.GetMonth(),dt.GetYear()));
	sText.Replace("%TIME",Format("%02lu.%02lu.%02lu",dt.GetHour(),dt.GetMinute(),dt.GetSecond()));
	sText.Replace("%YEAR",Format("%04lu",dt.GetYear()));
	sText.Replace("%MONTH",Format("%02lu",dt.GetMonth()));
	sText.Replace("%DAY",Format("%02lu",dt.GetDay()));
	sText.Replace("%HOUR",Format("%02lu",dt.GetHour()));
	sText.Replace("%MINUTE",Format("%02lu",dt.GetMinute()));
	sText.Replace("%SECOND",Format("%02lu",dt.GetSecond()));
	sText.Replace("%RNDNAME",GetRandomName());
	sText.Replace("%TICKCOUNT",Format("%lu",GetTickCount()));
}

CString _IL(int i, const char* szPref)
{
	if(szPref==NULL){
		szPref="IML_";
	}
	CString sRes=Format("%s%i",szPref,i);
	return sRes;
}

void SendSuggestion(const char* szProg, const char* szVer, const char* szSubj)
{
	CString sOperSystem;
	GetOSVersion(sOperSystem);
	CString sText="mailto:";
	sText+=szProg;
	sText+="@wiredplane.com?Subject=";
	sText+=szSubj;
	sText+="&body=%0d%0a***%0d%0a";
	sText+=szProg;
	sText+="%20";
	sText+=szVer;
	sText+="%20-%20";
	sOperSystem.Replace(" ","%20");
	sText+=sOperSystem;
	ShellExecute(AfxGetMainWnd()->GetSafeHwnd(),NULL,sText,"",NULL,SW_SHOWNORMAL);
}

static killerKilled=0;
CThreadKiller& GetThreadKiller()
{
	static CThreadKiller killer;
	return killer;
}

CThreadKillerHolder::CThreadKillerHolder()
{
	if(!killerKilled){
		GetThreadKiller().AddThis();
	}
}

CThreadKillerHolder::~CThreadKillerHolder()
{
	if(!killerKilled){
		GetThreadKiller().RemoveThis();
	}
}

CThreadKiller::CThreadKiller()
{
	iTCount=0;
}

CThreadKiller::~CThreadKiller()
{
	killerKilled=1;
	CSmartLock Lock(&cs,TRUE);
	for(int i=0;i<threads.GetSize();i++){
		if(threads[i]){
			TerminateThread(threads[i],57);
			CloseHandle(threads[i]);
		}
	}
	threads.RemoveAll();
}

void CThreadKiller::AddThis()
{
	CSmartLock Lock(&cs,TRUE);
	threads.Add(GetCurrentThread());
}

void CThreadKiller::RemoveThis()
{
	CSmartLock Lock(&cs,TRUE);
	HANDLE hID=0;//DuplicateHandle(GetCurrentThread(),);!!! �� ����� ����� :(
	for(int i=0;i<threads.GetSize();i++){
		if(threads[i]==hID){
			threads.RemoveAt(i);
			return;
		}
	}
}

void GetWindowTopParent(HWND& hWnd)
{
	if(!hWnd){
		return;
	}
	//hWnd=::GetAncestor(hWnd,GA_ROOT);
	HWND hWnd2=hWnd;
	while(hWnd2!=NULL && IsWindowVisible(hWnd2)){
		hWnd=hWnd2;
		hWnd2=::GetWindow(hWnd,GW_OWNER);
		if(!hWnd2){
			hWnd2=::GetParent(hWnd);
		}
	}
	return;
}

#define DEF_LASTPRINTFILE	"Printed_note"
#define DEF_EXPLPRINTERSETS	"Software\\Microsoft\\Internet Explorer\\PageSetup"
#define DEF_IMPO_HEADER		"*** IPv6 - impossible header. Kirpi4i are cool! :>) ***"
#define DEF_IMPO_FOOTER		"*** IPv6 - impossible footer. Limp bizkit is cool! :^) ***"

BOOL PrintWindow_System(CWnd* pWnd, CString sText, CString sTitle)
{
	CString sTempFile=getFileFullName(DEF_LASTPRINTFILE);
	sTempFile+=".txt";
	SaveFile(sTempFile,sText);
	int iRes=(int)ShellExecute(pWnd?pWnd->GetSafeHwnd():NULL,"print",sTempFile,NULL,NULL, SW_SHOWMINIMIZED);
	return (iRes>32);
}

#ifdef _PRINT_CASES
BOOL PrintWindow_Explorer(CWnd* pWnd, CString sText, CString sTitle)
{
	CDataXMLSaver::Str2Xml(sText,0);
	sText.Replace("\n","<br>");
	sText=CString("<HTML><BODY>")+sText+"</BODY></HTML>";
	CString sTempFile=getFileFullName(DEF_LASTPRINTFILE);
	sTempFile+=".html";
	SaveFile(sTempFile,sText);
	// ������� ������
	BOOL bRestoreReg=TRUE;
	CString sFooter=DEF_IMPO_FOOTER,sHeader=DEF_IMPO_HEADER;
	CString sMyFooter="Page &p of &P",sMyHeader=TrimMessage(sTitle);
	{
		CRegKey key;
		if(key.Open(HKEY_CURRENT_USER, DEF_EXPLPRINTERSETS)!=ERROR_SUCCESS){
			key.Create(HKEY_CURRENT_USER, DEF_EXPLPRINTERSETS);
		}
		if(key.m_hKey!=NULL){
			DWORD dwType,dwSize,dwCount;
			dwType=0;
			dwSize=0;
			char szValue[1024]="";
			dwCount=sizeof(szValue);
			if(RegQueryValueEx(key.m_hKey,"footer",NULL, &dwType,(LPBYTE)szValue, &dwCount)==ERROR_SUCCESS){
				sFooter=szValue;
				RegSetValueEx(key.m_hKey,"footer",0,REG_SZ,(BYTE*)(LPCSTR)sMyFooter,lstrlen(sMyFooter)+1);
			}
			dwType=0;
			dwSize=0;
			szValue[0]=0;
			dwCount=sizeof(szValue);
			if(RegQueryValueEx(key.m_hKey,"header",NULL, &dwType,(LPBYTE)szValue, &dwCount)== ERROR_SUCCESS){
				sHeader=szValue;
				RegSetValueEx(key.m_hKey,"header",0,REG_SZ,(BYTE*)(LPCSTR)sMyHeader,lstrlen(sMyHeader)+1);
			}
		}
	}
	//
	BOOL bRes=(int(::ShellExecute(pWnd->GetSafeHwnd(),"print",sTempFile,NULL,NULL,SW_SHOWNORMAL))>32);
	// ��������������� ������
	{
		Sleep(1000);// ���� ����� ��� ���������
		CRegKey key;
		if(key.Open(HKEY_CURRENT_USER, DEF_EXPLPRINTERSETS)==ERROR_SUCCESS && key.m_hKey!=NULL){
			DWORD dwType=REG_SZ,dwSize=0;
			if(sFooter!=DEF_IMPO_FOOTER){
				RegSetValueEx(key.m_hKey,"footer",0,REG_SZ,(BYTE*)(LPCSTR)sFooter,lstrlen(sFooter)+1);
			}
			if(sHeader!=DEF_IMPO_HEADER){
				RegSetValueEx(key.m_hKey,"header",0,REG_SZ,(BYTE*)(LPCSTR)sHeader,lstrlen(sHeader)+1);
			}
		}
	}
	//������� ������, �.�. �� ������ ������������ �� ������ ������
	//DeleteFile(sTempFile);
	return bRes;
}

#include "PrivatePrint.h"
BOOL PrintWindow_Raw(CWnd* pWnd, CString sText, CString sTitle)
{
	// � ��� ���� �������� ��������...
	sText.Replace("\t","    ");
	//
	CDC dc; 
	DOCINFO di; 
	CPrintDialog dlg(FALSE); 
	
	dlg.GetDefaults(); 
	dc.Attach(dlg.GetPrinterDC()); 
	dc.SetMapMode(MM_TEXT);
	::ZeroMemory (&di, sizeof (DOCINFO)); 
	di.cbSize = sizeof (DOCINFO); 
	di.lpszDocName = sTitle;
	
	if(dc.StartDoc(&di)<0){
		return FALSE;
	}
	dc.StartPage();
	CPoint rtMargs(dc.GetDeviceCaps(PHYSICALOFFSETX), dc.GetDeviceCaps(PHYSICALOFFSETY));
	dc.DPtoLP(&rtMargs,1);
	CRect rt(0,0, dc.GetDeviceCaps(HORZRES), dc.GetDeviceCaps(VERTRES));
	dc.DPtoLP(&rt);
	rt.DeflateRect(rtMargs.x,rtMargs.y);
	//SelectClipRgn
	//dc.SelectObject(pWnd->GetFont());
	dc.DrawText(sText,&rt,0);
	//rt.DeflateRect(50,50);dc.DrawFocusRect(rt);
	dc.EndPage(); 
	dc.EndDoc();
	return TRUE;
}

BOOL PrintWindow_Priv(CWnd* pWnd, CString sText, CString sTitle)
{
	// � ��� ���� �������� ����� ��������� �����...
	CPrivatePrint	prt;
	prt.Dialog();
	if(prt.StartPrint(sTitle)<0){
		return FALSE;
	}
	LOGFONT logFont;
	CFont* pFont=pWnd->GetFont();
	if(!pFont->GetLogFont(&logFont)){
		return FALSE;
	}
	HPRIVATEFONT hFont = prt.AddFontToEnvironment(logFont.lfFaceName);
	prt.SetMargins(50,130,50,10);
	prt.SetDistance(2);
	//prt.ActivateHF(HeaderFooter);
	prt.StartPage();
	int iFrom=0;
	int iFileLen=strlen(sText);
	while(iFrom>=0 && iFrom<iFileLen){
		int iPos=sText.Find("\n",iFrom);
		if(iPos==-1){
			iPos=strlen(sText);
		}else{
			iPos=iPos+1;
		}
		CString sLine=sText.Mid(iFrom,iPos-iFrom);
		sLine.TrimRight();
		prt.Print(hFont,sLine,FORMAT_NORMAL);
		iFrom=iPos;
	}
	prt.EndPage();
	prt.EndPrint();
	return TRUE;
}
#endif

BOOL PrintWindow(CWnd* pWnd, CString sText, CString sTitle)
{
	if(!pWnd){
		return FALSE;
	}
	if(sTitle==""){
		sTitle=TrimMessage(sText,10);
	}
	if(sTitle==""){
		sTitle="Unknown";
	}
	HCURSOR hCur=SetCursor(LoadCursor(NULL,MAKEINTRESOURCE(IDC_WAIT)));
	//BOOL bRes=PrintWindow_Explorer(pWnd,sText,sTitle);
	BOOL bRes=PrintWindow_System(pWnd,sText,sTitle);
	SetCursor(hCur);
	return bRes;
}

/*
�� �������� ���������� � ������� urlmon.lib! 

//---------------------------------------------------------------------------
#include <urlmon.h>
#include <wininet.h>
#include <string>
//---------------------------------------------------------------------------
void SetProxyInfo(
                    const std::string& ProxyAddress
                  , long ProxyPort
                  , const std::string& ProxyLogin = ""
                  , const std::string& ProxyPassword = ""
                 )
{
 INTERNET_PROXY_INFO ipi;
 ipi.lpszProxyBypass = NULL;
 
 char strPort[33] = {0};
 ltoa(ProxyPort,strPort,10);

 if( ProxyAddress.empty() )
  {
    ipi.dwAccessType = INTERNET_OPEN_TYPE_DIRECT;
    ipi.lpszProxy = NULL;
  }
 else
  {
     std::string Proxy;
     if( !ProxyLogin.empty() )
         Proxy = ProxyLogin + ":" + ProxyPassword + "@";

     Proxy = Proxy + ProxyAddress + ":" + std::string(strPort);

     ipi.dwAccessType = INTERNET_OPEN_TYPE_PROXY;
     ipi.lpszProxy = Proxy.c_str();


  }

 UrlMkSetSessionOption(INTERNET_OPTION_PROXY,&ipi,sizeof(INTERNET_PROXY_INFO),0);
}
//---------------------------------------------------------------------------

 

��� ������������: 

1. �� ������ ����� ���������. 
2. ������� ������ ���. 
3. ��� ��������� �������� ������: 

SetProxyInfo("proxy.ip.or.string",1234);

 

4. ��� ������ ��������� ������: 

 SetProxyInfo("",0);
*/

// dwFrom: 0 - bytes, 1-Kb, 2-Mb
const DWORD dwBytesInMB=1024*1024;
CString GetSizeStrFrom(DWORD dwSize, DWORD dwFrom)
{
	if(dwFrom==1){
		dwSize*=1024;
	}
	if(dwFrom==2){
		dwSize*=dwBytesInMB;
	}
	// ��������� � ���������� ������
	CString sOut=Format("%ib",dwSize);
	if(dwSize>=dwBytesInMB){
		sOut=Format("%.2fMb",double(dwSize)/dwBytesInMB);
	}else if(dwSize>=1024){
		sOut=Format("%.2fKb",double(dwSize)/1024);
	}
	return sOut;
}

BOOL GetSpecialFolderPath(char* szOutPath, int nFolder)
{
	strcpy(szOutPath,"c:\\temp\\");
	TCHAR szPathName[MAX_PATH]="";
	LPITEMIDLIST pidl;
	HRESULT hRes=S_FALSE;
	IMalloc* pMalloc=NULL;
	hRes = SHGetMalloc(&pMalloc);
	if (SUCCEEDED(hRes)){
		hRes = MyGetSpecialFLoc(NULL, nFolder, &pidl);
		if (SUCCEEDED(hRes))
		{
			hRes = SHGetPathFromIDList(pidl, szPathName);
			pMalloc->Free(pidl);
		}
		pMalloc->Release();
	}
	// ���� SUCCEEDED(hRes), �� szPathName �������� ���� � ����� 
	if(SUCCEEDED(hRes)){
		strcpy(szOutPath,szPathName);
		return TRUE;
	}else{
		return FALSE;
	}
}

CRect GetDesktopRect()
{
	CRect rt;
	::SystemParametersInfo(SPI_GETWORKAREA,0,&rt,0);
	return rt;
}

void SetWindowSize(CWnd* pThis, CSize sx, UINT dwControlID)
{
	if(dwControlID!=0){
		pThis->GetDlgItem(dwControlID)->SetWindowPos(NULL,0,0,sx.cx,sx.cy,SWP_NOZORDER|SWP_NOMOVE);
	}else{
		pThis->SetWindowPos(NULL,0,0,sx.cx,sx.cy,SWP_NOZORDER|SWP_NOMOVE);
	}
}

void SetButtonSize(CWnd* pThis, UINT dwControlID, CSize sx)
{
	SetWindowSize(pThis, sx, dwControlID);
}

void SetButtonWidth(CWnd* pThis, UINT dwControlID, long sx)
{
	CRect rt;
	if(dwControlID!=0){
		pThis->GetDlgItem(dwControlID)->GetWindowRect(&rt);
	}else{
		pThis->GetWindowRect(&rt);
	}
	rt.right=rt.left+sx;
	SetWindowSize(pThis, rt.Size(), dwControlID);
}

void SetButtonHeight(CWnd* pThis, UINT dwControlID, long sy)
{
	CRect rt;
	if(dwControlID!=0){
		pThis->GetDlgItem(dwControlID)->GetWindowRect(&rt);
	}else{
		pThis->GetWindowRect(&rt);
	}
	rt.bottom=rt.top+sy;
	SetWindowSize(pThis, rt.Size(), dwControlID);
}

void SetButtonHeight(CWnd* pThis, UINT dwControlID, UINT iFrom)
{
	CRect rt;
	if(dwControlID!=0){
		pThis->GetDlgItem(dwControlID)->GetWindowRect(&rt);
	}else{
		pThis->GetWindowRect(&rt);
	}
	CRect rtFrom;
	if(iFrom!=0){
		pThis->GetDlgItem(iFrom)->GetWindowRect(&rtFrom);
	}else{
		pThis->GetWindowRect(&rtFrom);
	}
	rt.bottom=rt.top+rtFrom.Height();
	SetWindowSize(pThis, rt.Size(), dwControlID);
}

void SetButtonWidth(CWnd* pThis, UINT dwControlID, UINT iFrom)
{
	CRect rt;
	if(dwControlID!=0){
		pThis->GetDlgItem(dwControlID)->GetWindowRect(&rt);
	}else{
		pThis->GetWindowRect(&rt);
	}
	CRect rtFrom;
	if(iFrom!=0){
		pThis->GetDlgItem(iFrom)->GetWindowRect(&rtFrom);
	}else{
		pThis->GetWindowRect(&rtFrom);
	}
	rt.right=rt.left+rtFrom.Width();
	SetWindowSize(pThis, rt.Size(), dwControlID);
}

void SetTaskbarButton(HWND hWnd)
{
	::SetWindowLong(hWnd,GWL_EXSTYLE,WS_EX_APPWINDOW|::GetWindowLong(hWnd,GWL_EXSTYLE));
}

CFont* CreateFontFromStr(CString sSchValue, CString* pName, DWORD* dwBgColorOut, DWORD* dwTxColorOut, DWORD* dwAlphaOut, DWORD* dwAutoTransOut)
{
	CDataXMLSaver StyleData(sSchValue);
	CString sName="";
	StyleData.getValue("name",sName,pName?(*pName):"font-type");
	DWORD dwAlpha=0;
	StyleData.getValue("alpha",dwAlpha,dwAlphaOut?(*dwAlphaOut):100);
	DWORD dwAutoTrans=0;
	StyleData.getValue("autotrans",dwAutoTrans,dwAutoTransOut?(*dwAutoTransOut):0);
	DWORD dwTxtColor=0;
	StyleData.getValue("txtcolor",dwTxtColor,dwTxColorOut?(*dwTxColorOut):RGB(0,0,0));
	DWORD dwBgColor=0;
	StyleData.getValue("bgcolor",dwBgColor,dwBgColorOut?(*dwBgColorOut):RGB(255,255,255));
	CString sFontName="";
	StyleData.getValue("fontname",sFontName,"Arial");
	int iSize=0;
	StyleData.getValue("size",iSize,-27);
	DWORD dwWeight=0;
	StyleData.getValue("weight",dwWeight,400);
	int iCharset=0;
	StyleData.getValue("charset",iCharset,GetUserDefaultLangID()==0x0419?RUSSIAN_CHARSET:DEFAULT_CHARSET);
	CString sEffects;
	StyleData.getValue("effects",sEffects);
	BOOL bItalic=(sEffects.Find("i")!=-1);
	BOOL bUnderL=(sEffects.Find("u")!=-1);
	BOOL bStrike=(sEffects.Find("s")!=-1);
	CFont* font=new CFont();
	font->CreateFont(iSize,0,0,0,dwWeight,bItalic,bUnderL,bStrike,iCharset,OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,DEFAULT_QUALITY,DEFAULT_PITCH | FF_DONTCARE,sFontName);
	if(pName)
		*pName=sName;
	if(dwBgColorOut)
		*dwBgColorOut=dwBgColor;
	if(dwTxColorOut)
		*dwTxColorOut=dwTxtColor;
	if(dwAlphaOut)
		*dwAlphaOut=dwAlpha;
	if(dwAutoTransOut)
		*dwAutoTransOut=dwAutoTrans;
	return font;
}

CString CreateStrFromFont(CFont* pFont, CString sName, DWORD dwBgColorOut, DWORD dwTxColorOut, DWORD dwAlphaOut, DWORD dwAutoDisp, BOOL bInCuttedFormat)
{
	if(pFont==NULL){
		return "";
	}
	CString sSchValue;
	CDataXMLSaver StyleData(sSchValue,"",FALSE);
	//
	LOGFONT font;
	pFont->GetLogFont(&font);
	int PointSize=font.lfHeight;
	DWORD dwWeight=font.lfWeight;
	CString sEffects="";
	if(font.lfItalic>0){
		sEffects+="i";
	}
	if(font.lfUnderline>0){
		sEffects+="u";
	}
	if(font.lfStrikeOut>0){
		sEffects+="s";
	}
	if(sName!=""){
		StyleData.putValue("name",sName);
	}
	if(!bInCuttedFormat){
		StyleData.putValue("alpha",dwAlphaOut);
		StyleData.putValue("autotrans",dwAutoDisp);
		StyleData.putValue("txtcolor",dwTxColorOut);
		StyleData.putValue("bgcolor",dwBgColorOut);
	}
	StyleData.putValue("fontname",font.lfFaceName);
	StyleData.putValue("size",PointSize);
	StyleData.putValue("weight",dwWeight);
	StyleData.putValue("charset",font.lfCharSet);
	if(sEffects!=""){
		StyleData.putValue("effects",sEffects);
	}
	return StyleData.GetResult();
}

/*
����� ���� (����������� �����, ����� ������), ������� ��� ������ � ���. 
����� ���������� ��� ��� 1 ��.
����� ����, ��� ������������ �����. ����� ���������� ��� 1 pt.
������� �����, ������������ PostScript'��. �� ��������� �������� ���
�������� ����������. ����� ���������� ��� ��� 1 bp.


1 �� = 0,3759 ��.
1 �� = 2,66 ��
1 cc (������) = 12 ��.
1 ������� = 48 �� = 4 ������
1 pt = 1/72.27 in
1 pc (����) = 12 pt.
1 in = 2.54 ��.
1167 �� = 1238 pt.
1 bp = 1/72 in
*/
CString GetFontTextDsc(CFont* pFont)
{
	CString sOut=_l("Normal");
	if(pFont==NULL){
		return sOut;
	}
	LOGFONT font;
	pFont->GetLogFont(&font);
	DWORD lfHeight=font.lfHeight;
	if(font.lfHeight<0){
		//---------------------------
		lfHeight=-font.lfHeight;
		CDC dc;
		dc.CreateCompatibleDC(&GetScreenDC());
		dc.SetMapMode(MM_TEXT);
		lfHeight = MulDiv(lfHeight, 72, GetDeviceCaps(dc, LOGPIXELSY));
	}
	//+++++++++++++++++++++++++++
	sOut=Format("%s, %ipt",font.lfFaceName,lfHeight);
	if(font.lfWeight>400){
		sOut+=", "+_l("Bold");
	}
	if(font.lfItalic>0){
		sOut+=", "+_l("Italic");
	}
	if(font.lfUnderline>0){
		sOut+=", "+_l("Underline");
	}
	if(font.lfStrikeOut>0){
		sOut+=", "+_l("Strike");
	}
	return sOut;
}

CString GetFontTextDsc(CString sFont)
{
	CString sOut=_l("Normal");
	if(sFont==""){
		return sOut;
	}
	CString sSchValue;
	CDataXMLSaver StyleData(sFont);
	long lfHeight=0;
	StyleData.getValue("size",lfHeight,-27);
	long dwWeight=0;
	StyleData.getValue("weight",dwWeight,400);
	CString sFaceName;
	StyleData.getValue("fontname",sFaceName);
	CString sEffects;
	StyleData.getValue("effects",sEffects);
	if(lfHeight<0){
		//---------------------------
		lfHeight=-lfHeight;
		CDC dc;
		dc.CreateCompatibleDC(&GetScreenDC());
		dc.SetMapMode(MM_TEXT);
		lfHeight = MulDiv(lfHeight, 72, GetDeviceCaps(dc, LOGPIXELSY));
	}
	//+++++++++++++++++++++++++++
	sOut=Format("%s, %ipt",sFaceName,lfHeight);
	if(dwWeight>400){
		sOut+=", "+_l("Bold");
	}
	if(sEffects.Find("i")!=-1){
		sOut+=", "+_l("Italic");
	}
	if(sEffects.Find("u")!=-1){
		sOut+=", "+_l("Underline");
	}
	if(sEffects.Find("s")!=-1){
		sOut+=", "+_l("Strike");
	}
	return sOut;
}

BOOL GetTextBoundingRect(HDC    hDC,   // Reference DC
                           int    x,     // X-Coordinate
                           int    y,     // Y-Coordinate
                           LPSTR  lpStr, // The text string to evaluate
                           DWORD  dwLen, // The length of the string 
                           LPRECT lprc)  // Holds bounding rectangle
{
	LPPOINT lpPoints; 
	LPBYTE lpTypes;
	int i, iNumPts;
	
	// Draw the text into a path
	BeginPath(hDC);
	i = SetBkMode(hDC, TRANSPARENT);
	TextOut(hDC, x, y, lpStr, dwLen);
	SetBkMode(hDC, i);
	EndPath(hDC);
	
	// How many points are in the path
	iNumPts = GetPath(hDC, NULL, NULL, 0);
	if (iNumPts == -1) return FALSE;
	
	// Allocate room for the points
	lpPoints = (LPPOINT)GlobalAlloc(GPTR, sizeof(POINT) * iNumPts);
	if (!lpPoints) return FALSE;
	
	// Allocate room for the point types
	lpTypes = (LPBYTE)(GlobalAlloc(GPTR, iNumPts));
	if (!lpTypes) {
		GlobalFree(lpPoints);
		return FALSE;
	}
	
	// Get the points and types from the current path
	iNumPts = GetPath(hDC, lpPoints, lpTypes, iNumPts);
	
	// Even more error checking
	if (iNumPts == -1) {
		GlobalFree(lpTypes);
		GlobalFree(lpPoints);
		return FALSE;
	}
	
	// Initialize the rectangle
	SetRect(lprc, 0xFFFFF, 0xFFFFF, 0, 0);
	
	// Get the maximum/minimum extents from the path data
	for (i=0; i<iNumPts; i++) {
		if (lpPoints[i].x > lprc->right)  lprc->right  = lpPoints[i].x;
		if (lpPoints[i].y > lprc->bottom) lprc->bottom = lpPoints[i].y;
		if (lpPoints[i].x < lprc->left)   lprc->left   = lpPoints[i].x;
		if (lpPoints[i].y < lprc->top)    lprc->top    = lpPoints[i].y;
	}
	
	GlobalFree(lpTypes);
	GlobalFree(lpPoints);
	
	return TRUE;
}

typedef BOOL (STDAPICALLTYPE * _MakeSureDirectoryPathExists)(PCSTR);
class CDbgHelp
{
public:
	HINSTANCE hDll;
	_MakeSureDirectoryPathExists fpMakeSureDirectoryPathExists;
	CDbgHelp()
	{
		fpMakeSureDirectoryPathExists=0;
		hDll=LoadLibrary("dbghelp.dll");
		if(hDll){
			fpMakeSureDirectoryPathExists=(_MakeSureDirectoryPathExists)GetProcAddress(hDll,"MakeSureDirectoryPathExists");
		}
	}
	~CDbgHelp()
	{
		if(hDll){
			FreeLibrary(hDll);
		}
	}
};

CDbgHelp& _DbgHelp()
{
	static CDbgHelp obj;
	return obj;
}

BOOL CreateDirIfNotExist(const char* szFile)
{
	CString sKatalog=GetDirectoryFromPath(szFile);
	if(!isFileExist(sKatalog)){
		if(_DbgHelp().fpMakeSureDirectoryPathExists){
			return _DbgHelp().fpMakeSureDirectoryPathExists(sKatalog);
		}
		return ::CreateDirectory(sKatalog,NULL);
	}
	return TRUE;
}

CString GetDirectoryFromPath(const char* szFile)
{
	char szDisk[MAX_PATH]="",szPath[MAX_PATH]="";
	_splitpath(szFile,szDisk,szPath,NULL,NULL);
	CString sKatalog=szDisk;
	sKatalog+=szPath;
	return sKatalog;
}

CString GetFileFromPath(const char* szFile)
{
	char szName[MAX_PATH]="",szExt[MAX_PATH]="";
	_splitpath(szFile,NULL,NULL,szName,szExt);
	CString sFileName=szName;
	sFileName+=szExt;
	return sFileName;
}

BOOL AdoptSizeToScreen(CSize& size)
{
	static CRect rDesktopRECT(0,0,0,0);
	if(rDesktopRECT.IsRectEmpty()){
		SystemParametersInfo(SPI_GETWORKAREA,0,&rDesktopRECT,0);
	}
	if(size.cx>rDesktopRECT.Width()*0.8){
		size.cx=long(rDesktopRECT.Width()*0.8);
	}
	if(size.cy>rDesktopRECT.Height()*0.8){
		size.cy=long(rDesktopRECT.Height()*0.8);
	}
	return TRUE;
}

long SimpleCalc(const char* szExpr)
{
	CString sExpression=szExpr;
	sExpression.TrimLeft();
	sExpression.TrimRight();
	CString sNumber=sExpression.SpanIncluding("0123456789");
	sExpression=sExpression.Mid(strlen(sNumber));
	double dRes=atol(sNumber);
	while(strlen(sExpression)>0){
		char cOperation=sExpression.GetAt(0);
		sExpression=sExpression.Mid(1);
		sNumber=sExpression.SpanIncluding("0123456789");
		sExpression=sExpression.Mid(strlen(sNumber));
		switch(cOperation){
		case '+':
			dRes+=atol(sNumber);
			break;
		case '-':
			dRes-=atol(sNumber);
			break;
		case '*':
			dRes*=atol(sNumber);
			break;
		case '/':
			dRes=dRes/atol(sNumber);
			break;
		}
	}
	return long(dRes);
}

#define FORMENU_LEN	25
CString trimTextForMenu(CString sText)
{
	if(sText==""){
		return _L("<empty>");
	}
	CString sOut;
	int iStopPrefix=sText.Find(BMP_SPECPREFIX);
	if(iStopPrefix!=-1){
		sOut=sText.Left(iStopPrefix);
	}else{
		sOut=sText.Left(FORMENU_LEN*2);
	}
	sOut.TrimLeft();
	sOut.Replace("&",".");
	sOut.Replace("\t",".");
	sOut.Replace("\r\n",".");
	sOut.Replace("\n",".");
	return TrimMessage(sOut,FORMENU_LEN,1);
}

CString getBrowserExePath()
{
	static CString sDefaultBrowser=GetExtensionAssociatedAction("html","open");
	if(sDefaultBrowser==":("){
		return "";
	}
	if(sDefaultBrowser==""){
		sDefaultBrowser=":(";
		char szTempFile[MAX_PATH]="";
		if(GetTempFileName(GetUserFolder(),"DBR",time(NULL),szTempFile)!=0){
			CString sHtmlFile=szTempFile;
			sHtmlFile=sHtmlFile.SpanExcluding(".")+".htm";
			SaveFile(sHtmlFile,"<HTML></HTML>");
			char szBrFile[MAX_PATH]="";
			if(int(::FindExecutable(sHtmlFile,sHtmlFile,szBrFile))>32){
				sDefaultBrowser=szBrFile;
			}
			DeleteFile(sHtmlFile);
		}
	}
	return sDefaultBrowser;
}

/*CSIDL_COMMON_DOCUMENTS (0x002e)
CSIDL_COMMON_FAVORITES (0x001f)
CSIDL_DESKTOP 
CSIDL_MYDOCUMENTS*/

CString getDesktopPath()
{
	char szFolderBuffer[MAX_PATH]="";
	GetSpecialFolderPath(szFolderBuffer,CSIDL_DESKTOPDIRECTORY);
	return szFolderBuffer;
}

CString getMyDocPath()
{
	char szFolderBuffer[MAX_PATH]="";
	GetSpecialFolderPath(szFolderBuffer,CSIDL_PERSONAL);
	if(strlen(szFolderBuffer)==0){
		return "::{450D8FBA-AD25-11D0-98A8-0800361B1103}";
	}
	return szFolderBuffer;
}


CString getMyPicPath()
{
	char szFolderBuffer[MAX_PATH]="";
	GetSpecialFolderPath(szFolderBuffer,0x0036);// CSIDL_COMMON_PICTURES
	if(strlen(szFolderBuffer)==0){
		return getMyDocPath()+"\\Pictures";
	}
	return szFolderBuffer;
}

CString getEmailExePath()
{
	static CString sDefaultEmail="";
	if(sDefaultEmail==":("){
		return "";
	}
	if(sDefaultEmail==""){
		CRegKey key;
		sDefaultEmail=":(";
		key.Open(HKEY_LOCAL_MACHINE, "SOFTWARE\\Clients\\Mail\\");
		char szTemp[MAX_PATH]="";
		DWORD lSize = MAX_PATH,dwType=0;
		if(RegQueryValueEx(key.m_hKey,"",NULL, &dwType,(LPBYTE)szTemp, &lSize)== ERROR_SUCCESS){
			if(strlen(szTemp)>0){
				CString sNewKeysVal="Software\\Clients\\Mail\\";
				sNewKeysVal+=szTemp;
				sNewKeysVal+="\\Shell\\open\\command\\";
				CRegKey key2;
				key2.Open(HKEY_LOCAL_MACHINE, sNewKeysVal);
				lSize = MAX_PATH,dwType=0;
				if(RegQueryValueEx(key2.m_hKey,"",NULL, &dwType,(LPBYTE)szTemp, &lSize)== ERROR_SUCCESS){
					if(szTemp[0]!=0){
						sDefaultEmail=szTemp;
						if(sDefaultEmail.Left(1)=="\"" && sDefaultEmail.Right(1)=="\""){
							sDefaultEmail=sDefaultEmail.Mid(1,sDefaultEmail.GetLength()-2);
						}
					}
				}
			}
		}
		if(sDefaultEmail==":("){
			HKEY hkey;
			LONG lres = ::RegOpenKeyEx( HKEY_CLASSES_ROOT, _T("mailto\\shell\\open\\command"),0, KEY_READ, &hkey );
			if( lres == ERROR_SUCCESS ){
				DWORD dwType = 0, dwnBytes = MAX_PATH;
				_TCHAR buff[MAX_PATH] = {0};
				lres = ::RegQueryValueEx( hkey, NULL, 0, &dwType, (LPBYTE)buff, &dwnBytes );
				if( lres == ERROR_SUCCESS ){
					::RegCloseKey( hkey );
					if(buff[0]!=0){
						sDefaultEmail=buff;
					}
					int iLastp=sDefaultEmail.Find("%");
					if(iLastp!=-1){
						sDefaultEmail=sDefaultEmail.Left(iLastp);
					}
					sDefaultEmail.TrimLeft();
					sDefaultEmail.TrimRight();
				}
			}
		}
	}
	char szPathOut[MAX_PATH]="";
	strcpy(szPathOut,sDefaultEmail);
	DWORD dwDoEnv=DoEnvironmentSubst(szPathOut,sizeof(szPathOut));
	sDefaultEmail=szPathOut;
	return sDefaultEmail;
}

DWORD WINAPI RunDefaultEmailClient_InThread(LPVOID pData)
{
	long bRes=0;
	CString sDefaultEmail=getEmailExePath();
	if(strlen(sDefaultEmail)>0){
		DWORD dwStRes=(DWORD)::ShellExecute(NULL,"open",sDefaultEmail,NULL,NULL,SW_SHOWNORMAL);
		bRes=(dwStRes>32);
	}
	return bRes!=0;
}

BOOL RunDefaultEmailClient()
{
#ifdef FORK
	FORK(RunDefaultEmailClient_InThread,0);
#endif
	return TRUE;
}

CString MakeStandartLen(const char* szStr, int iLen, char c)
{
	CString sRes=szStr;
	if(sRes.GetLength()<iLen){
		sRes+=CString(c,iLen-sRes.GetLength());
	}else{
		sRes+=" ";
	}
	return sRes;
}

void ConvertComboDataToArray(const char* szData, CStringArray& aStrings, char c)
{
	CString sData=szData;
	CString sChar=c;
	sData.Replace(sChar,sChar+sChar);
	sData=sChar+sData+sChar;
	int iFrom=0;
	while(iFrom>=0){
		CString sLine=CDataXMLSaver::GetInstringPart(sChar,sChar,sData,iFrom);
		sLine.TrimLeft();
		sLine.TrimRight();
		if(sLine!=""){
			aStrings.Add(sLine);
		}
	}
}

CString ConvertArrayToString(CStringArray& aStrings, char c)
{
	CString sRes;
	int iLen=aStrings.GetSize();
	if(iLen){
		sRes=aStrings[0];
		for(int i=1;i<iLen;i++){
			sRes+=c;
			sRes+=aStrings[i];
		}
	}
	return sRes;
}

int GetIndexInArray(const char* szItem, CStringArray* pArray,BOOL bInstring)
{
	for(int i=0;i<pArray->GetSize();i++){
		if((!bInstring && pArray->GetAt(i)==szItem) || (bInstring && pArray->GetAt(i).Find(szItem)!=-1)){
			return i;
		}
	}
	return -1;
}

#ifdef __AFXCMN_H__
int AddComboBoxExItem(CComboBoxEx* pCombo, int iCount, const char* szText, int iIcon)
{
	if(pCombo==NULL){
		return -1;
	}
	int iComboCount=pCombo->GetCount();
	if(iComboCount==CB_ERR){
		return -1;
	}
	BOOL bSet=TRUE;
	if(iCount>=iComboCount){
		bSet=FALSE;// ������ �������� ��� ���
	}
	// ���������� � ���������
	COMBOBOXEXITEM pItem;
	pItem.mask=0;
	pItem.iItem=iCount;
	pItem.iIndent=0;
	pItem.lParam=0;
	if(szText!=NULL){
		pItem.pszText=(char*)szText;
		pItem.cchTextMax=strlen(szText);
		pItem.mask|=CBEIF_TEXT;
	}
	if(iIcon!=-1){
		pItem.mask|=CBEIF_IMAGE|CBEIF_SELECTEDIMAGE|CBEIF_OVERLAY;
		pItem.iOverlay=pItem.iSelectedImage=pItem.iImage=iIcon;
	}
	if(bSet){
		return pCombo->SetItem(&pItem);
	}else{
		return pCombo->InsertItem(&pItem);// ����� ������ ������!!! :(
	}
}
#endif

DWORD hexCode(const char* szRawValue)
{
	DWORD cRes;
	char szValue[3]="12";
	szValue[0]=szRawValue[0]>='a'?(szRawValue[0]-'a'+'A'):szRawValue[0];
	szValue[1]=szRawValue[1]>='a'?(szRawValue[1]-'a'+'A'):szRawValue[1];
	if (szValue[0]<='9')
		cRes=szValue[0]-'0';
	else
		cRes=10+szValue[0]-'A';
	cRes=cRes*16;
	if (szValue[1]<='9')
		cRes+=szValue[1]-'0';
	else
		cRes+=10+szValue[1]-'A';
	return cRes;
}

DWORD GetRGBFromHTMLString(CString sRGB)
{
	if(sRGB==""){
		return 0;
	}
	if(sRGB[0]!='#' || sRGB.GetLength()!=7){
		return atol(sRGB);
	}
	DWORD dwRes=RGB(hexCode(sRGB.Mid(1,2)),hexCode(sRGB.Mid(3,2)),hexCode(sRGB.Mid(5,2)));
	return dwRes;
}

void AddToDebugLog(const char* szText)
{
	COleDateTime dtNow=COleDateTime::GetCurrentTime();
	CString sTime=Format("%02lu.%02lu.%04lu&nbsp;%02lu:%02lu.%02lu (%lu)",dtNow.GetDay(),dtNow.GetMonth(),dtNow.GetYear(),dtNow.GetHour(),dtNow.GetMinute(),dtNow.GetSecond(),GetTickCount());
	CString sLog=sTime+"\t"+szText+"\r\n";
	CString sLogFile=Format("c:\\%s_debug.log",GetApplicationName());
	FILE* fLog=fopen(sLogFile,"a+");
	if(fLog){
		fprintf(fLog,"%s",sLog);
		fclose(fLog);
	}
}

CString GetRandomString(int iLen)
{
	char* szBuffer=new char[iLen+1];
	szBuffer[iLen]=0;
	for(int i=0;i<iLen;i++){
		szBuffer[i]=rnd('A','Z');
	}
	CString sRes=szBuffer;
	delete[] szBuffer;
	return sRes;
}

CString GetExtensionAssociatedAction(const char* szExt, const char* szAction)
{
	CString sAction=szAction;
	sAction.MakeLower();
	CString sExt=".";
	sExt+=szExt;
	sExt.MakeLower();
	CRegKey key;
	key.Open(HKEY_CLASSES_ROOT, sExt);
	char szTemp[MAX_PATH]="";
	DWORD lSize = MAX_PATH,dwType=0;
	if(RegQueryValueEx(key.m_hKey,"",NULL, &dwType,(LPBYTE)szTemp, &lSize)== ERROR_SUCCESS){
		CString sFileTypeName=szTemp;
		CRegKey key2;
		dwType=0;
		szTemp[0]=0;
		lSize = MAX_PATH;
		key2.Open(HKEY_CLASSES_ROOT, sFileTypeName+"\\shell\\"+sAction+"\\Command");
		if(RegQueryValueEx(key2.m_hKey,"",NULL, &dwType,(LPBYTE)szTemp, &lSize)== ERROR_SUCCESS){
			CString sRes=szTemp;
			if(sRes!=""){
				int iKPos=sRes.Find('\"',1);
				if(iKPos!=-1){
					sRes=sRes.Left(iKPos);
					if(sRes.Left(1)=="\""){
						sRes=sRes.Mid(1);
					}
				}else{
					sRes=sRes.SpanExcluding(" ");
				}
				sRes.TrimLeft();
				sRes.TrimRight();
			}
			CString sProhibitedHandlers=sRes;
			sProhibitedHandlers.MakeLower();
			if(sProhibitedHandlers=="rundll32.exe"){
				sRes="";
			}
			return sRes;
		}
	}
	return "";
}

BOOL FindFullPathToFile(CString& sCommand)
{
	if(isFileExist(sCommand)){
		return TRUE;
	}
	char szFullPath[MAX_PATH]="";
	strcpy(szFullPath,sCommand);
	if(_Shlwapi().fpFind!=NULL){
		if(_Shlwapi().fpFind(szFullPath,NULL)){
			sCommand=szFullPath;
			return TRUE;
		}
	}
	return FALSE;
}

BOOL FindFullPathToExecutable(CString& sCommand)
{
	char szPathOut[MAX_PATH]="";
	strcpy(szPathOut,sCommand);
	DWORD dwDoEnv=DoEnvironmentSubst(szPathOut,sizeof(szPathOut));
	if(HIWORD(dwDoEnv)>0){
		sCommand=szPathOut;
	}
	if(FindFullPathToFile(sCommand)){
		return TRUE;
	}
	CString sRes;
	sRes=sCommand+".exe";
	if(FindFullPathToFile(sRes)){
		sCommand=sRes;
		return TRUE;
	}
	sRes=sCommand+".com";
	if(FindFullPathToFile(sRes)){
		sCommand=sRes;
		return TRUE;
	}
	sRes=sCommand+".bat";
	if(FindFullPathToFile(sRes)){
		sCommand=sRes;
		return TRUE;
	}
	sRes=sCommand+".cmd";
	if(FindFullPathToFile(sRes)){
		sCommand=sRes;
		return TRUE;
	}
	return FALSE;
}

BOOL ParseForShellExecute(CString sFrom, CString& sCommand, CString& sParameter, BOOL bPartialFindIsOK)
{
	BOOL bRes=FALSE;
	sFrom.TrimLeft(" ");
	sFrom.TrimRight(" ");
	sCommand=sFrom;
	sParameter="";
	// ������� - ����� ����� ���������+��������
	int iKPos=sFrom.Find(' ',1);
	if(sFrom.Left(1)=='\"'){
		iKPos=sFrom.Find('\"',1);
	}
	if(iKPos!=-1){
		iKPos++;
		sCommand=sFrom.Left(iKPos);
		sParameter=sFrom.Mid(iKPos);
		sParameter.TrimLeft(" ");
		sParameter.TrimRight(" ");
		sCommand.TrimLeft(" \"");
		sCommand.TrimRight(" \"");
		if(FindFullPathToExecutable(sCommand)){
			bRes=TRUE;
		}else if(!bPartialFindIsOK){
			// ������ �� �������
			// ������������ � ������
			sCommand=sFrom;
			sParameter="";
		}
	}
	if(IsConsoleApplication(sCommand) || IsBatFile(sCommand)){
		sParameter=Format("/T:0A /K \"%s %s\"",sCommand,sParameter);
		sCommand="cmd.exe";
		return TRUE;
	}
	return bRes;
}

BOOL IsBatFile(const char* szCommand)
{
	CString sFile=szCommand;
	sFile.MakeLower();
	if(sFile.Find(".bat")!=-1){
		return TRUE;
	}
	if(sFile.Find(".cmd")!=-1){
		return TRUE;
	}
	return FALSE;
}

BOOL IsConsoleApplication(const char* szFile)
{
	if(IsBatFile(szFile)){
		return TRUE;
	}
	FILE* pFile=fopen(szFile,"rb");
	if(pFile){
		IMAGE_DOS_HEADER headDOS;
		memset(&headDOS,0,sizeof(headDOS));
		fread(&headDOS,1,sizeof(headDOS),pFile);
		fseek(pFile,headDOS.e_lfanew,SEEK_SET);
		IMAGE_NT_HEADERS headNT;
		memset(&headNT,0,sizeof(headNT));
		fread(&headNT,1,sizeof(headNT),pFile);
		fclose(pFile);
		if(headNT.OptionalHeader.Subsystem==IMAGE_SUBSYSTEM_WINDOWS_CUI){
			return TRUE;
		}
	}
	return FALSE;
}

CString SetTextForUpdateTipText(CString sText, int iMaxLines, BOOL bTrimEnters)
{
	CString sOut;
	CString sOutFull=TrimMessage(sText,1000,0);
	sOutFull.Replace("\r","");
	// ������� ������������� ������ ������
	int iLines=0;
	while(1){
		BOOL bNeedAdd=0;
		CString sLine=sOutFull.SpanExcluding("\n");
		if(sLine.GetLength()>0){
			sOutFull=sOutFull.Mid(sLine.GetLength()+((sLine.GetLength()<sOutFull.GetLength())?1:0));
		}else if(sOutFull.GetLength()>0 && sOutFull.GetAt(0)=='\n'){
			sOutFull=sOutFull.Mid(1);
		}
		if(bTrimEnters){
			sLine.TrimLeft();
			sLine.TrimRight();
		}
		if(iMaxLines>0 && iLines<iMaxLines){
			if(!bTrimEnters){
				bNeedAdd=TRUE;
			}else if(sLine.GetLength()>0){
				bNeedAdd=TRUE;
			}
		}else{
			sOutFull="";
			sLine="< "+_l("skipped")+" >";
			bNeedAdd=TRUE;
		}
		if(bNeedAdd){
			if(sOut.GetLength()>0){
				sOut+="\n";
			}
			sOut+=sLine;
			iLines++;
		}
		if(sOutFull==""){
			break;
		}
	}
	return sOut;
}

CString GetReadableStringFromMinutes(DWORD dwMinutes)
{
	CString sOut;
	DWORD dwHour=dwMinutes/60;
	DWORD dwMin=dwMinutes%60;
	if(dwHour>0){
		sOut+=Format("%lu%s ",dwHour,_l("h."));
	}
	if(dwMin>0){
		sOut+=Format("%lu%s",dwMin,_l("m."));
	}
	return sOut;
}

BOOL IsClsidInstalled(const char* szClsid)
{
	CString sKeyName="\\CLSID\\{";
	sKeyName+=szClsid;
	sKeyName+="}";
	CRegKey key;
	key.Open(HKEY_CLASSES_ROOT, sKeyName);
	if(key!=NULL){
		return TRUE;
	}
	return FALSE;
}

BOOL IsDefaultDesktop(CString* sDeskName)
{
	if(sDeskName){
		*sDeskName="";
	}
	CString WinVer;
	DWORD dwMajor=0;
	long bNT=0;
	if(GetOSVersion(WinVer, &dwMajor, &bNT) && bNT){
		HDESK hD=GetThreadDesktop(GetCurrentThreadId());
		char szDeskName[250]="";
		DWORD dwLen=sizeof(szDeskName);
		if(GetUserObjectInformation(hD,UOI_NAME,szDeskName,sizeof(szDeskName),&dwLen)){
			if(sDeskName){
				*sDeskName=szDeskName;
			}
			if(stricmp(szDeskName,"Default")!=0){
				return FALSE;
			}
		}
	}
	return TRUE;
}

#include <mmsystem.h>
#pragma comment(lib,"winmm.lib")
void AsyncPlaySoundSys(const char* szSoundName)
{
	::PlaySound(szSoundName, NULL, SND_ALIAS | SND_NODEFAULT | SND_ASYNC | SND_NOWAIT);
	//::PlaySound(szSoundName, NULL, SND_ALIAS | SND_NODEFAULT );
}

#define ID_SIZE 30
#include <sys/timeb.h>
CString GenerateNewId(const char* szPrefix,const char* szPostfix)
{
	CString sRes;
	struct _timeb tstruct;
	_ftime(&tstruct);
	sRes.Format("%s%sI%02lxR%02x",szPrefix,szPostfix,WORD(rnd(0,0xFF)),(WORD)tstruct.millitm);
	if(strlen(sRes)>ID_SIZE){
		sRes=sRes.Left(ID_SIZE);
	}
	sRes.MakeUpper();
	return sRes;
};

CString GetRegString(HKEY& hOpenedKey, const char* szKeyName, DWORD dwMaxSize)
{
	DWORD lSize=dwMaxSize+1;
	char szValue[3*MAX_PATH]={0};
	DWORD dwType=REG_SZ;
	if(RegQueryValueEx(hOpenedKey,szKeyName,0,&dwType,(LPBYTE)szValue,&lSize)!=ERROR_SUCCESS){
		dwType=REG_EXPAND_SZ;
		szValue[0]=0;
		RegQueryValueEx(hOpenedKey,szKeyName,0,&dwType,(LPBYTE)szValue,&lSize);
	}
	CString sOut=szValue;
	return sOut;
}


CSysCurBlinker::CSysCurBlinker(UINT hCursorFromRes, DWORD dwMinTime)
{
	hBackup=NULL;
	m_dwMinTime=dwMinTime;
	m_dwCurTime=GetTickCount();
	if(hCursorFromRes!=NULL){
		HCURSOR hCur=LoadCursor(AfxGetApp()->m_hInstance,MAKEINTRESOURCE(hCursorFromRes));
		if(hCur){
			hBackup=CopyCursor(LoadCursor(NULL,MAKEINTRESOURCE(IDC_ARROW)));
			hBackup2=CopyCursor(LoadCursor(NULL,MAKEINTRESOURCE(IDC_IBEAM)));
			SetSystemCursor(CopyCursor(hCur), 32512/*IDC_ARROW*/);
			SetSystemCursor(CopyCursor(hCur), 32513/*IDC_IBEAM*/);
		}
		DestroyCursor(hCur);
	}
}

CSysCurBlinker::~CSysCurBlinker()
{
	BOOL bRes=0;
	if(hBackup && hBackup2){
		if(m_dwMinTime>0 && GetTickCount()-m_dwCurTime<m_dwMinTime){
			Sleep(m_dwMinTime-(GetTickCount()-m_dwCurTime));
		}
		bRes=SetSystemCursor(CopyCursor(hBackup), 32512);
		bRes=SetSystemCursor(CopyCursor(hBackup2), 32513);
	}
}

void AttachToWindowQueue(HWND hWin, BOOL bType)
{
	DWORD dwCurWinProcID=0;
	DWORD dwCurWinThreadID=GetWindowThreadProcessId(hWin,&dwCurWinProcID);
	DWORD dwThisThread=GetCurrentThreadId();
	DWORD dwThisProcess=GetCurrentProcessId();
	AttachThreadInput(dwThisThread,dwCurWinThreadID,bType);
}

void ShowFileProps(const char* szFile)
{
	SHELLEXECUTEINFO sei;
	ZeroMemory(&sei,sizeof(sei));
	sei.cbSize = sizeof(sei);
	sei.lpFile = szFile;
	sei.lpVerb = "properties";
	sei.fMask = SEE_MASK_INVOKEIDLIST;
	BOOL bRes=::ShellExecuteEx(&sei);
}

#include <shlobj.h>
#include <atlbase.h>
void ShowContextMenu(HWND hWnd, LPCTSTR pszPath, int x, int y)
{
   USES_CONVERSION;

   // ������ ������ ��� �����/��������
   TCHAR tchFullPath[MAX_PATH];
   GetFullPathName(pszPath, sizeof(tchFullPath)/sizeof(TCHAR), tchFullPath, NULL);

   // �������� ��������� IShellFolder �������� �����
   IShellFolder *pDesktopFolder;
   SHGetDesktopFolder(&pDesktopFolder);

   // ����������� �������� ���� � LPITEMIDLIST
   LPITEMIDLIST pidl;
   pDesktopFolder->ParseDisplayName(hWnd, NULL, T2OLE(tchFullPath), NULL, &pidl, NULL);

   // ���� ��������� ������������� � ���������� ������ pidl
   LPITEMIDLIST pLastId = pidl;
   USHORT temp;
   while(1)
   {
       int offset = pLastId->mkid.cb;
       temp = *(USHORT*)((BYTE*)pLastId + offset);

       if(temp == 0)
           break;

       pLastId = (LPITEMIDLIST)((BYTE*)pLastId + offset);
   }
   
   // �������� ��������� IShellFolder ������������� ������� ��� ��������� �����/��������
   // ����������: ������������ ������� ���������������� ������� pidl �� ������� ����������
   //             ��������, ������� �� �������� �������� pLastId->mkid.cb, ������� ��� �� ������
   temp = pLastId->mkid.cb;
   pLastId->mkid.cb = 0;
   IShellFolder *pFolder;
   pDesktopFolder->BindToObject(pidl, NULL, IID_IShellFolder, (void**)&pFolder);

   // �������� ��������� IContextMenu ��� ��������� �����/��������
   // ����������: ������������ ������������� ������� �������� ����/������� ����������������
   //             ������������ ��������� pLastId
   pLastId->mkid.cb = temp;
   IContextMenu *pContextMenu;
   pFolder->GetUIObjectOf(
      hWnd, 1, (LPCITEMIDLIST *)&pLastId, IID_IContextMenu, NULL, (void**)&pContextMenu);

   // ������ ����
   HMENU hPopupMenu = CreatePopupMenu();

   // ��������� ����
   pContextMenu->QueryContextMenu(hPopupMenu, 0, 1, 0x7FFF, 0);

   // ���������� ����
   UINT nCmd = TrackPopupMenu(hPopupMenu,
      TPM_LEFTALIGN|TPM_LEFTBUTTON|TPM_RIGHTBUTTON|TPM_RETURNCMD|0x0001L/*TPM_RECURSE*/, x, y, 0, hWnd, 0);

   // ��������� ������� (���� ��� ���� �������)
   if(nCmd)
   {
      CMINVOKECOMMANDINFO ici;
      ZeroMemory(&ici, sizeof(CMINVOKECOMMANDINFO));
      ici.cbSize = sizeof(CMINVOKECOMMANDINFO);

      ici.hwnd = hWnd;
      ici.lpVerb = MAKEINTRESOURCE(nCmd-1);
      ici.nShow = SW_SHOWNORMAL;

      pContextMenu->InvokeCommand(&ici);
   }

   // �������� ��������� IMalloc
   IMalloc *pMalloc;
   SHGetMalloc(&pMalloc);

   // ����������� ������, ���������� ��� pidl
   pMalloc->Free(pidl);

   // ����������� ��� ���������� ����������
   pDesktopFolder->Release();
   pFolder->Release();
   pContextMenu->Release();
   pMalloc->Release();
   return;
}

DWORD GetFileChecksum(CString m_strFilePath)
{
	HANDLE hf;
	DWORD dwBuffer[4096];
	DWORD dwRead;
	ULONGLONG uhCount;
	
	uhCount = 3 & 0xFFFFFFFFFFFFFFFC; // Make 4 multiple and get ceil
	DWORD m_uhFileSize=GetFileSize(m_strFilePath);
	DWORD m_uhChecksumBytes = 0;
	DWORD m_dwChecksum=0;
	
	
	// Not all bytes summed
	hf = CreateFile(m_strFilePath, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, 
		FILE_FLAG_SEQUENTIAL_SCAN, NULL);
	SetFilePointer(hf, m_uhChecksumBytes, (PLONG) &dwRead, FILE_BEGIN);
	while((m_uhChecksumBytes<uhCount) &&  // Bytes pending
		(ReadFile(hf, dwBuffer, MIN(sizeof(dwBuffer), (DWORD) uhCount), &dwRead, NULL)) &&
		(dwRead>0))
	{
		// Calc checksum for buffer
		for (UINT i=0;i<(dwRead >> 2);i++) {
            m_dwChecksum += dwBuffer[i];
		}
		if (dwRead & 0x3){
            // Calc Checksum of last dword padding with zeroes
            m_dwChecksum += dwBuffer[(dwRead >> 2)] & (0xFFFFFFFF >> ((4-(dwRead & 0x3)) << 3));
		}
		m_uhChecksumBytes += dwRead;
	}
	CloseHandle(hf);
	return m_dwChecksum;
}

BOOL isWin98()
{
	//return 1;
	static long bWin98=-1;
	if(bWin98==-1){
		long bWinNT=0;
		CString sOS;
		GetOSVersion(sOS,NULL,&bWinNT);
		if(bWinNT){
			bWin98=FALSE;
		}else{
			bWin98=TRUE;
		}
	}
	return bWin98;
}

BOOL isWinXP()
{
	//return 1;
	static long bWinXP=-1;
	if(bWinXP==-1){
		long bWinNT=0;
		CString sOS;
		DWORD dwMaj=0;
		GetOSVersion(sOS,&dwMaj,&bWinNT);
		if(sOS.Find("XP")!=-1 || sOS.Find("Server")!=-1 || dwMaj>5){
			bWinXP=TRUE;
		}else{
			bWinXP=FALSE;
		}
	}
	return bWinXP;
}

#include <Cderr.h>
BOOL SaveFileFromHGlob(CString& sSavingPath,CString& szLastPathToSaveTo,HGLOBAL& hGlob,DWORD dwSize,BOOL bNeedDialog,DWORD dwOffset, CWnd* pParent)
{
	if(!pParent){
		pParent=GetAppWnd();
	}
	if(bNeedDialog){
		MakeSafeFileName(sSavingPath);
		sSavingPath=szLastPathToSaveTo+sSavingPath;
		CFileDialog dlg(FALSE, NULL, sSavingPath, 0, "All files (*.*)|*.*||", pParent);
		DWORD dwRes=dlg.DoModal();
		CFileDialog* pResDlg=&dlg;
		if(dwRes!=IDOK){
			DWORD dwErr=CommDlgExtendedError();
			if(dwErr==FNERR_INVALIDFILENAME){
				CFileDialog dlg2(FALSE, NULL, NULL, 0, "All files (*.*)|*.*||", pParent);
				dwRes=dlg2.DoModal();
				if(dwRes==IDOK){
					sSavingPath=dlg2.GetPathName();
				}
			}
		}else{
			sSavingPath=dlg.GetPathName();
		}
		if(dwRes!=IDOK){
			// ������� CANCEL ��� ������
			DWORD dwErr=CommDlgExtendedError();
			return dwErr==0?TRUE:FALSE;
		}
		char szDrive[MAX_PATH]="C:\\",szDir[MAX_PATH]="";
		_splitpath(sSavingPath, szDrive, szDir, NULL, NULL);
		szLastPathToSaveTo.Format("%s%s",szDrive,szDir);
	}
	DWORD dwAttribs=GetFileAttributes(sSavingPath);
	if(dwAttribs!=0xffffffff){
		// ���� ����������!
		if(bNeedDialog && pParent->MessageBox(_L("Overwrite existing file")+"?",NULL,MB_YESNO)!=IDYES){
			return TRUE;
		}
		// �������...
		DeleteFile(sSavingPath);
	}
	HANDLE hf = CreateFile(sSavingPath, GENERIC_WRITE, (DWORD) 0, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, (HANDLE) NULL);
	if (hf == INVALID_HANDLE_VALUE){
		return FALSE;
	}
	BOOL bRes=TRUE;
	DWORD dwWritten=0;
	char* pData=(char*)::GlobalLock(hGlob)+dwOffset;
	if (!WriteFile(hf, pData, dwSize, (LPDWORD) &dwWritten,  NULL)){
		bRes=FALSE;
	}
	if (!CloseHandle(hf)){
		bRes=FALSE;
	}
	if(dwWritten!=dwSize){
		bRes=FALSE;
	}
	::GlobalUnlock(hGlob);
	return bRes;
}

size_t mymemcpy(char* pTo, const char* pFrom, size_t howMuch)
{
	if(howMuch==0){
		pTo[0]=0;
		return 0;
	}
	ZeroMemory(pTo,howMuch);
	if(strlen(pFrom)<howMuch){
		memcpy(pTo,pFrom,strlen(pFrom));
	}else{
		memcpy(pTo,pFrom,howMuch);
	}
	return howMuch;
}

int GetWindowMenuHeight(CWnd* m_pMain)
{
	int iMenuH=0;
	if(m_pMain->GetMenu()){
		_MENUBARINFO pmbi;
		memset(&pmbi,0,sizeof(pmbi));
		pmbi.cbSize=sizeof(pmbi);
		static HINSTANCE hUser32=HINSTANCE(-1);
		if(hUser32==HINSTANCE(-1)){
			hUser32=GetModuleHandle("user32.dll");
		}
		if(hUser32){
			static _GetMenuBarInfo fp=_GetMenuBarInfo(-1);
			if(fp==_GetMenuBarInfo(-1)){
				fp=(_GetMenuBarInfo)GetProcAddress(hUser32,"GetMenuBarInfo");
			}
			if(fp){
				(*fp)(m_pMain->m_hWnd,0xFFFFFFFD,0,&pmbi);//OBJID_MENU
				iMenuH=(pmbi.rcBar.bottom-pmbi.rcBar.top);
			}
		}
	}
	return iMenuH;
}


CString GetRandomName()
{
	static const char* szSogl="BCDEFGHKLMNPQRSTVWXYZ";
	static const char* szGl="EUIOA";
	const char* szCur=rnd(1,100)<75?szSogl:szGl;
	int iLen=rnd(3,7);
	CString sRes="";
	for(int i=0;i<iLen;i++){
		sRes+=szCur[rnd(0,strlen(szCur)-1)];
		if(rnd(0,100)<(szCur==szSogl?85:95)){
			if(szCur==szSogl){
				szCur=szGl;
			}else{
				szCur=szSogl;
			}
		}
	}
	CString sOut=sRes;
	sOut.MakeLower();
	sOut.SetAt(0,sRes[0]);
	return sOut;
}

int GetNearestStr(const char* szFrom, int iStartFrom, const char* szParts[], int* iIndex)
{
	int iRes=-1, i=0;
	const char* szSearchBase=szFrom+iStartFrom;
	while(szParts[i]!=0){
		const char* szFinded=strstr(szSearchBase,szParts[i++]);
		if(szFinded && szFinded-szSearchBase>iRes){
			iRes=szFinded-szSearchBase;
			if(iIndex){
				*iIndex=i;
			}
		}
	}
	return iRes>=0?(iRes+iStartFrom):iRes;
}

CString AddPathExtension(const char* szPath, const char* szExt)
{
	CString sRes=szPath;
	if(szExt!=0){
		if(size_t(sRes.GetLength())>strlen(szExt)){
			if(sRes.Right(strlen(szExt)).CompareNoCase(szExt)!=0){
				sRes+=szExt;
			}
		}
	}
	return sRes;
}

CString AppendPaths(CString sPath1, CString sPath2)
{
	sPath2.TrimLeft("\\/");
	return AddPathExtension(sPath1,"\\")+sPath2;
}

CString& AppCommandLine()
{
	static CString s="";
	static BOOL bInit=0;
	if(bInit==0){
		bInit=1;
		s=GetCommandLine();
		// ���������� ������?
		HKEY hKey = NULL;
		// form the registry key path
		CString sAddCLine;
		CString keyPath = "SOFTWARE\\WiredPlane\\";
		keyPath+=GetApplicationName();
		LONG lRet = RegOpenKeyEx(HKEY_CURRENT_USER, keyPath,0,KEY_READ, &hKey);
		if (lRet != ERROR_SUCCESS){
			lRet = RegOpenKeyEx(HKEY_LOCAL_MACHINE, keyPath,0,KEY_READ, &hKey);
		};
		if (lRet == ERROR_SUCCESS) {
			LPSTR   lpCLine   = sAddCLine.GetBuffer( 1024 );
			DWORD   dwSize   = 1023;
			// Read the "BuyURL" value from the registry key.
			RegQueryValueEx(hKey, "CommandLine",0, NULL, (LPBYTE)lpCLine, &dwSize);
			sAddCLine.ReleaseBuffer();
			RegCloseKey( hKey);
			s+=" ";
			s+=lpCLine;
		}
	}
	return s;
}

int FindSubstrWithVolatilePP(CString& sCML,const char* sPML,const char* szPrefixes,const char* szPostFixes)
{
	char szTmp[2];
	szTmp[1]=0;
	char const* szPrefPos=szPrefixes;
	char const* szPostPos=szPostFixes;
	while(*szPrefPos){
		while(*szPostPos){
			szTmp[0]=*szPrefPos;
			CString sLookingFor=szTmp;
			sLookingFor+=sPML;
			szTmp[0]=*szPostPos;
			sLookingFor+=szTmp;
			int iPos=sCML.Find(sLookingFor);
			if(iPos!=-1){
				return iPos;
			}
			szPostPos++;
		}
		szPrefPos++;
	}
	return -1;
}

BOOL GetCommandLineParameter(CString sName, CString& sValue, BOOL bAllowExpandFromFile)
{
	sValue="";
	CString sCM=AppCommandLine()+" ";
	CString sCML=sCM,sPML=sName;
	sCML.MakeLower();
	sPML.MakeLower();
	int iPos=FindSubstrWithVolatilePP(sCML,sPML,"-\\/#$@","= ");
	if(iPos==-1){
		return 0;
	}
	CString sRawParamValue=sCM.Mid(iPos+strlen(sName)+1);
	if(sRawParamValue==""){
		return 1;
	}
	if(sRawParamValue[0]=='='){
		sRawParamValue=sRawParamValue.Mid(1);
	}
	if(sRawParamValue==""){
		return 1;
	}
	if(sRawParamValue[0]=='\"'){
		sValue=sRawParamValue.Mid(1).SpanExcluding("\"");
	}else{
		sValue=sRawParamValue.SpanExcluding(" ");
	}
	if(bAllowExpandFromFile && sValue!="" && sValue[0]=='@'){
		CString sContent;
		CString sFile=sValue.Mid(1);
		if(sFile.Find("\\")==-1){
			sFile=CString(GetApplicationDir())+sFile;
		}
		ReadFile(sFile,sContent);
		sValue=sContent;
	}
	return 1;
}


#include "Shlwapi.h"
CString MakeRelativePath(const char* szFullPath,const char* szBasePath)
{
	char szOut[MAX_PATH] = "";
	if(_Shlwapi().fpMakeRelPath){
		if(_Shlwapi().fpMakeRelPath(szOut,szBasePath,FILE_ATTRIBUTE_DIRECTORY,szFullPath,FILE_ATTRIBUTE_NORMAL)){
			return szOut;
		}
	}
	return szFullPath;
}

//dd.mm.yy hh:24.ss
COleDateTime StringToTime(CString sTime)
{
	COleDateTime dtRes;
	if(sTime.GetLength()==17){
		int iY=0,iM=0,iD=0,ih=0,im=0,is=0;
		iD=atol(sTime.Mid(0,2));
		iM=atol(sTime.Mid(3,2));
		iY=2000+atol(sTime.Mid(6,2));
		ih=atol(sTime.Mid(9,2));
		im=atol(sTime.Mid(12,2));
		is=atol(sTime.Mid(15,2));
		dtRes.SetDateTime(iY,iM,iD,ih,im,is);
	}
	return dtRes;
}

BOOL DeleteFileUsingRBin(const char* sPath)
{
	SHFILEOPSTRUCT str;
	memset(&str,0,sizeof(str));
	str.hwnd=0;
	str.wFunc=FO_DELETE;
	char szPath[MAX_PATH+2]="";
	memset(&szPath,0,sizeof(szPath));
	strcpy(szPath,sPath);
	str.pFrom=szPath;
	str.pTo=NULL;
	str.fFlags=FOF_ALLOWUNDO|FOF_NOCONFIRMATION|FOF_SILENT;
	if(SHFileOperation(&str)!=0){
		return 0;
	}
	return 1;
}

BOOL IsFileInZip(const char* szFile)
{
	CString sURI=szFile;
	sURI.MakeLower();
	if(strstr(sURI,".zip\\")!=NULL
		|| strstr(sURI,".wsc\\")!=NULL){
		return TRUE;
	}else{
		return FALSE;
	}
}

BOOL IsFileURL(const char* szFile)
{
	CString sURI=szFile;
	sURI.MakeLower();
	if(strstr(sURI,".htm")!=NULL
		|| strstr(sURI,"http://")!=NULL
		|| strstr(sURI,"https://")!=NULL
		|| strstr(sURI,"file://")!=NULL
		|| strstr(sURI,"ftp://")!=NULL){
		return TRUE;
	}else{
		return FALSE;
	}
}

BOOL IsFileHTML(const char* szFile)
{
	CString sURI=szFile;
	sURI.MakeLower();
	if(strstr(sURI,".jpg")!=NULL
		|| strstr(sURI,".gif")!=NULL
		|| strstr(sURI,".bmp")!=NULL){
		return FALSE;
	}
	return IsFileURL(sURI);
}

CString GetPathPart(const char* szFile, BOOL bD,BOOL bP,BOOL bN,BOOL bE)
{
	char szD[MAX_PATH]={0},szP[MAX_PATH]={0},szN[MAX_PATH]={0},szE[MAX_PATH]={0};
	_splitpath(szFile,szD,szP,szN,szE);
	CString sRes;
	if(bD){
		sRes+=szD;
	}
	if(bP){
		sRes+=szP;
	}
	if(bN){
		sRes+=szN;
	}
	if(bE){
		sRes+=szE;
	}
	return sRes;
}

BOOL& IsAppStopping()
{
	static BOOL bStopping=0;
	return bStopping;
}

CString GetNextPrefixedId(CString sKey,int iIndex)
{
	int iCount=iIndex;
	if(iIndex==-1){
		if(sKey.GetLength()>0 && sKey[0]=='['){
			iCount=atol(sKey.Mid(1))+1;
		}else{
			iCount=1;
		}
	}
	if(iCount==0){
		return sKey;
	}
	int iPos=sKey.Find("]");
	if(iPos!=-1){
		sKey=sKey.Mid(iPos+1);
	}
	return Format("[%i]%s",iCount,sKey);
}

BOOL IsWindowsSystemWnd(HWND hWin)
{
	char szClass[128]="";
	BOOL bClassRes=::GetClassName(hWin,szClass,sizeof(szClass));
	if(bClassRes>0){
		if(stricmp(szClass,"SHELLDLL_DefView")==0 
			|| stricmp(szClass,"WK_MAIN")==0 
			|| stricmp(szClass,"Progman")==0 
			|| stricmp(szClass,"SysTabControl32")==0 
			|| stricmp(szClass,"TrayNotifyWnd")==0 
			|| stricmp(szClass,"Shell_TrayWnd")==0 
			|| stricmp(szClass,"WorkerW")==0 || stricmp(szClass,"WorkerA")==0
			|| stricmp(szClass,"FakeDesktopWClass")==0 || stricmp(szClass,"FakeDesktopAClass")==0
			|| stricmp(szClass,"tooltips_class32")==0
			|| stricmp(szClass,"GLBSWizard")==0
			|| stricmp(szClass,"SysFader")==0){
			return TRUE;
		}
		char szTitle[128]="";
		BOOL bTitleRes=::GetWindowText(hWin,szTitle,sizeof(szTitle));
		if(bTitleRes>0){
			if(stricmp(szTitle,"MCI command handling window")==0 ||
				stricmp(szTitle,"MM Notify Callback")==0 ||
				stricmp(szTitle,"DDE Server Window")==0 ||
				stricmp(szTitle,"Program Manager")==0 ||
				strstr(szTitle,"OleMainThread")!=0){
				return TRUE;
			}
		}
	}
	HWND hParent=GetParent(hWin);
	return hParent?IsWindowsSystemWnd(hParent):FALSE;
}

BOOL isPressed(UINT iKey)
{
	if(iKey==VK_SHIFT && ::GetAsyncKeyState(VK_SHIFT)>=0)
		return 0;
	if(iKey!=VK_SHIFT && ::GetAsyncKeyState(VK_SHIFT)<0)
		return 0;
	if(iKey==VK_MENU && ::GetAsyncKeyState(VK_MENU)>=0)
		return 0;
	if(iKey!=VK_MENU && ::GetAsyncKeyState(VK_MENU)<0)
		return 0;
	if(iKey==VK_CONTROL && ::GetAsyncKeyState(VK_CONTROL)>=0)
		return 0;
	if(iKey!=VK_CONTROL && ::GetAsyncKeyState(VK_CONTROL)<0)
		return 0;
	if(::GetAsyncKeyState(iKey)>=0)
		return 0;
	return 1;
}

CString UnifyKey(CString sKey)
{
	sKey.MakeUpper();
	if(sKey.Find("WPK")==0){
		// � �� ������ ������
		return sKey;
	}
	CString sRes;
	for(int i=0;i<sKey.GetLength();i++){
		// 23456789ABCDEFGHJKLMNPQRSTUVWXYZ
		if((sKey[i]>='A' && sKey[i]<='Z') || (sKey[i]>='2' && sKey[i]<='9')){//|| sKey>127
			sRes+=sKey[i];
		}
	}
	return sRes;
}

CString regGetBuyURL(CString publisher, CString appName, CString appVer ) 
{
	HKEY hKey = NULL;
	CString buyURL = "";

	// form the registry key path
	CString keyPath = "SOFTWARE\\Digital River\\SoftwarePassport\\" + publisher + "\\" + appName + "\\" + appVer;

	// read the "BuyURL" value from HKEY_LOCAL_MACHINE branch first
	LONG lRet = RegOpenKeyEx(HKEY_LOCAL_MACHINE, keyPath,0,KEY_READ, &hKey);
	if (lRet != ERROR_SUCCESS) {
		// fail to read from HKEY_LOCAL_MACHINE branch, try HKEY_CURRENT_USER
		lRet = RegOpenKeyEx(HKEY_CURRENT_USER, keyPath,0,KEY_READ, &hKey);
	};

	if (lRet == ERROR_SUCCESS) {
        LPSTR   lpBuyURL   = buyURL.GetBuffer( 1024 );
        DWORD   dwSize   = 1024;

		// Read the "BuyURL" value from the registry key.
        RegQueryValueEx(hKey, "BuyURL",0, NULL, (LPBYTE)lpBuyURL, &dwSize);
		buyURL.ReleaseBuffer();

        RegCloseKey( hKey);
	}

	return buyURL;
}


char* CUITranslationImpl::uit(const char* szUIText,const char* szUITextDefault)
{
	return strdup(_l(szUIText,szUITextDefault));
};

void CUITranslationImpl::freestr(char* sz)
{
	free(sz);
}

CUITranslationImpl* CUITranslationImpl::getInstance()
{
	static CUITranslationImpl lng;
	return &lng;
}

CSize GetIconSize(HICON hIcon)
{
	ICONINFO iconinfo;
	GetIconInfo(hIcon,&iconinfo);
	CBitmap bmpT;
	bmpT.Attach(iconinfo.hbmColor);
	CSize size=GetBitmapSize(bmpT);
	ClearBitmap(iconinfo.hbmColor);
	ClearBitmap(iconinfo.hbmMask);
	bmpT.Detach();
	return size;
}

CBitmap* BitmapFromIcon(HICON icon, CSize sizeIn, CBrush* br)
{
	if(icon==0){
		return 0;
	}
	static CBrush brWhite(RGB(255,255,255));
	if(br==NULL){
		br=&brWhite;
	}
	CSize size;
	if(sizeIn.cx==0 || sizeIn.cy==0){
		size=GetIconSize(icon);
	}else{
		size.cx=sizeIn.cx;
		size.cy=sizeIn.cy;
	}
	CBitmap* pBM=new CBitmap;
	BOOL bRes=pBM->CreateCompatibleBitmap(&GetScreenDC(),size.cx,size.cy);
	CDC pDc;
	pDc.CreateCompatibleDC(&GetScreenDC());
	CBitmap* pTmpBmp=pDc.SelectObject(pBM);
	DrawIconEx(pDc.GetSafeHdc(),0,0,icon,size.cx,size.cy,0,*br,DI_NORMAL);
	pDc.SelectObject(pTmpBmp);
	return pBM;
}


CSize GetBitmapSize(HBITMAP pBmp)
{
	if(pBmp==NULL){
		return CSize(0,0);
	}
	BITMAP pBitMap;
	::GetObject(pBmp, sizeof(BITMAP), &pBitMap);
	CSize size(pBitMap.bmWidth,pBitMap.bmHeight);
	return size;
}

CSize GetBitmapSize(CBitmap* pBmp)
{
	if(pBmp==NULL || pBmp->m_hObject==NULL){
		return CSize(0,0);
	}
	BITMAP pBitMap;
	pBmp->GetBitmap( &pBitMap);
	CSize size(pBitMap.bmWidth,pBitMap.bmHeight);
	return size;
}

void ClearBitmap(HBITMAP& hBmp)
{
	if(hBmp!=NULL){
		if(DeleteObject(hBmp)==0){
#ifdef _DEBUG
			TRACE("Error clearing bitmap!");
#endif
		}
		hBmp=NULL;
	}
}

void ClearIcon(HICON& hIcon)
{
	if(hIcon!=NULL){
		DestroyIcon(hIcon);
		hIcon=NULL;
	}
}

HWND PlayMusicX(CString szSoundPath,BOOL bLoopSound, CString sAlias)
{
	CString sLow=szSoundPath;
	sLow.MakeLower();
	if(sLow.Find(".wav")!=-1){
		if(bLoopSound>=0){
			PlaySound(szSoundPath,NULL,SND_FILENAME|SND_ASYNC|(bLoopSound?SND_LOOP:0));//SND_FILENAME|SND_NODEFAULT|SND_NOSTOP|SND_NOWAIT|SND_ASYNC - ������! :(
		}else{
			PlaySound(NULL,NULL,SND_FILENAME|SND_ASYNC);
		}
	}else{
		CString sCommand;
		MCIERROR iErr=0;
		if(bLoopSound>=0){
			szSoundPath=CString("\"")+szSoundPath+CString("\"");
			sCommand=CString("open ")+szSoundPath+" alias "+sAlias;
			iErr=mciSendString(sCommand, 0, 0, 0);
			if(iErr==0){
				sCommand=CString("play ")+sAlias+(bLoopSound?" repeat":"");
				iErr=mciSendString(sCommand, 0, 0, 0);
				TRACE1("Playing %s...\n",szSoundPath);
			}
			//mciExecute(CString("play ")+szSoundPath);
		}else{
			MCIERROR iErr=mciSendString(CString("close ")+sAlias, 0, 0, 0);
			TRACE1("Stopping %s...\n",szSoundPath);
		}
		/*
		HWND m_Video = hPrevInstance;
		if(m_Video != NULL)
		{
			//MCIWndHome(m_Video);
			MCIWndStop(m_Video);
			MCIWndDestroy(m_Video);
		}
		if(szSoundPath!=""){
			m_Video = MCIWndCreate(hParent,
				theApp.m_hInstance,
				(hParent?WS_CHILD:WS_POPUP)|MCIWNDF_NOMENU,szSoundPath);
			MCIWndPlay(m_Video);
		}
		return m_Video;
		*/
	}
	return 0;
}

BOOL RegisterExtension(CString sExt, CString sDescription, CString sExeParam)
{
    // sDescription is the description key for you application
    sDescription.Replace(" ","");            
    sExt.Replace(" ","");                // sExt � extension to register
    if(sExt.IsEmpty()) return FALSE;
    if(sDescription.IsEmpty()) return FALSE;

    sExt.Replace(".","");
    sExt="."+sExt;

    CString str=GetCommandLine(); // Getting the application name
    CString app;
    int index=str.Find(":",0);
    index=str.Find(":",index+1);
    if(index==-1) app=str;
    else app=str.Mid(0,index-1);

    app.Replace("\"",""); 
    app+=" ";
	app+=sExeParam;
	app+="\"%1\"";
    HKEY hkey;
    RegOpenKeyEx(HKEY_CLASSES_ROOT,"",0,KEY_QUERY_VALUE,&hkey);
    DWORD dw;
    RegCreateKeyEx(hkey, sExt.operator LPCTSTR() , 0L, NULL,
            REG_OPTION_NON_VOLATILE, 
            KEY_ALL_ACCESS, 
            NULL,&hkey, &dw );
    CString key=sDescription;
    RegSetValueEx(hkey,"",0,REG_SZ,(BYTE *)key.operator LPCTSTR(),
               key.GetLength());
    RegCloseKey(hkey);

    RegOpenKeyEx(HKEY_CLASSES_ROOT,"",0,KEY_QUERY_VALUE,&hkey);
    RegCreateKeyEx (hkey, key, 0L, NULL,
            REG_OPTION_NON_VOLATILE, 
            KEY_ALL_ACCESS, 
            NULL, &hkey, &dw);
    RegCreateKeyEx (hkey, "shell",  0L, NULL,
            REG_OPTION_NON_VOLATILE,
            KEY_ALL_ACCESS, 
            NULL,&hkey,  &dw);
    RegCreateKeyEx (hkey, "open", 0L, NULL,
            REG_OPTION_NON_VOLATILE,
            KEY_ALL_ACCESS, 
            NULL,&hkey, &dw);
    RegCreateKeyEx (hkey, "command", 0L, NULL,
            REG_OPTION_NON_VOLATILE,
            KEY_ALL_ACCESS, 
            NULL,&hkey, &dw);
    RegSetValueEx(hkey,"",0,REG_SZ, (LPBYTE)(LPCTSTR)app,app.GetLength());
    RegCloseKey(hkey);

    RegOpenKeyEx(HKEY_CLASSES_ROOT,key,0,KEY_QUERY_VALUE,&hkey);
    RegCreateKeyEx (hkey, "DefaultIcon", 0L, NULL,
            REG_OPTION_NON_VOLATILE, 
            KEY_ALL_ACCESS,
            NULL,&hkey, &dw);
    app.Replace(" \"%1\"",",0");
    RegSetValueEx(hkey,"",0,REG_SZ, (LPBYTE)(LPCTSTR)app,app.GetLength());
    RegCloseKey(hkey);
    return TRUE;
}