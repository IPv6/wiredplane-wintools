Mapi2Pop3 for Windows NT/2000/XP/98/ME
Copyright (C)2002-2003 WiredPlane Labs
e-mail: support@wiredplane.com
http://www.wiredplane.com
-------------------------

Description
-------------------------
Wish to use your favourite POP3 client instead of Outlook? Have program 
that work with emails via POP3 and want it to work through Outlook? 
Then install this application and get what you want!
Mapi2Pop3 allows one to read/access Outlook folders via 
Pop3 protocol and send messages through Outlook via Smtp protocol.
This application can be useful in the following cases:
- You wish to use your favourite Pop3 client for email messaging but 
have Exchange server without Pop3/Imap support (so you forced to use Outlook)
- You have application that can interact with/benefit from Pop3 or Smtp 
services and wish it to work thourgh Outlook folders
- You have PPC or mobile phone and with to use it`s emails in your 
favourite Pop3 client, but PPC/Mobile software allows synchronization 
with Outlook only. In this case you can leave synchronization with 
Outlook as is and connect to local Outlook folders through this proxy
	
Install/Uninstall
-------------------------
Install:
   Unzip the downloaded file Mapi2Pop3.zip into a temporary folder and
 run the Mapi2Pop3.exe file. The installer will let you choose where to
 install the program and create a program group in the Window's Start Menu.

Uninstall:
   Unstalling of Mapi2Pop3 may be carried out either by choosing
 "Add/Delete Program" in Control Panel or by choosing "Uninstall" from the
 program group.

Protection:
-------------------------
Mapi2Pop3 is distributed as Freeware for personal, non-commersial use.
For commersial use you need to purchase a license. 
See documentation or visit our web site for more information.

Disclaimer of warranty:
-------------------------
This software is sold "AS IS" and without warranties whether expressed or
implied. Because of the various software and hardware environments into
which this program may be put, no warranty of fitness for a particular
purpose is offered. 

Feedback
-------------------------
If you have a problem using Mapi2Pop3, want to tell us your suggestions,
or have found a bug, please write us: support@wiredplane.com
New versions and updates can be found at http://www.wiredplane.com

Authors
-------------------------
Razinkov Ilja, WiredPlane Labs

History
-------------------------
See history.html for details


