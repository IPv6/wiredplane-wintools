Made for PG competiotn at TigSource By Razinkov Ilja aka IPv6
(c)2008

Used libraries are:
- Irrlight, 3D Engine
- GameRotor, Game engine
- BASS, Sound engine
- Squirrel, Scripting engine
- BOX2d, Physics engine

Credits:
Music: SinQ, "Tryout"
Effects: Public domain collections